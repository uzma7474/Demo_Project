import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/BasePage';
import { parsePrice } from '../utils/helpers';

export interface CheckoutInfo {
  firstName: string;
  lastName: string;
  postalCode: string;
}

/** Covers all three checkout screens: information -> overview -> complete. */
export class CheckoutPage extends BasePage {
  readonly firstName: Locator;
  readonly lastName: Locator;
  readonly postalCode: Locator;
  readonly continueButton: Locator;
  readonly finishButton: Locator;
  readonly errorMessage: Locator;
  readonly subtotalLabel: Locator;
  readonly completeHeader: Locator;

  constructor(page: Page) {
    super(page);
    this.firstName = this.byTestId('firstName');
    this.lastName = this.byTestId('lastName');
    this.postalCode = this.byTestId('postalCode');
    this.continueButton = this.byTestId('continue');
    this.finishButton = this.byTestId('finish');
    this.errorMessage = this.byTestId('error');
    this.subtotalLabel = this.byTestId('subtotal-label');
    this.completeHeader = this.byTestId('complete-header');
  }

  async fillInformation(info: CheckoutInfo): Promise<void> {
    await this.type(this.firstName, info.firstName, 'first name');
    await this.type(this.lastName, info.lastName, 'last name');
    await this.type(this.postalCode, info.postalCode, 'postal code');
  }

  async continue(): Promise<void> {
    await this.click(this.continueButton, 'continue');
  }

  async finish(): Promise<void> {
    await this.click(this.finishButton, 'finish');
  }

  async getOverviewItemPrices(): Promise<number[]> {
    const raw = await this.byTestId('inventory-item-price').allInnerTexts();
    return raw.map(parsePrice);
  }

  async getSubtotal(): Promise<number> {
    return parsePrice(await this.subtotalLabel.innerText());
  }
}
