import { Locator, Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage';

/** Shared header + burger menu, present on every authenticated page. */
export class HeaderComponent extends BasePage {
  readonly menuButton: Locator;
  readonly logoutLink: Locator;
  readonly cartLink: Locator;
  readonly cartBadge: Locator;

  constructor(page: Page) {
    super(page);
    this.menuButton = page.locator('#react-burger-menu-btn');
    this.logoutLink = this.byTestId('logout-sidebar-link');
    this.cartLink = this.byTestId('shopping-cart-link');
    this.cartBadge = this.byTestId('shopping-cart-badge');
  }

  async logout(): Promise<void> {
    await this.click(this.menuButton, 'burger menu');
    await this.click(this.logoutLink, 'logout link');
  }

  async openCart(): Promise<void> {
    await this.click(this.cartLink, 'cart icon');
  }

  /** Returns 0 when the badge is not rendered (empty cart). */
  async getCartCount(): Promise<number> {
    if (!(await this.cartBadge.isVisible())) return 0;
    return Number(await this.cartBadge.innerText());
  }
}
