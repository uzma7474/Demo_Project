import { Page } from '@playwright/test';
import { CartPage } from './CartPage';
import { CheckoutPage } from './CheckoutPage';
import { InventoryPage } from './InventoryPage';
import { LoginPage } from './LoginPage';
import { HeaderComponent } from './components/HeaderComponent';

/** Lazily instantiates page objects so each scenario only pays for what it uses. */
export class PageManager {
  private cache = new Map<string, unknown>();

  constructor(private readonly page: Page) {}

  private get<T>(key: string, factory: (p: Page) => T): T {
    if (!this.cache.has(key)) this.cache.set(key, factory(this.page));
    return this.cache.get(key) as T;
  }

  get login(): LoginPage { return this.get('login', (p) => new LoginPage(p)); }
  get inventory(): InventoryPage { return this.get('inventory', (p) => new InventoryPage(p)); }
  get cart(): CartPage { return this.get('cart', (p) => new CartPage(p)); }
  get checkout(): CheckoutPage { return this.get('checkout', (p) => new CheckoutPage(p)); }
  get header(): HeaderComponent { return this.get('header', (p) => new HeaderComponent(p)); }
}
