import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/BasePage';
import { slugify } from '../utils/helpers';

export class CartPage extends BasePage {
  readonly title: Locator;
  readonly checkoutButton: Locator;
  readonly continueShoppingButton: Locator;

  constructor(page: Page) {
    super(page);
    this.title = this.byTestId('title');
    this.checkoutButton = this.byTestId('checkout');
    this.continueShoppingButton = this.byTestId('continue-shopping');
  }

  async getItemNames(): Promise<string[]> {
    return this.byTestId('inventory-item-name').allInnerTexts();
  }

  async removeItem(productName: string): Promise<void> {
    await this.click(this.byTestId(`remove-${slugify(productName)}`), `remove ${productName}`);
  }

  async checkout(): Promise<void> {
    await this.click(this.checkoutButton, 'checkout');
  }
}
