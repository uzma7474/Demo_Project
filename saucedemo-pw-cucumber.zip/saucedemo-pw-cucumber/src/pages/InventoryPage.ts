import { Locator, Page } from '@playwright/test';
import { BasePage } from '../core/BasePage';
import { parsePrice, slugify } from '../utils/helpers';

export class InventoryPage extends BasePage {
  readonly title: Locator;
  readonly items: Locator;
  readonly sortDropdown: Locator;

  constructor(page: Page) {
    super(page);
    this.title = this.byTestId('title');
    this.items = this.byTestId('inventory-item');
    this.sortDropdown = this.byTestId('product-sort-container');
  }

  async getProductNames(): Promise<string[]> {
    return this.byTestId('inventory-item-name').allInnerTexts();
  }

  async getProductPrices(): Promise<number[]> {
    const raw = await this.byTestId('inventory-item-price').allInnerTexts();
    return raw.map(parsePrice);
  }

  async sortBy(label: string): Promise<void> {
    await this.sortDropdown.selectOption({ label });
  }

  async addToCart(productName: string): Promise<void> {
    await this.click(this.byTestId(`add-to-cart-${slugify(productName)}`), `add ${productName}`);
  }

  async removeFromCart(productName: string): Promise<void> {
    await this.click(this.byTestId(`remove-${slugify(productName)}`), `remove ${productName}`);
  }

  removeButtonFor(productName: string): Locator {
    return this.byTestId(`remove-${slugify(productName)}`);
  }
}
