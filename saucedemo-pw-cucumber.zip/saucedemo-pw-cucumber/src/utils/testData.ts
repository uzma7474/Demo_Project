import users from '../test-data/users.json';

export interface Credentials { username: string; password: string }

export const getUser = (key: string): Credentials => {
  const user = (users as Record<string, Credentials>)[key];
  if (!user) throw new Error(`Unknown user "${key}". Available: ${Object.keys(users).join(', ')}`);
  return user;
};
