/** "Sauce Labs Backpack" -> "sauce-labs-backpack" (matches SauceDemo data-test ids). */
export const slugify = (name: string): string =>
  name.trim().toLowerCase().replace(/\s+/g, '-');

/** "Item total: $39.98" | "$29.99" -> 39.98 | 29.99 */
export const parsePrice = (text: string): number => {
  const match = text.match(/\$?(\d+(?:\.\d+)?)\s*$/);
  if (!match) throw new Error(`Cannot parse price from "${text}"`);
  return Number(match[1]);
};

export const round2 = (n: number): number => Math.round(n * 100) / 100;

export const sum = (nums: number[]): number => round2(nums.reduce((a, b) => a + b, 0));

export const isSortedAsc = <T>(arr: T[]): boolean => arr.every((v, i) => i === 0 || arr[i - 1] <= v);

export const isSortedDesc = <T>(arr: T[]): boolean => arr.every((v, i) => i === 0 || arr[i - 1] >= v);
