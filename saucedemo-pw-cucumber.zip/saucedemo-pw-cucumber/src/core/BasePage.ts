import { Locator, Page, expect } from '@playwright/test';
import { Logger } from './logger';

/**
 * Base class for every Page Object / Component.
 * Holds thin, logged wrappers over Playwright actions so page classes stay declarative.
 */
export abstract class BasePage {
  protected readonly log: Logger;

  constructor(protected readonly page: Page) {
    this.log = new Logger(this.constructor.name);
  }

  /** Locator by `data-test` attribute - the stable contract SauceDemo exposes. */
  protected byTestId(id: string): Locator {
    return this.page.locator(`[data-test="${id}"]`);
  }

  async goto(path = '/'): Promise<void> {
    this.log.info(`Navigating to ${path}`);
    await this.page.goto(path);
  }

  protected async click(locator: Locator, description: string): Promise<void> {
    this.log.debug(`Click: ${description}`);
    await locator.click();
  }

  protected async type(locator: Locator, value: string, description: string): Promise<void> {
    this.log.debug(`Fill: ${description}`);
    await locator.fill(value);
  }

  async expectUrlToMatch(pattern: RegExp): Promise<void> {
    await expect(this.page).toHaveURL(pattern);
  }
}
