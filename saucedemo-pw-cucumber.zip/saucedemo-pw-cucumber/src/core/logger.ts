import { env, LogLevel } from '../config/env';

const levels: Record<LogLevel, number> = { debug: 10, info: 20, warn: 30, error: 40 };

/** Tiny structured logger; swap for pino/winston without touching callers. */
export class Logger {
  constructor(private readonly scope: string) {}

  private write(level: LogLevel, message: string, meta?: unknown): void {
    if (levels[level] < levels[env.logLevel]) return;
    const line = `${new Date().toISOString()} [${level.toUpperCase()}] [${this.scope}] ${message}`;
    // eslint-disable-next-line no-console
    (level === 'error' ? console.error : console.log)(line, meta ?? '');
  }

  debug = (m: string, meta?: unknown) => this.write('debug', m, meta);
  info = (m: string, meta?: unknown) => this.write('info', m, meta);
  warn = (m: string, meta?: unknown) => this.write('warn', m, meta);
  error = (m: string, meta?: unknown) => this.write('error', m, meta);
}
