import { Given } from '@cucumber/cucumber';
import { CustomWorld } from '../support/world';

Given('I am on the login page', async function (this: CustomWorld) {
  await this.pages.login.open();
});
