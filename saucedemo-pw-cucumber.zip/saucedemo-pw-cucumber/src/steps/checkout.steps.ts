import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { sum } from '../utils/helpers';

When('I proceed to checkout', async function (this: CustomWorld) {
  await this.pages.cart.checkout();
});

When(
  'I enter checkout information {string}, {string}, {string}',
  async function (this: CustomWorld, firstName: string, lastName: string, postalCode: string) {
    await this.pages.checkout.fillInformation({ firstName, lastName, postalCode });
  },
);

When('I continue the checkout', async function (this: CustomWorld) {
  await this.pages.checkout.continue();
});

When('I finish the order', async function (this: CustomWorld) {
  await this.pages.checkout.finish();
});

Then('the item total should equal the sum of the product prices', async function (this: CustomWorld) {
  const checkout = this.pages.checkout;
  const prices = await checkout.getOverviewItemPrices();
  expect(prices).toHaveLength(this.addedProducts.length);
  expect(await checkout.getSubtotal()).toBeCloseTo(sum(prices), 2);
});

Then('I should see the order confirmation {string}', async function (this: CustomWorld, message: string) {
  await expect(this.pages.checkout.completeHeader).toHaveText(message);
});

Then('I should see checkout error {string}', async function (this: CustomWorld, message: string) {
  await expect(this.pages.checkout.errorMessage).toHaveText(message);
});
