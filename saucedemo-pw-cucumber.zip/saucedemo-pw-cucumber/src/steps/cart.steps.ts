import { DataTable, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';

When('I add {string} to the cart', async function (this: CustomWorld, product: string) {
  await this.pages.inventory.addToCart(product);
  this.addedProducts.push(product);
});

When('I add the following products to the cart:', async function (this: CustomWorld, table: DataTable) {
  for (const { product } of table.hashes()) {
    await this.pages.inventory.addToCart(product);
    this.addedProducts.push(product);
  }
});

When('I remove {string} from the inventory page', async function (this: CustomWorld, product: string) {
  await this.pages.inventory.removeFromCart(product);
  this.addedProducts = this.addedProducts.filter((p) => p !== product);
});

When('I open the cart', async function (this: CustomWorld) {
  await this.pages.header.openCart();
});

Then('the cart badge should show {int}', async function (this: CustomWorld, count: number) {
  await expect(this.pages.header.cartBadge).toHaveText(String(count));
});

Then('the cart should contain {string}', async function (this: CustomWorld, product: string) {
  expect(await this.pages.cart.getItemNames()).toContain(product);
});

Then('the cart should not contain {string}', async function (this: CustomWorld, product: string) {
  expect(await this.pages.cart.getItemNames()).not.toContain(product);
});
