import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { getUser } from '../utils/testData';

When('I login as {string}', async function (this: CustomWorld, userKey: string) {
  const { username, password } = getUser(userKey);
  await this.pages.login.login(username, password);
});

When(
  'I login with username {string} and password {string}',
  async function (this: CustomWorld, username: string, password: string) {
    await this.pages.login.login(username, password);
  },
);

When('I logout', async function (this: CustomWorld) {
  await this.pages.header.logout();
});

Then('I should be on the inventory page', async function (this: CustomWorld) {
  await this.pages.inventory.expectUrlToMatch(/inventory\.html/);
  await expect(this.pages.inventory.title).toHaveText('Products');
});

Then('I should be on the login page', async function (this: CustomWorld) {
  await expect(this.pages.login.loginButton).toBeVisible();
});

Then('I should see login error {string}', async function (this: CustomWorld, message: string) {
  await expect(this.pages.login.errorMessage).toHaveText(message);
});
