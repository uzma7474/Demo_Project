import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { isSortedAsc, isSortedDesc } from '../utils/helpers';

Then('I should see {int} products on the inventory page', async function (this: CustomWorld, count: number) {
  await expect(this.pages.inventory.items).toHaveCount(count);
});

When('I sort products by {string}', async function (this: CustomWorld, option: string) {
  await this.pages.inventory.sortBy(option);
});

Then('the products should be ordered by {string}', async function (this: CustomWorld, option: string) {
  const inventory = this.pages.inventory;
  switch (option) {
    case 'Name (A to Z)':
      expect(isSortedAsc(await inventory.getProductNames())).toBe(true);
      break;
    case 'Name (Z to A)':
      expect(isSortedDesc(await inventory.getProductNames())).toBe(true);
      break;
    case 'Price (low to high)':
      expect(isSortedAsc(await inventory.getProductPrices())).toBe(true);
      break;
    case 'Price (high to low)':
      expect(isSortedDesc(await inventory.getProductPrices())).toBe(true);
      break;
    default:
      throw new Error(`Unsupported sort option: ${option}`);
  }
});
