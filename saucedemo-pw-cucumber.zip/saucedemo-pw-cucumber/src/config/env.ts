import * as dotenv from 'dotenv';

dotenv.config();

const bool = (value: string | undefined, fallback: boolean): boolean =>
  value === undefined ? fallback : value.toLowerCase() === 'true';

const num = (value: string | undefined, fallback: number): number => {
  const parsed = Number(value);
  return Number.isFinite(parsed) && value !== undefined && value !== '' ? parsed : fallback;
};

export type BrowserName = 'chromium' | 'firefox' | 'webkit';
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

const browser = (process.env.BROWSER ?? 'chromium').toLowerCase() as BrowserName;
if (!['chromium', 'firefox', 'webkit'].includes(browser)) {
  throw new Error(`Unsupported BROWSER "${browser}". Use chromium | firefox | webkit`);
}

/** Single source of truth for runtime configuration. */
export const env = Object.freeze({
  baseUrl: process.env.BASE_URL ?? 'https://www.saucedemo.com',
  browser,
  headless: bool(process.env.HEADLESS, true),
  slowMo: num(process.env.SLOW_MO, 0),
  timeout: num(process.env.TIMEOUT_MS, 15_000),
  viewport: {
    width: num(process.env.VIEWPORT_WIDTH, 1440),
    height: num(process.env.VIEWPORT_HEIGHT, 900),
  },
  video: bool(process.env.VIDEO, false),
  logLevel: (process.env.LOG_LEVEL ?? 'info') as LogLevel,
});
