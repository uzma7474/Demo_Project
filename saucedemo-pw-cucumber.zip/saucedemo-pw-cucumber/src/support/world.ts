import { IWorldOptions, World, setWorldConstructor } from '@cucumber/cucumber';
import { BrowserContext, Page } from '@playwright/test';
import { PageManager } from '../pages/PageManager';

/**
 * One World instance is created per scenario => full isolation.
 * Holds the Playwright context/page and any state steps need to share.
 */
export class CustomWorld extends World {
  context!: BrowserContext;
  page!: Page;
  pages!: PageManager;

  /** Scenario-scoped shared state (e.g. products added to the cart). */
  addedProducts: string[] = [];

  constructor(options: IWorldOptions) {
    super(options);
  }
}

setWorldConstructor(CustomWorld);
