import {
  After, AfterAll, Before, BeforeAll, ITestCaseHookParameter, Status, setDefaultTimeout,
} from '@cucumber/cucumber';
import { Browser, chromium, firefox, webkit } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { env } from '../config/env';
import { Logger } from '../core/logger';
import { PageManager } from '../pages/PageManager';
import { getUser } from '../utils/testData';
import { CustomWorld } from './world';

const log = new Logger('Hooks');
const launchers = { chromium, firefox, webkit };
const TRACE_DIR = 'traces';
const VIDEO_DIR = 'videos';

let browser: Browser;

setDefaultTimeout(60_000); // Cucumber step timeout (Playwright has its own, see env.timeout)

BeforeAll(async () => {
  log.info(`Launching ${env.browser} (headless=${env.headless})`);
  browser = await launchers[env.browser].launch({ headless: env.headless, slowMo: env.slowMo });
});

AfterAll(async () => {
  await browser?.close();
});

Before(async function (this: CustomWorld, { pickle }: ITestCaseHookParameter) {
  log.info(`Starting scenario: ${pickle.name}`);
  this.context = await browser.newContext({
    baseURL: env.baseUrl,
    viewport: env.viewport,
    recordVideo: env.video ? { dir: VIDEO_DIR } : undefined,
  });
  await this.context.tracing.start({ screenshots: true, snapshots: true, sources: true });
  this.page = await this.context.newPage();
  this.page.setDefaultTimeout(env.timeout);
  this.pages = new PageManager(this.page);
});

/** Tag @loggedin => start the scenario already authenticated as standard_user. */
Before({ tags: '@loggedin' }, async function (this: CustomWorld) {
  const { username, password } = getUser('standard_user');
  await this.pages.login.open();
  await this.pages.login.login(username, password);
  await this.pages.inventory.title.waitFor();
});

After(async function (this: CustomWorld, { pickle, result }: ITestCaseHookParameter) {
  const failed = result?.status === Status.FAILED;
  const safeName = pickle.name.replace(/[^a-z0-9]+/gi, '_').slice(0, 80);

  if (failed) {
    const shot = await this.page.screenshot({ fullPage: true });
    this.attach(shot, 'image/png');
    fs.mkdirSync(TRACE_DIR, { recursive: true });
    const tracePath = path.join(TRACE_DIR, `${safeName}.zip`);
    await this.context.tracing.stop({ path: tracePath });
    log.error(`FAILED: ${pickle.name} -> trace: ${tracePath} (npx playwright show-trace)`);
  } else {
    await this.context.tracing.stop();
  }

  await this.page.close();
  await this.context.close();
});
