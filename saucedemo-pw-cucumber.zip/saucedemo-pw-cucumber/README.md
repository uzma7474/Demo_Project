# SauceDemo – Playwright + TypeScript + Cucumber (BDD) Framework

## Architecture

```
features/                 Gherkin specs (business-readable, tagged)
src/
  config/env.ts           Typed, validated env config (dotenv)
  core/                   BasePage (action wrappers), Logger
  pages/                  Page Objects + components + PageManager (lazy factory)
  steps/                  Thin step definitions (no selectors, no waits)
  support/                World (per-scenario state) + Hooks (browser lifecycle, trace, screenshot)
  test-data/              JSON test data   |  utils/  helpers & data access
scripts/generate-report.ts  HTML report generator
cucumber.js               Profiles: default | smoke | regression
.github/workflows/e2e.yml CI matrix (chromium/firefox/webkit) + artifacts
```

Layering rule: **Feature -> Steps -> Page Objects -> BasePage -> Playwright**. Steps never touch locators; assertions live in steps using Playwright web-first `expect`.

Key design decisions
- One shared browser per worker (`BeforeAll`), **one isolated BrowserContext per scenario** -> parallel-safe.
- Locators use SauceDemo's `data-test` attributes; no `waitForTimeout` anywhere (auto-waiting + web-first assertions).
- On failure: full-page screenshot attached to the report + Playwright **trace zip** in `traces/`.
- `@loggedin` tag hook gives pre-authenticated scenarios without repeating login steps.
- Tag strategy: `@smoke`, `@regression`, `@wip`/`@skip` (excluded automatically).

## Quick start

```bash
npm install
npx playwright install --with-deps
cp .env.example .env

npm test                 # all (excluding @wip/@skip)
npm run test:smoke
npm run test:regression
npm run test:parallel    # 4 workers
npm run test:headed
BROWSER=firefox npm test
npm run report           # reports/html/index.html
npm run test:rerun       # re-run failed scenarios
npx playwright show-trace traces/<scenario>.zip
```

Ad-hoc tags: `npx cucumber-js --tags "@cart and not @smoke"`

## Extending
1. Add a page class in `src/pages`, expose it in `PageManager`.
2. Add steps in `src/steps/<area>.steps.ts`.
3. Write the `.feature` file and tag it.
