// eslint-disable-next-line @typescript-eslint/no-var-requires
const reporter = require('multiple-cucumber-html-reporter');
import { env } from '../src/config/env';

reporter.generate({
  jsonDir: 'reports',
  reportPath: 'reports/html',
  reportName: 'SauceDemo E2E Report',
  pageTitle: 'SauceDemo E2E',
  displayDuration: true,
  metadata: {
    browser: { name: env.browser === 'webkit' ? 'safari' : env.browser, version: 'latest' },
    device: process.env.CI ? 'CI runner' : 'Local machine',
    platform: { name: process.platform },
  },
  customData: {
    title: 'Run info',
    data: [
      { label: 'Base URL', value: env.baseUrl },
      { label: 'Headless', value: String(env.headless) },
    ],
  },
});
