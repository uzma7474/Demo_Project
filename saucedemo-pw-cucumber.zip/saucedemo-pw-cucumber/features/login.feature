@login
Feature: Login
  As a shopper
  I want to authenticate on SauceDemo
  So that I can access the product catalogue

  Background:
    Given I am on the login page

  @smoke @regression
  Scenario: Successful login with a standard user
    When I login as "standard_user"
    Then I should be on the inventory page

  @regression
  Scenario: Locked out user cannot login
    When I login as "locked_out_user"
    Then I should see login error "Epic sadface: Sorry, this user has been locked out."

  @regression
  Scenario Outline: Login fails with invalid input
    When I login with username "<username>" and password "<password>"
    Then I should see login error "<error>"

    Examples:
      | username      | password     | error                                                                     |
      | standard_user | wrong_pass   | Epic sadface: Username and password do not match any user in this service |
      | unknown_user  | secret_sauce | Epic sadface: Username and password do not match any user in this service |
      |               | secret_sauce | Epic sadface: Username is required                                        |
      | standard_user |              | Epic sadface: Password is required                                        |

  @regression @loggedin
  Scenario: User can logout
    When I logout
    Then I should be on the login page
