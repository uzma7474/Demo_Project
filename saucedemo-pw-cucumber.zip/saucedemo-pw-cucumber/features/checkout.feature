@checkout @loggedin
Feature: Checkout

  @smoke @regression
  Scenario: Complete an end-to-end purchase
    When I add the following products to the cart:
      | product                 |
      | Sauce Labs Backpack     |
      | Sauce Labs Bike Light   |
    And I open the cart
    And I proceed to checkout
    And I enter checkout information "John", "Doe", "411001"
    And I continue the checkout
    Then the item total should equal the sum of the product prices
    When I finish the order
    Then I should see the order confirmation "Thank you for your order!"

  @regression
  Scenario Outline: Checkout information is validated
    When I add "Sauce Labs Backpack" to the cart
    And I open the cart
    And I proceed to checkout
    And I enter checkout information "<first>", "<last>", "<zip>"
    And I continue the checkout
    Then I should see checkout error "<error>"

    Examples:
      | first | last | zip    | error                          |
      |       | Doe  | 411001 | Error: First Name is required  |
      | John  |      | 411001 | Error: Last Name is required   |
      | John  | Doe  |        | Error: Postal Code is required |
