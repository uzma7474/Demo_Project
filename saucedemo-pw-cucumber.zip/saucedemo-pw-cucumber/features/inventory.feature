@inventory @loggedin
Feature: Product inventory

  @smoke @regression
  Scenario: Catalogue shows six products
    Then I should see 6 products on the inventory page

  @regression
  Scenario Outline: Sort products
    When I sort products by "<sort option>"
    Then the products should be ordered by "<sort option>"

    Examples:
      | sort option         |
      | Name (A to Z)       |
      | Name (Z to A)       |
      | Price (low to high) |
      | Price (high to low) |
