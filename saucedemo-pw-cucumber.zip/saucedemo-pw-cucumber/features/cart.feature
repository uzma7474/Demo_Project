@cart @loggedin
Feature: Shopping cart

  @smoke @regression
  Scenario: Add a product to the cart
    When I add "Sauce Labs Backpack" to the cart
    Then the cart badge should show 1
    When I open the cart
    Then the cart should contain "Sauce Labs Backpack"

  @regression
  Scenario: Add multiple products and remove one
    When I add the following products to the cart:
      | product                  |
      | Sauce Labs Backpack      |
      | Sauce Labs Bike Light    |
      | Sauce Labs Bolt T-Shirt  |
    Then the cart badge should show 3
    When I remove "Sauce Labs Bike Light" from the inventory page
    Then the cart badge should show 2
    When I open the cart
    Then the cart should contain "Sauce Labs Backpack"
    And the cart should contain "Sauce Labs Bolt T-Shirt"
    And the cart should not contain "Sauce Labs Bike Light"
