// Cucumber profiles. Run with: cucumber-js --profile <name>
const common = {
  requireModule: ['ts-node/register'],
  require: ['src/support/**/*.ts', 'src/steps/**/*.ts'],
  paths: ['features/**/*.feature'],
  format: [
    'progress-bar',
    'html:reports/cucumber-report.html',
    'json:reports/cucumber-report.json',
    'rerun:@rerun.txt',
  ],
  formatOptions: { snippetInterface: 'async-await' },
  retry: Number(process.env.RETRY || 0),
  parallel: Number(process.env.PARALLEL || 1),
  publishQuiet: true,
};

module.exports = {
  default: { ...common, tags: 'not @wip and not @skip' },
  smoke: { ...common, tags: '@smoke and not @wip and not @skip' },
  regression: { ...common, tags: '@regression and not @wip and not @skip' },
};
