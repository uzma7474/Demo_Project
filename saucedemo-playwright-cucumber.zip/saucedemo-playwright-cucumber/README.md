# SauceDemo – Playwright + TypeScript + Cucumber (BDD) Framework

Scalable UI automation framework for https://www.saucedemo.com using the Page Object Model,
a Cucumber `CustomWorld`, lifecycle hooks, and JSON/Excel data-driven testing.

## Prerequisites
- Node.js 18+ (20 LTS recommended)

## Setup
```bash
npm install          # also downloads the Chromium browser (postinstall)
npm run typecheck    # optional: verify TypeScript compiles
```
If browsers were skipped: `npx playwright install` (add `--with-deps` on Linux CI).

## Running tests
| Command | Purpose |
|---|---|
| `npm test` | all scenarios (headless Chromium) |
| `npm run test:smoke` / `test:regression` / `test:e2e` | run by tag profile |
| `npm run test:headed` | visible browser |
| `npm run test:parallel` | 4 parallel workers (`PARALLEL=n` to change) |
| `npm run test:firefox` / `test:webkit` | other browsers |
| `npm run test:debug` | headed + slow motion |
| `npx cucumber-js --tags "@login and not @excel"` | ad-hoc tag expression |
| `RETRY=1 npm test` | retry failed scenarios once |

## Architecture
```
config/env.config.ts        Typed env config (.env, .env.<ENV>, real env vars)
cucumber.js                 Profiles: default, smoke, regression, e2e + reporters
src/
  features/                 Gherkin: login, inventory, cart, checkout
  steps/                    Thin step definitions (no selectors, only page-object calls)
  pages/                    POM: BasePage, Login, Inventory, Cart, CheckoutInfo/Overview/Complete, PageManager
  support/
    world.ts                CustomWorld (page, context, pages, shared scenario state)
    hooks.ts                BeforeAll/Before/@loggedin/After/AfterAll (trace, screenshot, video, cleanup)
    browserManager.ts       One browser per worker, isolated context per scenario
  utils/                    logger (winston), jsonReader, excelReader, testDataProvider, priceUtils
  test-data/                users.json, products.json, checkout.json, testdata.xlsx
reports/                    cucumber-report.html/json, screenshots, traces (generated)
logs/execution.log          Rolling log file (generated)
```

### Key design points
- **Isolation:** every scenario gets its own `BrowserContext`; the browser is launched once per worker.
- **POM + PageManager:** locators live only in page classes; steps call intent-level methods.
  `data-test` attributes are exposed through `getByTestId()` (`selectors.setTestIdAttribute('data-test')`).
- **Hooks:** `@loggedin` tag logs in as `standard_user` before the scenario; failures attach a full-page
  screenshot to the report and keep a Playwright trace (`reports/traces/*.zip`).
  View traces with `npx playwright show-trace reports/traces/<name>.zip`.
- **Data-driven:** `TestDataProvider` is the single facade over JSON and Excel (`@excel` scenarios use `testdata.xlsx`
  sheets `LoginData` and `CheckoutData`, keyed by `TestCaseId`).
- **Config:** override anything via env vars, e.g. `BROWSER=firefox HEADLESS=false npm test`,
  or create `.env.staging` and run with `ENV=staging`.

## Adding a new test
1. Add/extend a page class in `src/pages` and expose it in `PageManager`.
2. Write the scenario in `src/features/*.feature`.
3. Add steps in `src/steps` (reuse existing ones first).
4. Put data in `src/test-data` and read it through `TestDataProvider`.

## Notes
- Reports: open `reports/cucumber-report.html` after a run.
- The framework was written against SauceDemo's `data-test` attributes; if the site changes them, update only the page classes.
