import { ExcelReader, ExcelRow } from './excelReader';
import { JsonReader } from './jsonReader';

export interface UserCredentials {
  username: string;
  password: string;
}

export interface Product {
  name: string;
  price: number;
}

export interface CheckoutInfo {
  firstName: string;
  lastName: string;
  postalCode: string;
}

export const EXCEL_FILE = 'testdata.xlsx';

/** Single facade over all test-data sources (JSON + Excel). Steps never touch files directly. */
export class TestDataProvider {
  static getUser(key: string): UserCredentials {
    return JsonReader.get<UserCredentials>('users.json', key);
  }

  static getProducts(): Product[] {
    return JsonReader.read<Product[]>('products.json');
  }

  static getProduct(name: string): Product {
    const product = TestDataProvider.getProducts().find((p) => p.name === name);
    if (!product) throw new Error(`Product "${name}" not found in products.json`);
    return product;
  }

  static getCheckoutInfo(key: string): CheckoutInfo {
    return JsonReader.get<CheckoutInfo>('checkout.json', key);
  }

  static getLoginRow(testCaseId: string): Promise<ExcelRow> {
    return ExcelReader.getRow(EXCEL_FILE, 'LoginData', testCaseId);
  }

  static getCheckoutRow(testCaseId: string): Promise<ExcelRow> {
    return ExcelReader.getRow(EXCEL_FILE, 'CheckoutData', testCaseId);
  }
}
