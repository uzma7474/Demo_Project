import fs from 'fs';
import path from 'path';
import { config } from '../../config/env.config';
import { logger } from './logger';

const cache = new Map<string, unknown>();

export class JsonReader {
  /** Reads (and caches) a JSON file located in src/test-data. */
  static read<T>(fileName: string): T {
    const filePath = path.join(config.paths.testData, fileName);
    if (!cache.has(filePath)) {
      if (!fs.existsSync(filePath)) throw new Error(`JSON test data not found: ${filePath}`);
      logger.debug(`Loading JSON test data: ${fileName}`);
      cache.set(filePath, JSON.parse(fs.readFileSync(filePath, 'utf-8')));
    }
    return cache.get(filePath) as T;
  }

  /** Reads a single top-level key from a JSON file. */
  static get<T>(fileName: string, key: string): T {
    const data = JsonReader.read<Record<string, T>>(fileName);
    if (!(key in data)) {
      throw new Error(`Key "${key}" not found in ${fileName}. Available: ${Object.keys(data).join(', ')}`);
    }
    return data[key];
  }
}
