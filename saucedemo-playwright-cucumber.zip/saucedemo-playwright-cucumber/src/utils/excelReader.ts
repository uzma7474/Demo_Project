import ExcelJS from 'exceljs';
import fs from 'fs';
import path from 'path';
import { config } from '../../config/env.config';
import { logger } from './logger';

export type ExcelRow = Record<string, string>;

const cache = new Map<string, ExcelRow[]>();

export class ExcelReader {
  /** Reads a worksheet into an array of objects (first row = headers). Results are cached. */
  static async readSheet(fileName: string, sheetName: string): Promise<ExcelRow[]> {
    const filePath = path.join(config.paths.testData, fileName);
    const cacheKey = `${filePath}::${sheetName}`;
    if (cache.has(cacheKey)) return cache.get(cacheKey) as ExcelRow[];

    if (!fs.existsSync(filePath)) throw new Error(`Excel test data not found: ${filePath}`);
    logger.debug(`Loading Excel sheet "${sheetName}" from ${fileName}`);

    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(filePath);
    const sheet = workbook.getWorksheet(sheetName);
    if (!sheet) {
      const available = workbook.worksheets.map((w) => w.name).join(', ');
      throw new Error(`Sheet "${sheetName}" not found in ${fileName}. Available: ${available}`);
    }

    const headers: string[] = [];
    sheet.getRow(1).eachCell({ includeEmpty: false }, (cell, col) => {
      headers[col] = cell.text.trim();
    });

    const rows: ExcelRow[] = [];
    sheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      if (rowNumber === 1) return;
      const record: ExcelRow = {};
      headers.forEach((header, col) => {
        if (header) record[header] = row.getCell(col).text ?? '';
      });
      rows.push(record);
    });

    cache.set(cacheKey, rows);
    return rows;
  }

  /** Returns the row whose `keyColumn` equals `keyValue` (default key column: TestCaseId). */
  static async getRow(
    fileName: string,
    sheetName: string,
    keyValue: string,
    keyColumn = 'TestCaseId'
  ): Promise<ExcelRow> {
    const rows = await ExcelReader.readSheet(fileName, sheetName);
    const row = rows.find((r) => r[keyColumn] === keyValue);
    if (!row) throw new Error(`No row with ${keyColumn}="${keyValue}" in sheet "${sheetName}"`);
    return row;
  }
}
