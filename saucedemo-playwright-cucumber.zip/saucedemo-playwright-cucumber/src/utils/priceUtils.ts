/** Extracts a number from strings like "$29.99" or "Item total: $39.98". */
export function parsePrice(text: string): number {
  const match = text.match(/\$?(\d+(?:\.\d+)?)\s*$/);
  if (!match) throw new Error(`Unable to parse price from "${text}"`);
  return Number(match[1]);
}

export const round2 = (n: number): number => Math.round(n * 100) / 100;
