import fs from 'fs';
import winston from 'winston';
import { config } from '../../config/env.config';

fs.mkdirSync(config.paths.logs, { recursive: true });

const lineFormat = winston.format.printf(
  ({ timestamp, level, message }) => `${timestamp} [${level.toUpperCase().padEnd(5)}] ${message}`
);

export const logger = winston.createLogger({
  level: config.logLevel,
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
    lineFormat
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(winston.format.colorize({ all: false }), lineFormat)
    }),
    new winston.transports.File({
      filename: `${config.paths.logs}/execution.log`,
      maxsize: 5 * 1024 * 1024,
      maxFiles: 5
    })
  ]
});
