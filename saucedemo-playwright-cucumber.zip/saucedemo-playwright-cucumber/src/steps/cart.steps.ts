import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';

When('I open the shopping cart', async function (this: CustomWorld) {
  await this.pages.inventory.openCart();
  await this.pages.cart.expectLoaded();
});

Then('the cart should contain the selected products', async function (this: CustomWorld) {
  const names = await this.pages.cart.getItemNames();
  expect(names.sort()).toEqual([...this.cartProducts].sort());
});

Then('the cart should contain {int} item(s)', async function (this: CustomWorld, count: number) {
  expect(await this.pages.cart.getItemCount()).toBe(count);
});

When('I remove the product {string} from the cart', async function (this: CustomWorld, name: string) {
  await this.pages.cart.removeItem(name);
  this.cartProducts = this.cartProducts.filter((p) => p !== name);
});

When('I continue shopping', async function (this: CustomWorld) {
  await this.pages.cart.continueShopping();
});

When('I proceed to checkout', async function (this: CustomWorld) {
  await this.pages.cart.proceedToCheckout();
  await this.pages.checkoutInfo.expectLoaded();
});
