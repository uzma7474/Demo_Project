import { Given, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { TestDataProvider } from '../utils/testDataProvider';

Given('I am on the login page', async function (this: CustomWorld) {
  await this.pages.login.open();
  await this.pages.login.expectLoginFormVisible();
});

Given('I am logged in as {string} user', async function (this: CustomWorld, userKey: string) {
  const user = TestDataProvider.getUser(userKey);
  await this.pages.login.open();
  await this.pages.login.login(user.username, user.password);
  await this.pages.inventory.expectLoaded();
  this.currentUser = user;
});

Then('I should land on the products page', async function (this: CustomWorld) {
  await this.pages.inventory.expectLoaded();
});

Then('the page title should be {string}', async function (this: CustomWorld, title: string) {
  expect(await this.pages.inventory.getTitle()).toBe(title);
});
