import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { round2 } from '../utils/priceUtils';
import { TestDataProvider } from '../utils/testDataProvider';

When('I enter checkout information {string} from JSON', async function (this: CustomWorld, key: string) {
  await this.pages.checkoutInfo.fillInformation(TestDataProvider.getCheckoutInfo(key));
});

When(
  'I enter checkout information first name {string}, last name {string} and postal code {string}',
  async function (this: CustomWorld, firstName: string, lastName: string, postalCode: string) {
    await this.pages.checkoutInfo.fillInformation({ firstName, lastName, postalCode });
  }
);

When('I enter checkout information from Excel test case {string}', async function (this: CustomWorld, id: string) {
  this.excelRow = await TestDataProvider.getCheckoutRow(id);
  await this.pages.checkoutInfo.fillInformation({
    firstName: this.excelRow.FirstName,
    lastName: this.excelRow.LastName,
    postalCode: this.excelRow.PostalCode
  });
});

When('I continue to the order overview', async function (this: CustomWorld) {
  await this.pages.checkoutInfo.continue();
});

When('I cancel the checkout', async function (this: CustomWorld) {
  await this.pages.checkoutInfo.cancel();
});

Then('I should see the checkout error {string}', async function (this: CustomWorld, message: string) {
  await this.pages.checkoutInfo.expectError(message);
});

Then('the checkout error should match the Excel expectation', async function (this: CustomWorld) {
  await this.pages.checkoutInfo.expectError(this.excelRow!.ExpectedError);
});

Then('the order overview should list the selected products', async function (this: CustomWorld) {
  await this.pages.checkoutOverview.expectLoaded();
  const names = await this.pages.checkoutOverview.getItemNames();
  expect(names.sort()).toEqual([...this.cartProducts].sort());
});

Then('the order totals should be calculated correctly', async function (this: CustomWorld) {
  const expectedSubtotal = round2(
    this.cartProducts.reduce((sum, name) => sum + TestDataProvider.getProduct(name).price, 0)
  );
  const subtotal = await this.pages.checkoutOverview.getSubtotal();
  const tax = await this.pages.checkoutOverview.getTax();
  const total = await this.pages.checkoutOverview.getTotal();

  expect(subtotal).toBe(expectedSubtotal);
  expect(round2(subtotal + tax)).toBe(total);
  this.log(`Subtotal=${subtotal} Tax=${tax} Total=${total}`);
});

When('I finish the order', async function (this: CustomWorld) {
  await this.pages.checkoutOverview.finish();
});

Then('I should see the order confirmation {string}', async function (this: CustomWorld, header: string) {
  await this.pages.checkoutComplete.expectOrderComplete(header);
});

Then('I should be back on the cart page', async function (this: CustomWorld) {
  await this.pages.cart.expectLoaded();
});
