import { DataTable, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { TestDataProvider } from '../utils/testDataProvider';

Then('I should see all products listed', async function (this: CustomWorld) {
  const expected = TestDataProvider.getProducts();
  expect(await this.pages.inventory.getProductCount()).toBe(expected.length);
  const names = await this.pages.inventory.getProductNames();
  expect([...names].sort()).toEqual(expected.map((p) => p.name).sort());
});

When('I sort products by {string}', async function (this: CustomWorld, option: string) {
  await this.pages.inventory.sortBy(option);
});

Then('the products should be sorted by {string}', async function (this: CustomWorld, option: string) {
  const names = await this.pages.inventory.getProductNames();
  const prices = await this.pages.inventory.getProductPrices();
  const asc = <T>(a: T[]) => [...a].sort();
  switch (option) {
    case 'Name (A to Z)':
      expect(names).toEqual(asc(names));
      break;
    case 'Name (Z to A)':
      expect(names).toEqual(asc(names).reverse());
      break;
    case 'Price (low to high)':
      expect(prices).toEqual([...prices].sort((a, b) => a - b));
      break;
    case 'Price (high to low)':
      expect(prices).toEqual([...prices].sort((a, b) => b - a));
      break;
    default:
      throw new Error(`Unsupported sort option: ${option}`);
  }
});

When('I add the product {string} to the cart', async function (this: CustomWorld, name: string) {
  await this.pages.inventory.addToCart(name);
  this.cartProducts.push(name);
});

When('I add the following products to the cart:', async function (this: CustomWorld, table: DataTable) {
  for (const name of table.raw().flat()) {
    await this.pages.inventory.addToCart(name);
    this.cartProducts.push(name);
  }
});

When('I remove the product {string} from the inventory page', async function (this: CustomWorld, name: string) {
  await this.pages.inventory.removeFromCart(name);
  this.cartProducts = this.cartProducts.filter((p) => p !== name);
});

Then('the cart badge should show {int}', async function (this: CustomWorld, count: number) {
  await this.pages.inventory.expectCartBadge(count);
});

Then('the cart badge should not be displayed', async function (this: CustomWorld) {
  await this.pages.inventory.expectCartBadge(0);
});

Then('the {string} button should be shown for {string}', async function (this: CustomWorld, _label: string, name: string) {
  await this.pages.inventory.expectRemoveButtonVisible(name);
});
