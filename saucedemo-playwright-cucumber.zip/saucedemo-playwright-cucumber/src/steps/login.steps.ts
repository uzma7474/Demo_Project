import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { TestDataProvider } from '../utils/testDataProvider';

When('I login as {string} user', async function (this: CustomWorld, userKey: string) {
  const user = TestDataProvider.getUser(userKey);
  this.currentUser = user;
  await this.pages.login.login(user.username, user.password);
});

When(
  'I login with username {string} and password {string}',
  async function (this: CustomWorld, username: string, password: string) {
    await this.pages.login.login(username, password);
  }
);

Then('I should see the login error {string}', async function (this: CustomWorld, message: string) {
  await this.pages.login.expectError(message);
});

When('I login using Excel test case {string}', async function (this: CustomWorld, testCaseId: string) {
  this.excelRow = await TestDataProvider.getLoginRow(testCaseId);
  this.log(`Excel login data: ${JSON.stringify({ ...this.excelRow, Password: '***' })}`);
  await this.pages.login.login(this.excelRow.Username, this.excelRow.Password);
});

Then('the login result should match the Excel expectation', async function (this: CustomWorld) {
  expect(this.excelRow, 'Excel row must be loaded first').toBeDefined();
  const { ExpectedResult, ExpectedMessage } = this.excelRow!;
  if (ExpectedResult === 'Success') {
    await this.pages.inventory.expectLoaded();
  } else {
    await this.pages.login.expectError(ExpectedMessage);
  }
});

When('I logout', async function (this: CustomWorld) {
  await this.pages.inventory.logout();
});

Then('I should be redirected to the login page', async function (this: CustomWorld) {
  await this.pages.login.expectLoginFormVisible();
});
