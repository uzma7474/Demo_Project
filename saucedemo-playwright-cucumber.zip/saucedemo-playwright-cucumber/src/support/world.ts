import { IWorldOptions, World, setWorldConstructor } from '@cucumber/cucumber';
import { BrowserContext, Page } from '@playwright/test';
import { PageManager } from '../pages/PageManager';
import { ExcelRow } from '../utils/excelReader';
import { logger } from '../utils/logger';
import { UserCredentials } from '../utils/testDataProvider';

/**
 * CustomWorld: per-scenario container. Holds the Playwright objects, page objects
 * and any state that steps need to share (cart contents, current user, Excel row...).
 */
export class CustomWorld extends World {
  context!: BrowserContext;
  page!: Page;
  pages!: PageManager;

  // Shared scenario state
  currentUser?: UserCredentials;
  cartProducts: string[] = [];
  excelRow?: ExcelRow;

  constructor(options: IWorldOptions) {
    super(options);
  }

  /** Logs to file/console and attaches the message to the Cucumber report. */
  log(message: string): void {
    logger.info(message);
    this.attach(message);
  }
}

setWorldConstructor(CustomWorld);
