import {
  After,
  AfterAll,
  AfterStep,
  Before,
  BeforeAll,
  ITestCaseHookParameter,
  Status,
  setDefaultTimeout
} from '@cucumber/cucumber';
import fs from 'fs';
import { config } from '../../config/env.config';
import { PageManager } from '../pages/PageManager';
import { logger } from '../utils/logger';
import { TestDataProvider } from '../utils/testDataProvider';
import { BrowserManager } from './browserManager';
import { CustomWorld } from './world';

setDefaultTimeout(60 * 1000);

const safeName = (name: string): string => name.replace(/[^a-z0-9]+/gi, '_').slice(0, 100);

BeforeAll(async function () {
  [config.paths.screenshots, config.paths.traces, config.paths.videos].forEach((dir) =>
    fs.mkdirSync(dir, { recursive: true })
  );
  logger.info(`===== Test run started | env=${config.env} | baseUrl=${config.baseUrl} =====`);
  await BrowserManager.launch();
});

Before(async function (this: CustomWorld, scenario: ITestCaseHookParameter) {
  logger.info(`--- Scenario START: ${scenario.pickle.name} ---`);

  const browser = await BrowserManager.launch();
  this.context = await browser.newContext({
    baseURL: config.baseUrl,
    viewport: config.viewport,
    ...(config.video ? { recordVideo: { dir: config.paths.videos } } : {})
  });
  this.context.setDefaultTimeout(config.defaultTimeout);
  this.context.setDefaultNavigationTimeout(config.navigationTimeout);

  if (config.trace !== 'off') {
    await this.context.tracing.start({ screenshots: true, snapshots: true, sources: false });
  }

  this.page = await this.context.newPage();
  this.pages = new PageManager(this.page);
});

// Tagged hook: scenarios tagged @loggedin start already authenticated as standard_user.
Before({ tags: '@loggedin' }, async function (this: CustomWorld) {
  const user = TestDataProvider.getUser('standard');
  logger.info('@loggedin hook: performing pre-login');
  await this.pages.login.open();
  await this.pages.login.login(user.username, user.password);
  await this.pages.inventory.expectLoaded();
  this.currentUser = user;
});

AfterStep(async function (this: CustomWorld, { result }) {
  if (result?.status === Status.FAILED) {
    logger.error('Step failed - screenshot will be captured in the After hook');
  }
});

After(async function (this: CustomWorld, scenario: ITestCaseHookParameter) {
  const failed = scenario.result?.status === Status.FAILED;
  const name = safeName(scenario.pickle.name);

  if (failed && this.page && !this.page.isClosed()) {
    const screenshot = await this.page.screenshot({
      path: `${config.paths.screenshots}/${name}_${Date.now()}.png`,
      fullPage: true
    });
    this.attach(screenshot, 'image/png');
  }

  if (config.trace !== 'off' && this.context) {
    const keep = config.trace === 'on' || failed;
    await this.context.tracing.stop(keep ? { path: `${config.paths.traces}/${name}.zip` } : undefined);
  }

  const video = this.page?.video();
  await this.page?.close();
  await this.context?.close();
  if (video && !failed) await video.delete().catch(() => undefined);

  logger.info(`--- Scenario END: ${scenario.pickle.name} | ${scenario.result?.status} ---`);
});

AfterAll(async function () {
  await BrowserManager.close();
  logger.info('===== Test run finished =====');
});
