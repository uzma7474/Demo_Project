import { Browser, chromium, firefox, selectors, webkit } from '@playwright/test';
import { config } from '../../config/env.config';
import { logger } from '../utils/logger';

/** One browser per worker process; each scenario gets an isolated BrowserContext. */
export class BrowserManager {
  private static browser?: Browser;

  static async launch(): Promise<Browser> {
    if (this.browser) return this.browser;

    // SauceDemo uses `data-test` attributes, so getByTestId() maps to them.
    selectors.setTestIdAttribute('data-test');

    const launcher = { chromium, firefox, webkit }[config.browser];
    logger.info(`Launching ${config.browser} (headless=${config.headless}, slowMo=${config.slowMo})`);
    this.browser = await launcher.launch({ headless: config.headless, slowMo: config.slowMo });
    return this.browser;
  }

  static async close(): Promise<void> {
    if (this.browser) {
      await this.browser.close();
      this.browser = undefined;
      logger.info('Browser closed');
    }
  }
}
