import { expect } from '@playwright/test';
import { BasePage } from './BasePage';
import { CheckoutInfo } from '../utils/testDataProvider';

export class CheckoutInfoPage extends BasePage {
  protected readonly path = '/checkout-step-one.html';

  private readonly firstName = this.testId('firstName');
  private readonly lastName = this.testId('lastName');
  private readonly postalCode = this.testId('postalCode');
  private readonly continueButton = this.testId('continue');
  private readonly cancelButton = this.testId('cancel');
  private readonly errorMessage = this.testId('error');

  async expectLoaded(): Promise<void> {
    await this.expectOnPage('checkout-step-one.html', 'Checkout: Your Information');
  }

  async fillInformation(info: CheckoutInfo): Promise<void> {
    await this.fill(this.firstName, info.firstName, 'first name');
    await this.fill(this.lastName, info.lastName, 'last name');
    await this.fill(this.postalCode, info.postalCode, 'postal code');
  }

  async continue(): Promise<void> {
    await this.click(this.continueButton, 'Continue');
  }

  async cancel(): Promise<void> {
    await this.click(this.cancelButton, 'Cancel');
  }

  async expectError(expected: string): Promise<void> {
    await expect(this.errorMessage).toHaveText(expected);
  }
}
