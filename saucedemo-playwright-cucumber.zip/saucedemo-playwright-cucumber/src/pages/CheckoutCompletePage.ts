import { expect } from '@playwright/test';
import { BasePage } from './BasePage';

export class CheckoutCompletePage extends BasePage {
  protected readonly path = '/checkout-complete.html';

  private readonly header = this.testId('complete-header');
  private readonly backHomeButton = this.testId('back-to-products');

  async expectOrderComplete(expectedHeader: string): Promise<void> {
    await this.expectOnPage('checkout-complete.html', 'Checkout: Complete!');
    await expect(this.header).toHaveText(expectedHeader);
  }

  async backToProducts(): Promise<void> {
    await this.click(this.backHomeButton, 'Back Home');
  }
}
