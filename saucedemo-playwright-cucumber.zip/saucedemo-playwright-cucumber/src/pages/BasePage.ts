import { Locator, Page, expect } from '@playwright/test';
import { logger } from '../utils/logger';

export abstract class BasePage {
  protected abstract readonly path: string;

  constructor(protected readonly page: Page) {}

  protected get pageName(): string {
    return this.constructor.name;
  }

  async open(): Promise<void> {
    logger.info(`[${this.pageName}] Opening ${this.path}`);
    await this.page.goto(this.path);
  }

  protected testId(id: string): Locator {
    return this.page.getByTestId(id);
  }

  protected async click(locator: Locator, description: string): Promise<void> {
    logger.info(`[${this.pageName}] Click: ${description}`);
    await locator.click();
  }

  protected async fill(locator: Locator, value: string, description: string): Promise<void> {
    logger.info(`[${this.pageName}] Fill: ${description}`);
    await locator.fill(value);
  }

  async getTitle(): Promise<string> {
    return (await this.testId('title').textContent())?.trim() ?? '';
  }

  async expectOnPage(urlFragment: string, title?: string): Promise<void> {
    await expect(this.page).toHaveURL(new RegExp(urlFragment));
    if (title) await expect(this.testId('title')).toHaveText(title);
  }
}
