import { Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';
import { parsePrice } from '../utils/priceUtils';
import { logger } from '../utils/logger';

export class InventoryPage extends BasePage {
  protected readonly path = '/inventory.html';

  private readonly items = this.testId('inventory-item');
  private readonly itemNames = this.testId('inventory-item-name');
  private readonly itemPrices = this.testId('inventory-item-price');
  private readonly sortDropdown = this.testId('product-sort-container');
  private readonly cartLink = this.testId('shopping-cart-link');
  private readonly cartBadge = this.testId('shopping-cart-badge');
  private readonly menuButton = this.page.getByRole('button', { name: 'Open Menu' });
  private readonly logoutLink = this.testId('logout-sidebar-link');

  private item(name: string): Locator {
    return this.items.filter({ has: this.page.getByTestId('inventory-item-name').getByText(name, { exact: true }) });
  }

  async expectLoaded(): Promise<void> {
    await this.expectOnPage('inventory.html', 'Products');
  }

  async getProductCount(): Promise<number> {
    return this.items.count();
  }

  async getProductNames(): Promise<string[]> {
    return (await this.itemNames.allTextContents()).map((t) => t.trim());
  }

  async getProductPrices(): Promise<number[]> {
    return (await this.itemPrices.allTextContents()).map(parsePrice);
  }

  async addToCart(productName: string): Promise<void> {
    logger.info(`[InventoryPage] Add to cart: ${productName}`);
    await this.item(productName).getByRole('button', { name: 'Add to cart' }).click();
  }

  async removeFromCart(productName: string): Promise<void> {
    logger.info(`[InventoryPage] Remove from cart: ${productName}`);
    await this.item(productName).getByRole('button', { name: 'Remove' }).click();
  }

  async sortBy(optionLabel: string): Promise<void> {
    logger.info(`[InventoryPage] Sort by: ${optionLabel}`);
    await this.sortDropdown.selectOption({ label: optionLabel });
  }

  async expectCartBadge(count: number): Promise<void> {
    if (count === 0) await expect(this.cartBadge).toHaveCount(0);
    else await expect(this.cartBadge).toHaveText(String(count));
  }

  async expectRemoveButtonVisible(productName: string): Promise<void> {
    await expect(this.item(productName).getByRole('button', { name: 'Remove' })).toBeVisible();
  }

  async openCart(): Promise<void> {
    await this.click(this.cartLink, 'Shopping cart');
  }

  async logout(): Promise<void> {
    await this.click(this.menuButton, 'Open Menu');
    await this.click(this.logoutLink, 'Logout');
  }
}
