import { Page } from '@playwright/test';
import { CartPage } from './CartPage';
import { CheckoutCompletePage } from './CheckoutCompletePage';
import { CheckoutInfoPage } from './CheckoutInfoPage';
import { CheckoutOverviewPage } from './CheckoutOverviewPage';
import { InventoryPage } from './InventoryPage';
import { LoginPage } from './LoginPage';

/** Lazily creates page objects so each scenario gets fresh instances bound to its own Page. */
export class PageManager {
  private _login?: LoginPage;
  private _inventory?: InventoryPage;
  private _cart?: CartPage;
  private _checkoutInfo?: CheckoutInfoPage;
  private _checkoutOverview?: CheckoutOverviewPage;
  private _checkoutComplete?: CheckoutCompletePage;

  constructor(private readonly page: Page) {}

  get login(): LoginPage { return (this._login ??= new LoginPage(this.page)); }
  get inventory(): InventoryPage { return (this._inventory ??= new InventoryPage(this.page)); }
  get cart(): CartPage { return (this._cart ??= new CartPage(this.page)); }
  get checkoutInfo(): CheckoutInfoPage { return (this._checkoutInfo ??= new CheckoutInfoPage(this.page)); }
  get checkoutOverview(): CheckoutOverviewPage { return (this._checkoutOverview ??= new CheckoutOverviewPage(this.page)); }
  get checkoutComplete(): CheckoutCompletePage { return (this._checkoutComplete ??= new CheckoutCompletePage(this.page)); }
}
