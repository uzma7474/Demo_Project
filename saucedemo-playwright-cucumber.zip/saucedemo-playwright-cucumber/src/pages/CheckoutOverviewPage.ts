import { BasePage } from './BasePage';
import { parsePrice } from '../utils/priceUtils';

export class CheckoutOverviewPage extends BasePage {
  protected readonly path = '/checkout-step-two.html';

  private readonly itemNames = this.testId('inventory-item-name');
  private readonly subtotal = this.testId('subtotal-label');
  private readonly tax = this.testId('tax-label');
  private readonly total = this.testId('total-label');
  private readonly finishButton = this.testId('finish');

  async expectLoaded(): Promise<void> {
    await this.expectOnPage('checkout-step-two.html', 'Checkout: Overview');
  }

  async getItemNames(): Promise<string[]> {
    return (await this.itemNames.allTextContents()).map((t) => t.trim());
  }

  async getSubtotal(): Promise<number> {
    return parsePrice((await this.subtotal.textContent()) ?? '');
  }

  async getTax(): Promise<number> {
    return parsePrice((await this.tax.textContent()) ?? '');
  }

  async getTotal(): Promise<number> {
    return parsePrice((await this.total.textContent()) ?? '');
  }

  async finish(): Promise<void> {
    await this.click(this.finishButton, 'Finish');
  }
}
