import { expect } from '@playwright/test';
import { BasePage } from './BasePage';
import { logger } from '../utils/logger';

export class LoginPage extends BasePage {
  protected readonly path = '/';

  private readonly username = this.testId('username');
  private readonly password = this.testId('password');
  private readonly loginButton = this.testId('login-button');
  private readonly errorMessage = this.testId('error');

  async login(username: string, password: string): Promise<void> {
    logger.info(`[LoginPage] Logging in as "${username}"`);
    await this.fill(this.username, username, 'username');
    await this.fill(this.password, password, 'password');
    await this.click(this.loginButton, 'Login');
  }

  async getErrorMessage(): Promise<string> {
    return (await this.errorMessage.textContent())?.trim() ?? '';
  }

  async expectError(expected: string): Promise<void> {
    await expect(this.errorMessage).toHaveText(expected);
  }

  async expectLoginFormVisible(): Promise<void> {
    await expect(this.loginButton).toBeVisible();
  }
}
