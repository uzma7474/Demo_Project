import { expect } from '@playwright/test';
import { BasePage } from './BasePage';

export class CartPage extends BasePage {
  protected readonly path = '/cart.html';

  private readonly items = this.testId('inventory-item');
  private readonly itemNames = this.testId('inventory-item-name');
  private readonly checkoutButton = this.testId('checkout');
  private readonly continueShoppingButton = this.testId('continue-shopping');

  async expectLoaded(): Promise<void> {
    await this.expectOnPage('cart.html', 'Your Cart');
  }

  async getItemNames(): Promise<string[]> {
    return (await this.itemNames.allTextContents()).map((t) => t.trim());
  }

  async getItemCount(): Promise<number> {
    return this.items.count();
  }

  async removeItem(productName: string): Promise<void> {
    await this.items
      .filter({ has: this.page.getByTestId('inventory-item-name').getByText(productName, { exact: true }) })
      .getByRole('button', { name: 'Remove' })
      .click();
  }

  async proceedToCheckout(): Promise<void> {
    await this.click(this.checkoutButton, 'Checkout');
  }

  async continueShopping(): Promise<void> {
    await this.click(this.continueShoppingButton, 'Continue Shopping');
  }

  async expectEmpty(): Promise<void> {
    await expect(this.items).toHaveCount(0);
  }
}
