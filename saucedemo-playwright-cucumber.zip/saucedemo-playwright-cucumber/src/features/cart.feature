@cart @loggedin
Feature: Shopping cart
  As a logged in customer
  I want to manage the items in my cart
  So that I only buy what I want

  @smoke @regression
  Scenario: Cart contains the selected products
    When I add the following products to the cart:
      | Sauce Labs Backpack     |
      | Sauce Labs Bolt T-Shirt |
      | Sauce Labs Fleece Jacket |
    And I open the shopping cart
    Then the cart should contain the selected products
    And the cart should contain 3 items

  @regression
  Scenario: Remove an item from the cart
    When I add the following products to the cart:
      | Sauce Labs Backpack   |
      | Sauce Labs Bike Light |
    And I open the shopping cart
    And I remove the product "Sauce Labs Bike Light" from the cart
    Then the cart should contain the selected products
    And the cart should contain 1 item

  @regression
  Scenario: Continue shopping returns to the products page
    When I open the shopping cart
    And I continue shopping
    Then I should land on the products page
