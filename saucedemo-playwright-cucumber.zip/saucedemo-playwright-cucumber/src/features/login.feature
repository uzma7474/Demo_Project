@login
Feature: Login
  As a SauceDemo customer
  I want to log in with my credentials
  So that I can shop for products

  Background:
    Given I am on the login page

  @smoke @regression
  Scenario: Successful login with a valid user
    When I login as "standard" user
    Then I should land on the products page

  @regression
  Scenario: Locked out user cannot login
    When I login as "lockedOut" user
    Then I should see the login error "Epic sadface: Sorry, this user has been locked out."

  @regression
  Scenario Outline: Login fails with invalid credentials
    When I login with username "<username>" and password "<password>"
    Then I should see the login error "<error>"

    Examples:
      | username      | password     | error                                                                     |
      | standard_user | wrong_pass   | Epic sadface: Username and password do not match any user in this service |
      | invalid_user  | secret_sauce | Epic sadface: Username and password do not match any user in this service |
      |               | secret_sauce | Epic sadface: Username is required                                        |
      | standard_user |              | Epic sadface: Password is required                                        |

  @regression @excel
  Scenario Outline: Data driven login from Excel
    When I login using Excel test case "<testCaseId>"
    Then the login result should match the Excel expectation

    Examples:
      | testCaseId |
      | LOGIN_001  |
      | LOGIN_002  |
      | LOGIN_003  |

  @regression @loggedin
  Scenario: Logout returns the user to the login page
    When I logout
    Then I should be redirected to the login page
