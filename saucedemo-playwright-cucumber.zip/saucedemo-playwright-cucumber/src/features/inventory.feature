@inventory @loggedin
Feature: Product inventory
  As a logged in customer
  I want to browse, sort and add products
  So that I can choose what to buy

  @smoke @regression
  Scenario: All products are displayed
    Then I should see all products listed
    And the page title should be "Products"

  @regression
  Scenario Outline: Sort products
    When I sort products by "<option>"
    Then the products should be sorted by "<option>"

    Examples:
      | option              |
      | Name (A to Z)       |
      | Name (Z to A)       |
      | Price (low to high) |
      | Price (high to low) |

  @smoke @regression
  Scenario: Adding products updates the cart badge
    When I add the product "Sauce Labs Backpack" to the cart
    And I add the product "Sauce Labs Bike Light" to the cart
    Then the cart badge should show 2

  @regression
  Scenario: Removing a product updates the cart badge
    When I add the product "Sauce Labs Onesie" to the cart
    Then the "Remove" button should be shown for "Sauce Labs Onesie"
    When I remove the product "Sauce Labs Onesie" from the inventory page
    Then the cart badge should not be displayed
