@checkout @loggedin
Feature: Checkout
  As a logged in customer
  I want to complete my purchase
  So that I receive my products

  @e2e @smoke @regression
  Scenario: Complete an end-to-end purchase
    When I add the following products to the cart:
      | Sauce Labs Backpack     |
      | Sauce Labs Bolt T-Shirt |
    And I open the shopping cart
    And I proceed to checkout
    And I enter checkout information "validCustomer" from JSON
    And I continue to the order overview
    Then the order overview should list the selected products
    And the order totals should be calculated correctly
    When I finish the order
    Then I should see the order confirmation "Thank you for your order!"

  @regression
  Scenario Outline: Checkout information validation
    When I add the product "Sauce Labs Backpack" to the cart
    And I open the shopping cart
    And I proceed to checkout
    And I enter checkout information first name "<firstName>", last name "<lastName>" and postal code "<postalCode>"
    And I continue to the order overview
    Then I should see the checkout error "<error>"

    Examples:
      | firstName | lastName | postalCode | error                          |
      |           | Doe      | 411001     | Error: First Name is required  |
      | John      |          | 411001     | Error: Last Name is required   |
      | John      | Doe      |            | Error: Postal Code is required |

  @regression @excel
  Scenario Outline: Checkout validation driven from Excel
    When I add the product "Sauce Labs Onesie" to the cart
    And I open the shopping cart
    And I proceed to checkout
    And I enter checkout information from Excel test case "<testCaseId>"
    And I continue to the order overview
    Then the checkout error should match the Excel expectation

    Examples:
      | testCaseId |
      | CHK_001    |
      | CHK_002    |

  @regression
  Scenario: Cancelling checkout returns to the cart
    When I add the product "Sauce Labs Backpack" to the cart
    And I open the shopping cart
    And I proceed to checkout
    And I cancel the checkout
    Then I should be back on the cart page
