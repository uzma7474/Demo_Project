import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

const root = path.resolve(__dirname, '..');
const envName = process.env.ENV || 'qa';

// Priority: real env vars > .env.<ENV> > .env  (dotenv never overrides existing values)
const envSpecific = path.join(root, `.env.${envName}`);
if (fs.existsSync(envSpecific)) dotenv.config({ path: envSpecific });
dotenv.config({ path: path.join(root, '.env') });

const toBool = (v: string | undefined, d: boolean): boolean =>
  v === undefined ? d : ['true', '1', 'yes', 'on'].includes(v.toLowerCase());

export type BrowserName = 'chromium' | 'firefox' | 'webkit';
export type TraceMode = 'on' | 'off' | 'on-failure';

export const config = {
  env: envName,
  baseUrl: process.env.BASE_URL || 'https://www.saucedemo.com',
  browser: (process.env.BROWSER || 'chromium') as BrowserName,
  headless: toBool(process.env.HEADLESS, true),
  slowMo: Number(process.env.SLOW_MO || 0),
  defaultTimeout: Number(process.env.DEFAULT_TIMEOUT || 15000),
  navigationTimeout: Number(process.env.NAVIGATION_TIMEOUT || 30000),
  viewport: {
    width: Number(process.env.VIEWPORT_WIDTH || 1366),
    height: Number(process.env.VIEWPORT_HEIGHT || 768)
  },
  video: toBool(process.env.VIDEO, false),
  trace: (process.env.TRACE || 'on-failure') as TraceMode,
  logLevel: process.env.LOG_LEVEL || 'info',
  paths: {
    root,
    testData: path.join(root, 'src', 'test-data'),
    reports: path.join(root, 'reports'),
    screenshots: path.join(root, 'reports', 'screenshots'),
    traces: path.join(root, 'reports', 'traces'),
    videos: path.join(root, 'reports', 'videos'),
    logs: path.join(root, 'logs')
  }
} as const;
