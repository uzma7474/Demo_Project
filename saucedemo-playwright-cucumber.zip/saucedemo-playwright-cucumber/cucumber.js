// Cucumber profiles. Run with: npm run test | test:smoke | test:regression | test:e2e
const base = {
  requireModule: ['ts-node/register'],
  require: ['src/support/**/*.ts', 'src/steps/**/*.ts'],
  paths: ['src/features/**/*.feature'],
  format: [
    'progress-bar',
    'html:reports/cucumber-report.html',
    'json:reports/cucumber-report.json'
  ],
  formatOptions: { snippetInterface: 'async-await' },
  parallel: Number(process.env.PARALLEL || 1),
  retry: Number(process.env.RETRY || 0)
};

module.exports = {
  default: base,
  smoke: { ...base, tags: '@smoke' },
  regression: { ...base, tags: '@regression' },
  e2e: { ...base, tags: '@e2e' }
};
