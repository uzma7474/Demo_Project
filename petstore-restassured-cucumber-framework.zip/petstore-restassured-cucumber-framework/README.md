# Petstore API Automation Framework (REST Assured + Cucumber + TestNG)

Industry-style API test framework for the [Swagger Petstore v2](https://petstore.swagger.io/) covering **all 20 operations**
of the three Swagger tags `pet`, `store` and `user`.

Java 17 - Maven - REST Assured 5 - Cucumber 7 (PicoContainer) - TestNG 7 - Jackson - Apache POI - AssertJ - Log4j2 - masterthought HTML reports

## Quick start

```bash
mvn clean verify                                   # everything, 4 scenarios in parallel
mvn clean verify -Psmoke                           # @smoke  (also: -Pregression -Pe2e -Pnegative)
mvn clean verify -Dcucumber.filter.tags="@pet and not @negative"
mvn clean verify -Denv=local                       # self-hosted Petstore: docker run -p 8080:8080 swaggerapi/petstore
mvn clean verify -Dbase.uri=https://my-host -Dapi.key=secret
```

Use `verify` (not `test`): the runner is executed by Failsafe so the HTML report is still produced when scenarios fail.

| Output | Location |
| --- | --- |
| HTML report (masterthought) | `target/cucumber-html-reports/overview-features.html` |
| Cucumber HTML / JSON / JUnit XML | `target/cucumber-reports/` |
| Failed scenarios for re-run | `target/cucumber-reports/rerun.txt` |
| Log file | `logs/api-tests.log` (set `com.petstore` to `debug` in `src/test/resources/log4j2.xml` for full request/response text) |

Every scenario gets its last request/response attached to the report; failed scenarios get the whole conversation.

## API coverage

| Tag | Operation | Endpoint | API object method | Features |
| --- | --- | --- | --- | --- |
| pet | Add pet | `POST /pet` | `PetApi.addPet` | pet, data-driven, e2e |
| pet | Update pet | `PUT /pet` | `PetApi.updatePet` | pet, e2e |
| pet | Find by status | `GET /pet/findByStatus` | `PetApi.findByStatus` | pet |
| pet | Find by tags | `GET /pet/findByTags` | `PetApi.findByTags` | pet |
| pet | Get pet | `GET /pet/{petId}` | `PetApi.getPetById` | pet |
| pet | Update with form | `POST /pet/{petId}` | `PetApi.updatePetWithForm` | pet |
| pet | Delete pet | `DELETE /pet/{petId}` | `PetApi.deletePet` | pet, e2e |
| pet | Upload image | `POST /pet/{petId}/uploadImage` | `PetApi.uploadImage` | pet |
| store | Inventory | `GET /store/inventory` | `StoreApi.getInventory` | store |
| store | Place order | `POST /store/order` | `StoreApi.placeOrder` | store, data-driven, e2e |
| store | Get order | `GET /store/order/{orderId}` | `StoreApi.getOrderById` | store, data-driven |
| store | Delete order | `DELETE /store/order/{orderId}` | `StoreApi.deleteOrder` | store, e2e |
| user | Create user | `POST /user` | `UserApi.createUser` | user, data-driven |
| user | Create with array | `POST /user/createWithArray` | `UserApi.createWithArray` | user |
| user | Create with list | `POST /user/createWithList` | `UserApi.createWithList` | user |
| user | Login | `GET /user/login` | `UserApi.login` | user, e2e |
| user | Logout | `GET /user/logout` | `UserApi.logout` | user, e2e |
| user | Get user | `GET /user/{username}` | `UserApi.getUser` | user, data-driven |
| user | Update user | `PUT /user/{username}` | `UserApi.updateUser` | user |
| user | Delete user | `DELETE /user/{username}` | `UserApi.deleteUser` | user |

5 feature files, 31 scenarios that expand to 45 test executions through the `Scenario Outline` examples (positive, negative,
schema/header/response-time checks, JSON + Excel data-driven outlines, one end-to-end purchase journey).

## Architecture

```
feature file ──▶ step definition ──▶ API object (POM) ──▶ RestClient ──▶ Petstore
 (Gherkin)        (thin glue)         one per Swagger tag    spec, retry,    (HTTP)
                        │                                    logging filter
                        ├──▶ ResponseAssertions (fluent, AssertJ + JSON schema)
                        └──▶ TestDataProvider (JSON | Excel strategy) ──▶ Builders / POJOs
```

```
petstore-restassured-cucumber-framework/
├── pom.xml  testng.xml
├── src/main/java/com/petstore/framework/          # the reusable framework (no Cucumber here)
│   ├── config/ConfigManager                      # Singleton: -D > env var > config-<env>.properties > config.properties
│   ├── constants/Endpoints                       # every path in one place
│   ├── core/    RestClient, RequestSpecFactory   # base spec, retry on 502/503/504 for GET, timeouts
│   ├── api/     BaseApi, PetApi, StoreApi, UserApi   # ★ API Object Model (the POM layer)
│   ├── models/  Pet, Order, User, Category, Tag, ApiMessage (+ status enums)
│   ├── builders/ PetBuilder, OrderBuilder, UserBuilder
│   ├── data/    TestDataProvider, JsonDataProvider, ExcelDataProvider, ExcelMapper, DataProviderFactory
│   ├── utils/   JsonUtils, ExcelUtils, DataResolver, RandomUtils, RetryUtils, ResourceUtils, DateUtils, TextUtils
│   ├── assertions/ ResponseAssertions
│   └── logging/ ExchangeLogFilter                # logs + records every exchange for report attachments
├── src/main/resources/config/                     # config.properties, config-prod.properties, config-local.properties
└── src/test/
    ├── java/com/petstore/
    │   ├── runners/PetstoreRunner                # TestNG + Cucumber, parallel scenarios
    │   ├── hooks/Hooks                           # logging, report attachments, cleanup
    │   ├── context/TestContext                   # per-scenario DI container (PicoContainer)
    │   └── stepdefinitions/ CommonSteps PetSteps StoreSteps UserSteps
    └── resources/
        ├── features/                             # pet, store, user, data-driven, e2e
        ├── schemas/                              # JSON-schema contracts
        └── testdata/                             # json/*.json, excel/petstore-data.xlsx, files/sample-pet.png
```

### POM for APIs

"Page Object Model" has no pages in an API, so each Swagger **tag is the page** and each **operation is a page method**:

| UI Page Object Model | This framework |
| --- | --- |
| `BasePage` | `BaseApi` (holds the `RestClient`) |
| `LoginPage`, `CartPage` ... | `PetApi`, `StoreApi`, `UserApi` |
| locators | `Endpoints` constants |
| page methods return the next page | API methods return the raw `Response` (assert in steps, not in the API object) |
| driver / `WebDriverFactory` | `RestClient` / `RequestSpecFactory` |

API objects hold no assertions and no test data, so the same object serves smoke, regression, e2e and data-driven suites.

### Hybrid design - which pattern solves what

| Pattern | Where | Why |
| --- | --- | --- |
| API Object Model (POM) | `framework/api` | One class per Swagger tag, tests never build URLs or headers |
| Builder | `framework/builders` | Valid-by-default payloads with fluent overrides |
| Factory | `RequestSpecFactory`, `DataProviderFactory` | Central object creation |
| Strategy | `TestDataProvider` (JSON / Excel) | Same scenario, interchangeable data source |
| Singleton | `ConfigManager` | One configuration per JVM |
| Dependency injection | `TestContext` via PicoContainer | Per-scenario client, state and cleanup shared by all step classes, safe for parallel runs |
| Filter (decorator) | `ExchangeLogFilter` | Cross-cutting logging/recording without touching API objects |
| Fluent assertions | `ResponseAssertions` | Readable checks, every failure carries status + body |
| BDD + data-driven | features, `testdata` | Gherkin for behaviour, JSON/Excel for data |

## JSON and Excel utilities

* `JsonUtils` - `readTree`, `read`, `readRecord(file, key, Type)`, `parse`, `fromJson`, `toJson`, `toPrettyJson`, `write`, `getByPath(json, "tags[0].name")`.
* `ExcelUtils` - `readSheet(file, sheet)` returns row maps keyed by header (formulas evaluated); `findRow(file, sheet, key)` (key column `TestCaseId`); `writeSheet(file, sheet, rows)` to export results or generate data.
* `DataResolver` - placeholders usable in JSON **and** Excel cells, so data files can be reused on a shared server:

  `{{randomId}}` (stays numeric) - `{{randomString:Rex}}` - `{{randomEmail:john}}` - `{{randomInt:1:10}}` - `{{timestamp}}` - `{{now}}` - `{{env:NAME}}`

Excel layout (`testdata/excel/petstore-data.xlsx`): sheets `Pets`, `Users`, `Orders`; first column `TestCaseId`; list columns
(`PhotoUrls`, `Tags`) are `;`-separated. The JSON files use the **same keys** as the `TestCaseId` column, so a scenario switches
source with one word:

```gherkin
When I add the pet "PET_DOG_AVAILABLE" from the "excel" data source
```

## Adding a new endpoint or scenario

1. Add the path to `Endpoints` and a method to the right API object (return the `Response`).
2. Add a step in the matching `*Steps` class (call the API object, then `ResponseAssertions`).
3. Write the scenario in `src/test/resources/features`.
4. New data? Add a record to the JSON file and a row to the Excel sheet with the same key.

## Notes about the public Petstore

* It is a shared sandbox: anybody can change or delete data. Every scenario creates its own unique ids/usernames, registers cleanups,
  and read-after-write checks poll briefly because the service is eventually consistent.
* `findByStatus` returns junk created by other users, so the `pets` schema is deliberately loose.
* `shipDate` is sent in the format used by the Swagger examples (`yyyy-MM-dd'T'HH:mm:ss.SSS+0000`).
* The suite hits the live API; run it with a few parallel threads (see `testng.xml`) to stay polite.
* CI: `.github/workflows/api-tests.yml` runs `mvn verify` and uploads the reports.
