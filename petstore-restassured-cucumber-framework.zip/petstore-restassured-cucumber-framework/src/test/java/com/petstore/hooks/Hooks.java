package com.petstore.hooks;

import com.petstore.context.TestContext;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Hooks {

    private static final Logger LOG = LogManager.getLogger(Hooks.class);

    private final TestContext context;

    public Hooks(TestContext context) {
        this.context = context;
    }

    @Before
    public void beforeScenario(Scenario scenario) {
        LOG.info(">>> {}", scenario.getName());
    }

    @After
    public void afterScenario(Scenario scenario) {
        // Attach the last exchange to every scenario and the complete conversation when it failed.
        List<String> exchanges = context.client().exchanges();
        if (!exchanges.isEmpty()) {
            if (scenario.isFailed()) {
                for (int i = 0; i < exchanges.size(); i++) {
                    scenario.attach(exchanges.get(i), "text/plain", "API call " + (i + 1));
                }
            } else {
                scenario.attach(exchanges.get(exchanges.size() - 1), "text/plain", "Last API call");
            }
        }
        context.runCleanups();
        LOG.info("<<< {} [{}]", scenario.getName(), scenario.getStatus());
    }
}
