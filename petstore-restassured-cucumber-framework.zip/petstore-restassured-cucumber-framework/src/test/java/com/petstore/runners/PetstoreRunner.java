package com.petstore.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

/**
 * TestNG entry point. Run a subset with {@code -Dcucumber.filter.tags="@smoke and not @negative"}.
 * Scenarios execute in parallel; the thread count is {@code data-provider-thread-count} in testng.xml.
 */
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"com.petstore.stepdefinitions", "com.petstore.hooks"},
        plugin = {
                "pretty",
                "html:target/cucumber-reports/cucumber.html",
                "json:target/cucumber-reports/cucumber.json",
                "junit:target/cucumber-reports/cucumber.xml",
                "rerun:target/cucumber-reports/rerun.txt"
        },
        monochrome = true)
public class PetstoreRunner extends AbstractTestNGCucumberTests {

    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
