package com.petstore.stepdefinitions;

import com.petstore.context.TestContext;
import com.petstore.framework.assertions.ResponseAssertions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

/** Generic response assertions shared by every feature. */
public class CommonSteps {

    private final TestContext context;

    public CommonSteps(TestContext context) {
        this.context = context;
    }

    @Given("the Petstore API is available")
    public void thePetstoreApiIsAvailable() {
        ResponseAssertions.assertThat(context.record(context.store().getInventory())).hasStatus(200);
    }

    @Then("the response status code should be {int}")
    public void theResponseStatusCodeShouldBe(int expected) {
        ResponseAssertions.assertThat(context.response()).hasStatus(expected);
    }

    @Then("the response status code should be one of {string}")
    public void theResponseStatusCodeShouldBeOneOf(String allowed) {
        ResponseAssertions.assertThat(context.response()).hasStatusIn(allowed);
    }

    @Then("the response body field {string} should equal {string}")
    public void theResponseBodyFieldShouldEqual(String path, String expected) {
        ResponseAssertions.assertThat(context.response()).bodyFieldEquals(path, expected);
    }

    @Then("the response body field {string} should exist")
    public void theResponseBodyFieldShouldExist(String path) {
        ResponseAssertions.assertThat(context.response()).bodyFieldExists(path);
    }

    @Then("the response message should contain {string}")
    public void theResponseMessageShouldContain(String text) {
        ResponseAssertions.assertThat(context.response()).messageContains(text);
    }

    @Then("the response should be a JSON array")
    public void theResponseShouldBeAJsonArray() {
        ResponseAssertions.assertThat(context.response()).isJsonArray();
    }

    @Then("the response header {string} should exist")
    public void theResponseHeaderShouldExist(String name) {
        ResponseAssertions.assertThat(context.response()).hasHeader(name);
    }

    @Then("the response time should be under {int} ms")
    public void theResponseTimeShouldBeUnderMs(int maxMillis) {
        ResponseAssertions.assertThat(context.response()).respondedWithin(maxMillis);
    }

    @Then("the response should match the {string} schema")
    public void theResponseShouldMatchTheSchema(String schema) {
        ResponseAssertions.assertThat(context.response()).matchesSchema(schema);
    }
}
