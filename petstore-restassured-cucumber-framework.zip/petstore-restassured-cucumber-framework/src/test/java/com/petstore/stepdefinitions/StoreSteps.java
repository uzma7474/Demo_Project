package com.petstore.stepdefinitions;

import static org.assertj.core.api.Assertions.assertThat;

import com.petstore.context.TestContext;
import com.petstore.framework.builders.OrderBuilder;
import com.petstore.framework.data.DataProviderFactory;
import com.petstore.framework.models.Order;
import com.petstore.framework.utils.JsonUtils;
import com.petstore.framework.utils.RandomUtils;
import com.petstore.framework.utils.RetryUtils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

/** Step definitions for Swagger tag {@code store}. */
public class StoreSteps {

    private final TestContext context;

    public StoreSteps(TestContext context) {
        this.context = context;
    }

    @When("I request the store inventory")
    public void iRequestTheStoreInventory() {
        context.record(context.store().getInventory());
    }

    /** Orders the pet created earlier in the scenario (or a random pet id when there is none). */
    @When("I place an order for the pet with quantity {int}")
    public void iPlaceAnOrderForThePetWithQuantity(int quantity) {
        submit(buildOrder(quantity));
    }

    @Given("an order is placed for quantity {int}")
    public void anOrderIsPlacedForQuantity(int quantity) {
        submit(buildOrder(quantity));
        assertThat(context.response().statusCode()).as("Precondition failed: %s", context.response().asString()).isEqualTo(200);
    }

    @When("I place the order {string} from the {string} data source")
    public void iPlaceTheOrderFromTheDataSource(String key, String source) {
        submit(DataProviderFactory.create(source).getOrder(key));
    }

    @When("I get the order by its id")
    public void iGetTheOrderByItsId() {
        long id = context.order().getId();
        context.record(RetryUtils.pollUntil(() -> context.store().getOrderById(id), r -> r.statusCode() == 200, 5, 600));
    }

    @When("I get the order with id {long}")
    public void iGetTheOrderWithId(long id) {
        context.record(context.store().getOrderById(id));
    }

    @When("I delete the order")
    public void iDeleteTheOrder() {
        context.record(context.store().deleteOrder(context.order().getId()));
    }

    @When("I delete the order with id {long}")
    public void iDeleteTheOrderWithId(long id) {
        context.record(context.store().deleteOrder(id));
    }

    @Then("the order should no longer exist")
    public void theOrderShouldNoLongerExist() {
        long id = context.order().getId();
        Response response = RetryUtils.pollUntil(() -> context.store().getOrderById(id), r -> r.statusCode() == 404, 5, 600);
        context.record(response);
        assertThat(response.statusCode()).as("Order %s should have been deleted", id).isEqualTo(404);
    }

    @Then("the response should match the submitted order")
    public void theResponseShouldMatchTheSubmittedOrder() {
        Order submitted = context.order();
        Order actual = JsonUtils.fromJson(context.response().asString(), Order.class);
        assertThat(actual.getId()).as("id").isEqualTo(submitted.getId());
        assertThat(actual.getPetId()).as("petId").isEqualTo(submitted.getPetId());
        assertThat(actual.getQuantity()).as("quantity").isEqualTo(submitted.getQuantity());
        assertThat(actual.getStatus()).as("status").isEqualTo(submitted.getStatus());
    }

    @Then("the response message should be the order id")
    public void theResponseMessageShouldBeTheOrderId() {
        assertThat(context.response().jsonPath().getString("message")).isEqualTo(String.valueOf(context.order().getId()));
    }

    private Order buildOrder(int quantity) {
        long petId = context.hasPet() ? context.pet().getId() : RandomUtils.id();
        return OrderBuilder.anOrder().forPet(petId).withQuantity(quantity).build();
    }

    private void submit(Order order) {
        context.setOrder(order);
        Response response = context.record(context.store().placeOrder(order));
        if (response.statusCode() == 200 && order.getId() != null) {
            long id = order.getId();
            context.registerCleanup(() -> context.store().deleteOrder(id));
        }
    }
}
