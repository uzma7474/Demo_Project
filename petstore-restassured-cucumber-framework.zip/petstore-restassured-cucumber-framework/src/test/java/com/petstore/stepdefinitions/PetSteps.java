package com.petstore.stepdefinitions;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.petstore.context.TestContext;
import com.petstore.framework.builders.PetBuilder;
import com.petstore.framework.data.DataProviderFactory;
import com.petstore.framework.models.Pet;
import com.petstore.framework.utils.JsonUtils;
import com.petstore.framework.utils.ResourceUtils;
import com.petstore.framework.utils.RetryUtils;
import com.petstore.framework.utils.TextUtils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import java.util.ArrayList;
import java.util.List;

/** Step definitions for Swagger tag {@code pet}. Thin: they call the API objects and the assertion helpers. */
public class PetSteps {

    private final TestContext context;

    public PetSteps(TestContext context) {
        this.context = context;
    }

    @When("I add a pet named {string} with status {string}")
    public void iAddAPetNamedWithStatus(String name, String status) {
        submit(PetBuilder.aPet().withName(name).withStatus(status).build());
    }

    @When("I add the pet {string} from the {string} data source")
    public void iAddThePetFromTheDataSource(String key, String source) {
        submit(DataProviderFactory.create(source).getPet(key));
    }

    @Given("a pet named {string} with status {string} exists")
    public void aPetNamedWithStatusExists(String name, String status) {
        submit(PetBuilder.aPet().withName(name).withStatus(status).build());
        assertThat(context.response().statusCode()).as("Precondition failed: %s", context.response().asString()).isEqualTo(200);
    }

    @When("I get the pet by its id")
    public void iGetThePetByItsId() {
        long id = context.pet().getId();
        context.record(RetryUtils.pollUntil(() -> context.pets().getPetById(id), r -> r.statusCode() == 200, 5, 600));
    }

    @When("I get the pet with id {long}")
    public void iGetThePetWithId(long id) {
        context.record(context.pets().getPetById(id));
    }

    @When("I update the pet name to {string} and status to {string}")
    public void iUpdateThePetNameAndStatus(String name, String status) {
        Pet updated = copyOf(context.pet());
        updated.setName(name);
        updated.setStatus(status);
        Response response = context.record(context.pets().updatePet(updated));
        if (response.statusCode() == 200) {
            context.setPet(updated);
        }
    }

    @When("I update the pet with form data name {string} and status {string}")
    public void iUpdateThePetWithFormData(String name, String status) {
        Pet pet = context.pet();
        Response response = context.record(context.pets().updatePetWithForm(pet.getId(), name, status));
        if (response.statusCode() == 200) {
            pet.setName(name);
            pet.setStatus(status);
        }
    }

    @When("I find pets by status {string}")
    public void iFindPetsByStatus(String statuses) {
        context.record(context.pets().findByStatus(TextUtils.splitCsv(statuses)));
    }

    @When("I find pets by tags {string}")
    public void iFindPetsByTags(String tags) {
        context.record(context.pets().findByTags(TextUtils.splitCsv(tags)));
    }

    @When("I delete the pet")
    public void iDeleteThePet() {
        context.record(context.pets().deletePet(context.pet().getId()));
    }

    @When("I delete the pet with id {long}")
    public void iDeleteThePetWithId(long id) {
        context.record(context.pets().deletePet(id));
    }

    @When("I upload the image {string} for the pet with metadata {string}")
    public void iUploadTheImageForThePet(String fileName, String metadata) {
        context.record(context.pets().uploadImage(context.pet().getId(), ResourceUtils.toFile("testdata/files/" + fileName), metadata));
    }

    @When("I add a pet with a malformed JSON body")
    public void iAddAPetWithAMalformedJsonBody() {
        context.record(context.pets().addPetRaw("{ \"id\": 1, \"name\": "));
    }

    @Then("the pet should no longer exist")
    public void thePetShouldNoLongerExist() {
        long id = context.pet().getId();
        Response response = RetryUtils.pollUntil(() -> context.pets().getPetById(id), r -> r.statusCode() == 404, 5, 600);
        context.record(response);
        assertThat(response.statusCode()).as("Pet %s should have been deleted", id).isEqualTo(404);
    }

    @Then("the response should match the submitted pet")
    public void theResponseShouldMatchTheSubmittedPet() {
        Pet submitted = context.pet();
        Pet actual = JsonUtils.fromJson(context.response().asString(), Pet.class);
        assertThat(actual.getId()).as("id").isEqualTo(submitted.getId());
        assertThat(actual.getName()).as("name").isEqualTo(submitted.getName());
        assertThat(actual.getStatus()).as("status").isEqualTo(submitted.getStatus());
        assertThat(actual.getPhotoUrls()).as("photoUrls").isEqualTo(submitted.getPhotoUrls());
    }

    @Then("every pet in the response should have one of the statuses {string}")
    public void everyPetInTheResponseShouldHaveOneOfTheStatuses(String statuses) {
        List<String> allowed = TextUtils.splitCsv(statuses);
        JsonNode pets = JsonUtils.parse(context.response().asString());
        assertThat(pets.isArray()).as("response should be an array").isTrue();
        List<String> unexpected = new ArrayList<>();
        for (JsonNode pet : pets) {
            String status = pet.path("status").asText();
            if (!allowed.contains(status)) {
                unexpected.add(pet.path("id").asText() + ":" + status);
            }
        }
        assertThat(unexpected).as("pets outside %s", allowed).isEmpty();
    }

    @Then("the response message should be the pet id")
    public void theResponseMessageShouldBeThePetId() {
        assertThat(context.response().jsonPath().getString("message")).isEqualTo(String.valueOf(context.pet().getId()));
    }

    private void submit(Pet pet) {
        context.setPet(pet);
        Response response = context.record(context.pets().addPet(pet));
        if (response.statusCode() == 200 && pet.getId() != null) {
            long id = pet.getId();
            context.registerCleanup(() -> context.pets().deletePet(id));
        }
    }

    private static Pet copyOf(Pet source) {
        return JsonUtils.fromJson(JsonUtils.toJson(source), Pet.class);
    }
}
