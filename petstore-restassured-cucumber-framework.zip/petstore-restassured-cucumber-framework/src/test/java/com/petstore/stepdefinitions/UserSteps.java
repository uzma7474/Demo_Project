package com.petstore.stepdefinitions;

import static org.assertj.core.api.Assertions.assertThat;

import com.petstore.context.TestContext;
import com.petstore.framework.builders.UserBuilder;
import com.petstore.framework.data.DataProviderFactory;
import com.petstore.framework.models.User;
import com.petstore.framework.utils.JsonUtils;
import com.petstore.framework.utils.RandomUtils;
import com.petstore.framework.utils.RetryUtils;
import com.petstore.framework.utils.TextUtils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import java.util.ArrayList;
import java.util.List;

/** Step definitions for Swagger tag {@code user}. */
public class UserSteps {

    private final TestContext context;

    public UserSteps(TestContext context) {
        this.context = context;
    }

    /** Usernames get a random suffix so repeated and parallel runs never collide on the shared server. */
    @When("I create a user {string}")
    public void iCreateAUser(String username) {
        submit(UserBuilder.aUser().withUsername(RandomUtils.string(username)).build());
    }

    @Given("a user {string} exists")
    public void aUserExists(String username) {
        submit(UserBuilder.aUser().withUsername(RandomUtils.string(username)).build());
        assertThat(context.response().statusCode()).as("Precondition failed: %s", context.response().asString()).isEqualTo(200);
    }

    @When("I create the user {string} from the {string} data source")
    public void iCreateTheUserFromTheDataSource(String key, String source) {
        submit(DataProviderFactory.create(source).getUser(key));
    }

    @When("I create users with the usernames {string} using the array endpoint")
    public void iCreateUsersUsingTheArrayEndpoint(String usernames) {
        List<User> users = buildUsers(usernames);
        context.setBulkUsers(users);
        context.record(context.users().createWithArray(users));
        registerCleanups(users);
    }

    @When("I create users with the usernames {string} using the list endpoint")
    public void iCreateUsersUsingTheListEndpoint(String usernames) {
        List<User> users = buildUsers(usernames);
        context.setBulkUsers(users);
        context.record(context.users().createWithList(users));
        registerCleanups(users);
    }

    @Then("each created user should be retrievable")
    public void eachCreatedUserShouldBeRetrievable() {
        for (User user : context.bulkUsers()) {
            String username = user.getUsername();
            Response response = RetryUtils.pollUntil(() -> context.users().getUser(username), r -> r.statusCode() == 200, 5, 600);
            context.record(response);
            assertThat(response.statusCode()).as("User %s should exist", username).isEqualTo(200);
        }
    }

    @When("I get the user by username")
    public void iGetTheUserByUsername() {
        String username = context.user().getUsername();
        context.record(RetryUtils.pollUntil(() -> context.users().getUser(username), r -> r.statusCode() == 200, 5, 600));
    }

    @When("I get the user {string}")
    public void iGetTheUser(String username) {
        context.record(context.users().getUser(username));
    }

    @When("I update the user email to {string}")
    public void iUpdateTheUserEmailTo(String email) {
        User user = context.user();
        User updated = JsonUtils.fromJson(JsonUtils.toJson(user), User.class);
        updated.setEmail(email);
        Response response = context.record(context.users().updateUser(user.getUsername(), updated));
        if (response.statusCode() == 200) {
            context.setUser(updated);
        }
    }

    @When("I delete the user")
    public void iDeleteTheUser() {
        context.record(context.users().deleteUser(context.user().getUsername()));
    }

    @When("I delete the user {string}")
    public void iDeleteTheUser(String username) {
        context.record(context.users().deleteUser(username));
    }

    @When("I login with the created user credentials")
    public void iLoginWithTheCreatedUserCredentials() {
        User user = context.user();
        context.record(context.users().login(user.getUsername(), user.getPassword()));
    }

    @When("I login with username {string} and password {string}")
    public void iLoginWithUsernameAndPassword(String username, String password) {
        context.record(context.users().login(username, password));
    }

    @When("I logout")
    public void iLogout() {
        context.record(context.users().logout());
    }

    @Then("the user should no longer exist")
    public void theUserShouldNoLongerExist() {
        String username = context.user().getUsername();
        Response response = RetryUtils.pollUntil(() -> context.users().getUser(username), r -> r.statusCode() == 404, 5, 600);
        context.record(response);
        assertThat(response.statusCode()).as("User %s should have been deleted", username).isEqualTo(404);
    }

    @Then("the response should match the submitted user")
    public void theResponseShouldMatchTheSubmittedUser() {
        User submitted = context.user();
        User actual = JsonUtils.fromJson(context.response().asString(), User.class);
        assertThat(actual.getUsername()).as("username").isEqualTo(submitted.getUsername());
        assertThat(actual.getFirstName()).as("firstName").isEqualTo(submitted.getFirstName());
        assertThat(actual.getLastName()).as("lastName").isEqualTo(submitted.getLastName());
        assertThat(actual.getEmail()).as("email").isEqualTo(submitted.getEmail());
    }

    @Then("the response message should be the user id")
    public void theResponseMessageShouldBeTheUserId() {
        assertThat(context.response().jsonPath().getString("message")).isEqualTo(String.valueOf(context.user().getId()));
    }

    @Then("the response message should be the username")
    public void theResponseMessageShouldBeTheUsername() {
        assertThat(context.response().jsonPath().getString("message")).isEqualTo(context.user().getUsername());
    }

    @Then("the response should contain a login session message")
    public void theResponseShouldContainALoginSessionMessage() {
        assertThat(context.response().jsonPath().getString("message")).contains("logged in user session");
    }

    private List<User> buildUsers(String usernamesCsv) {
        List<User> users = new ArrayList<>();
        for (String name : TextUtils.splitCsv(usernamesCsv)) {
            users.add(UserBuilder.aUser().withUsername(RandomUtils.string(name)).build());
        }
        return users;
    }

    private void registerCleanups(List<User> users) {
        if (context.response().statusCode() != 200) {
            return;
        }
        for (User user : users) {
            String username = user.getUsername();
            context.registerCleanup(() -> context.users().deleteUser(username));
        }
    }

    private void submit(User user) {
        context.setUser(user);
        Response response = context.record(context.users().createUser(user));
        if (response.statusCode() == 200 && user.getUsername() != null) {
            String username = user.getUsername();
            context.registerCleanup(() -> context.users().deleteUser(username));
        }
    }
}
