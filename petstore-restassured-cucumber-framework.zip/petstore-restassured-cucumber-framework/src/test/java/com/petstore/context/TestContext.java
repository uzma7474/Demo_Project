package com.petstore.context;

import com.petstore.framework.api.PetApi;
import com.petstore.framework.api.StoreApi;
import com.petstore.framework.api.UserApi;
import com.petstore.framework.core.RestClient;
import com.petstore.framework.models.Order;
import com.petstore.framework.models.Pet;
import com.petstore.framework.models.User;
import io.restassured.response.Response;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Per-scenario container created by Cucumber's PicoContainer and injected into every step class and hook
 * of that scenario: the REST client, the API objects, the scenario state and a cleanup registry.
 */
public class TestContext {

    private static final Logger LOG = LogManager.getLogger(TestContext.class);

    private final RestClient client = new RestClient();
    private final PetApi petApi = new PetApi(client);
    private final StoreApi storeApi = new StoreApi(client);
    private final UserApi userApi = new UserApi(client);
    private final Deque<Runnable> cleanups = new ArrayDeque<>();

    private Response response;
    private Pet pet;
    private Order order;
    private User user;
    private List<User> users;

    public RestClient client() { return client; }
    public PetApi pets() { return petApi; }
    public StoreApi store() { return storeApi; }
    public UserApi users() { return userApi; }

    /** Stores a response as "the last response" and returns it. */
    public Response record(Response response) {
        this.response = response;
        return response;
    }

    public Response response() {
        if (response == null) {
            throw new IllegalStateException("No API call has been made yet in this scenario.");
        }
        return response;
    }

    public Pet pet() {
        if (pet == null || pet.getId() == null) {
            throw new IllegalStateException("No pet in scenario state - add or create one first.");
        }
        return pet;
    }

    public void setPet(Pet pet) { this.pet = pet; }

    public Order order() {
        if (order == null || order.getId() == null) {
            throw new IllegalStateException("No order in scenario state - place one first.");
        }
        return order;
    }

    public boolean hasPet() { return pet != null && pet.getId() != null; }
    public void setOrder(Order order) { this.order = order; }

    public User user() {
        if (user == null || user.getUsername() == null) {
            throw new IllegalStateException("No user in scenario state - create one first.");
        }
        return user;
    }

    public void setUser(User user) { this.user = user; }

    public List<User> bulkUsers() {
        if (users == null || users.isEmpty()) {
            throw new IllegalStateException("No bulk-created users in scenario state.");
        }
        return users;
    }

    public void setBulkUsers(List<User> users) { this.users = users; }

    /** Registers a best-effort cleanup; cleanups run in reverse order after the scenario. */
    public void registerCleanup(Runnable cleanup) {
        cleanups.push(cleanup);
    }

    public void runCleanups() {
        while (!cleanups.isEmpty()) {
            try {
                cleanups.pop().run();
            } catch (RuntimeException e) {
                LOG.warn("Cleanup failed: {}", e.toString());
            }
        }
    }
}
