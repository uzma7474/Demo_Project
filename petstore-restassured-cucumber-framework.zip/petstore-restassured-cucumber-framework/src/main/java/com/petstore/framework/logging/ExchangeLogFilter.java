package com.petstore.framework.logging;

import com.petstore.framework.utils.TextUtils;
import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * REST Assured filter that logs every exchange (INFO summary, DEBUG full text) and keeps the
 * formatted request/response pairs so the Cucumber hooks can attach them to the report.
 * One instance per RestClient, i.e. per scenario - no shared state between parallel scenarios.
 */
public class ExchangeLogFilter implements Filter {

    private static final Logger LOG = LogManager.getLogger(ExchangeLogFilter.class);
    private static final Set<String> SENSITIVE_HEADERS = Set.of("api_key", "authorization");
    private static final int MAX_BODY_CHARS = 20_000;

    private final List<String> exchanges = Collections.synchronizedList(new ArrayList<>());

    @Override
    public Response filter(FilterableRequestSpecification request, FilterableResponseSpecification response, FilterContext context) {
        Response result = context.next(request, response);

        String record = format(request, result);
        exchanges.add(record);
        LOG.info("{} {} -> {} ({} ms)", request.getMethod(), request.getURI(), result.getStatusCode(), result.time());
        LOG.debug("\n{}", record);
        return result;
    }

    /** All formatted exchanges of the scenario, oldest first. */
    public List<String> exchanges() {
        synchronized (exchanges) {
            return new ArrayList<>(exchanges);
        }
    }

    private static String format(FilterableRequestSpecification request, Response response) {
        StringBuilder text = new StringBuilder();
        text.append("REQUEST  ").append(request.getMethod()).append(' ').append(request.getURI()).append('\n');
        boolean multipart = false;
        for (Header header : request.getHeaders()) {
            text.append("  ").append(header.getName()).append(": ").append(mask(header)).append('\n');
            if ("Content-Type".equalsIgnoreCase(header.getName()) && header.getValue() != null
                    && header.getValue().toLowerCase().startsWith("multipart")) {
                multipart = true;
            }
        }
        Object body = request.getBody();
        if (multipart) {
            text.append("  <multipart body>\n");
        } else if (body != null) {
            text.append("  body: ").append(TextUtils.truncate(String.valueOf(body), MAX_BODY_CHARS)).append('\n');
        }

        text.append("RESPONSE ").append(response.getStatusLine()).append(" (").append(response.time()).append(" ms)\n");
        for (Header header : response.getHeaders()) {
            text.append("  ").append(header.getName()).append(": ").append(header.getValue()).append('\n');
        }
        text.append("  body: ").append(TextUtils.truncate(response.asString(), MAX_BODY_CHARS));
        return text.toString();
    }

    private static String mask(Header header) {
        return SENSITIVE_HEADERS.contains(header.getName().toLowerCase()) ? "***" : header.getValue();
    }
}
