package com.petstore.framework.builders;

import com.petstore.framework.models.Order;
import com.petstore.framework.models.OrderStatus;
import com.petstore.framework.utils.DateUtils;
import com.petstore.framework.utils.RandomUtils;

public final class OrderBuilder {

    private final Order order = new Order();

    private OrderBuilder() {
        order.setId(RandomUtils.id());
        order.setPetId(RandomUtils.id());
        order.setQuantity(1);
        order.setShipDate(DateUtils.nowForApi());
        order.setStatus(OrderStatus.PLACED.value());
        order.setComplete(false);
    }

    public static OrderBuilder anOrder() {
        return new OrderBuilder();
    }

    public OrderBuilder withId(long id) {
        order.setId(id);
        return this;
    }

    public OrderBuilder forPet(long petId) {
        order.setPetId(petId);
        return this;
    }

    public OrderBuilder withQuantity(int quantity) {
        order.setQuantity(quantity);
        return this;
    }

    public OrderBuilder withStatus(String status) {
        order.setStatus(status);
        return this;
    }

    public OrderBuilder completed(boolean complete) {
        order.setComplete(complete);
        return this;
    }

    public Order build() {
        return order;
    }
}
