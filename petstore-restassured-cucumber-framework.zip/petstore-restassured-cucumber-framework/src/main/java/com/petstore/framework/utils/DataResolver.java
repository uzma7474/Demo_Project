package com.petstore.framework.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.IntNode;
import com.fasterxml.jackson.databind.node.LongNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Resolves dynamic placeholders inside JSON / Excel test data so the same data file can be reused
 * run after run on a shared environment.
 *
 * <pre>
 *   {{randomId}}           unique number (keeps its numeric type when it is the whole value)
 *   {{randomString:Rex}}   "Rex_k3j9x2"
 *   {{randomEmail:john}}   "john.k3j9x2@example.com"
 *   {{randomInt:1:10}}     number between 1 and 10
 *   {{timestamp}}          epoch millis
 *   {{now}}                date-time in the Petstore format
 *   {{env:API_KEY}}        value of an environment variable
 * </pre>
 */
public final class DataResolver {

    private static final Pattern TOKEN = Pattern.compile("\\{\\{\\s*(\\w+)(?::([^}]*?))?\\s*\\}\\}");

    private DataResolver() {
    }

    public static JsonNode resolve(JsonNode node) {
        if (node == null) {
            return null;
        }
        if (node.isTextual()) {
            return resolveText(node.asText());
        }
        if (node.isObject()) {
            ObjectNode object = (ObjectNode) node;
            List<String> names = new ArrayList<>();
            object.fieldNames().forEachRemaining(names::add);
            for (String name : names) {
                object.set(name, resolve(object.get(name)));
            }
            return object;
        }
        if (node.isArray()) {
            ArrayNode array = (ArrayNode) node;
            for (int i = 0; i < array.size(); i++) {
                array.set(i, resolve(array.get(i)));
            }
            return array;
        }
        return node;
    }

    private static JsonNode resolveText(String text) {
        Matcher whole = TOKEN.matcher(text);
        if (whole.matches()) {
            return token(whole.group(1), whole.group(2));
        }
        Matcher partial = TOKEN.matcher(text);
        StringBuilder result = new StringBuilder();
        while (partial.find()) {
            String replacement = token(partial.group(1), partial.group(2)).asText();
            partial.appendReplacement(result, Matcher.quoteReplacement(replacement));
        }
        partial.appendTail(result);
        return TextNode.valueOf(result.toString());
    }

    private static JsonNode token(String name, String argument) {
        String arg = argument == null ? "" : argument.trim();
        return switch (name) {
            case "randomId" -> LongNode.valueOf(RandomUtils.id());
            case "randomString" -> TextNode.valueOf(RandomUtils.string(arg.isEmpty() ? "data" : arg));
            case "randomEmail" -> TextNode.valueOf(RandomUtils.email(arg.isEmpty() ? "user" : arg));
            case "randomInt" -> {
                String[] range = (arg.isEmpty() ? "1:100" : arg).split(":");
                yield IntNode.valueOf(RandomUtils.intBetween(Integer.parseInt(range[0].trim()), Integer.parseInt(range[1].trim())));
            }
            case "timestamp" -> LongNode.valueOf(System.currentTimeMillis());
            case "now" -> TextNode.valueOf(DateUtils.nowForApi());
            case "env" -> TextNode.valueOf(System.getenv().getOrDefault(arg, ""));
            default -> throw new IllegalArgumentException("Unknown test-data placeholder {{" + name + "}}");
        };
    }
}
