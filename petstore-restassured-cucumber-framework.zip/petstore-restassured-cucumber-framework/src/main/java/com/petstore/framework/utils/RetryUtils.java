package com.petstore.framework.utils;

import java.util.function.Predicate;
import java.util.function.Supplier;

public final class RetryUtils {

    private RetryUtils() {
    }

    /**
     * Repeats {@code action} until {@code done} accepts the value or the attempts run out; returns the last value.
     * The public Petstore is eventually consistent, so read-after-write checks use this instead of a single GET.
     */
    public static <T> T pollUntil(Supplier<T> action, Predicate<T> done, int attempts, long delayMs) {
        T last = null;
        for (int attempt = 1; attempt <= attempts; attempt++) {
            last = action.get();
            if (done.test(last)) {
                return last;
            }
            if (attempt < attempts) {
                sleep(delayMs);
            }
        }
        return last;
    }

    public static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
