package com.petstore.framework.utils;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public final class DateUtils {

    /** The format used by the Swagger examples, e.g. 2026-11-03T10:15:30.123+0000. */
    private static final DateTimeFormatter API_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

    private DateUtils() {
    }

    public static String nowForApi() {
        return OffsetDateTime.now(ZoneOffset.UTC).format(API_FORMAT);
    }
}
