package com.petstore.framework.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Excel utilities (Apache POI). Row 1 is the header; every following non-empty row becomes a
 * map keyed by header name. Cells are read as displayed text ({@link DataFormatter}) and formulas
 * are evaluated, so {@code 1}, {@code TRUE} and {@code {{randomId}}} all arrive as strings.
 */
public final class ExcelUtils {

    private static final Map<String, List<Map<String, String>>> CACHE = new ConcurrentHashMap<>();

    private ExcelUtils() {
    }

    /** Reads a sheet from the classpath or file system. Returned rows are copies and safe to modify. */
    public static List<Map<String, String>> readSheet(String path, String sheetName) {
        List<Map<String, String>> rows = CACHE.computeIfAbsent(path + "::" + sheetName, key -> loadSheet(path, sheetName));
        List<Map<String, String>> copy = new ArrayList<>();
        for (Map<String, String> row : rows) {
            copy.add(new LinkedHashMap<>(row));
        }
        return copy;
    }

    /** First row whose {@code keyColumn} equals {@code key} (default key column: TestCaseId). */
    public static Map<String, String> findRow(String path, String sheetName, String keyColumn, String key) {
        List<Map<String, String>> rows = readSheet(path, sheetName);
        for (Map<String, String> row : rows) {
            if (key.equals(row.get(keyColumn))) {
                return row;
            }
        }
        List<String> available = new ArrayList<>();
        rows.forEach(row -> available.add(row.get(keyColumn)));
        throw new IllegalArgumentException("No row with " + keyColumn + "=\"" + key + "\" in sheet \"" + sheetName
                + "\" of " + path + ". Available: " + available);
    }

    public static Map<String, String> findRow(String path, String sheetName, String key) {
        return findRow(path, sheetName, "TestCaseId", key);
    }

    /**
     * Writes rows to a sheet of {@code file} (created if missing, sheet replaced if present),
     * e.g. to export an execution summary or generate test data.
     */
    public static void writeSheet(Path file, String sheetName, List<Map<String, String>> rows) {
        try {
            Workbook workbook;
            if (Files.exists(file)) {
                try (InputStream in = Files.newInputStream(file)) {
                    workbook = WorkbookFactory.create(in);
                }
            } else {
                workbook = new XSSFWorkbook();
            }
            try (Workbook wb = workbook) {
                int existing = wb.getSheetIndex(sheetName);
                if (existing >= 0) {
                    wb.removeSheetAt(existing);
                }
                Sheet sheet = wb.createSheet(sheetName);

                Set<String> columns = new LinkedHashSet<>();
                rows.forEach(row -> columns.addAll(row.keySet()));

                Font bold = wb.createFont();
                bold.setBold(true);
                CellStyle headerStyle = wb.createCellStyle();
                headerStyle.setFont(bold);

                Row header = sheet.createRow(0);
                int column = 0;
                for (String name : columns) {
                    Cell cell = header.createCell(column++);
                    cell.setCellValue(name);
                    cell.setCellStyle(headerStyle);
                }
                int rowIndex = 1;
                for (Map<String, String> data : rows) {
                    Row row = sheet.createRow(rowIndex++);
                    column = 0;
                    for (String name : columns) {
                        row.createCell(column++).setCellValue(data.getOrDefault(name, ""));
                    }
                }
                for (int i = 0; i < columns.size(); i++) {
                    sheet.autoSizeColumn(i);
                }
                if (file.getParent() != null) {
                    Files.createDirectories(file.getParent());
                }
                try (OutputStream out = Files.newOutputStream(file)) {
                    wb.write(out);
                }
            }
            CACHE.clear();
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to write Excel file " + file, e);
        }
    }

    private static List<Map<String, String>> loadSheet(String path, String sheetName) {
        try (InputStream in = ResourceUtils.open(path); Workbook workbook = WorkbookFactory.create(in)) {
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                List<String> names = new ArrayList<>();
                workbook.forEach(s -> names.add(s.getSheetName()));
                throw new IllegalArgumentException("Sheet \"" + sheetName + "\" not found in " + path + ". Available: " + names);
            }
            DataFormatter formatter = new DataFormatter();
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                return Collections.emptyList();
            }
            List<String> headers = new ArrayList<>();
            for (int c = 0; c < headerRow.getLastCellNum(); c++) {
                headers.add(read(formatter, evaluator, headerRow.getCell(c)));
            }

            List<Map<String, String>> rows = new ArrayList<>();
            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) {
                    continue;
                }
                Map<String, String> record = new LinkedHashMap<>();
                boolean hasValue = false;
                for (int c = 0; c < headers.size(); c++) {
                    if (headers.get(c).isEmpty()) {
                        continue;
                    }
                    String value = read(formatter, evaluator, row.getCell(c));
                    hasValue |= !value.isEmpty();
                    record.put(headers.get(c), value);
                }
                if (hasValue) {
                    rows.add(record);
                }
            }
            return rows;
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to read Excel file " + path, e);
        }
    }

    private static String read(DataFormatter formatter, FormulaEvaluator evaluator, Cell cell) {
        return cell == null ? "" : formatter.formatCellValue(cell, evaluator).trim();
    }
}
