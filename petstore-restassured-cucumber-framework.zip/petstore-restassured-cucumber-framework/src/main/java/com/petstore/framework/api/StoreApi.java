package com.petstore.framework.api;

import com.petstore.framework.config.ConfigManager;
import com.petstore.framework.constants.Endpoints;
import com.petstore.framework.core.RestClient;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.response.Response;

/** Swagger tag {@code store} - 4 operations. */
public class StoreApi extends BaseApi {

    public StoreApi(RestClient client) {
        super(client);
    }

    /** GET /store/inventory - requires the api_key header. */
    public Response getInventory() {
        return getInventory(ConfigManager.getInstance().apiKey());
    }

    public Response getInventory(String apiKey) {
        return client.sendWith(Method.GET, Endpoints.STORE_INVENTORY, spec -> spec.header("api_key", apiKey));
    }

    /** POST /store/order */
    public Response placeOrder(Object order) {
        return client.sendWith(Method.POST, Endpoints.STORE_ORDER, spec -> spec.contentType(ContentType.JSON).body(order));
    }

    /** GET /store/order/{orderId} */
    public Response getOrderById(Object orderId) {
        return client.send(Method.GET, Endpoints.STORE_ORDER_BY_ID, orderId);
    }

    /** DELETE /store/order/{orderId} */
    public Response deleteOrder(Object orderId) {
        return client.send(Method.DELETE, Endpoints.STORE_ORDER_BY_ID, orderId);
    }
}
