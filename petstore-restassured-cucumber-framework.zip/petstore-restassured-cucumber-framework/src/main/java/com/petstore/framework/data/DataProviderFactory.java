package com.petstore.framework.data;

import java.util.Locale;

/** Factory + Strategy selector: {@code json} or {@code excel}. Register new sources (CSV, DB, ...) here. */
public final class DataProviderFactory {

    private DataProviderFactory() {
    }

    public static TestDataProvider create(String source) {
        switch (source.trim().toLowerCase(Locale.ROOT)) {
            case "json":
                return new JsonDataProvider();
            case "excel":
            case "xlsx":
                return new ExcelDataProvider();
            default:
                throw new IllegalArgumentException("Unsupported data source \"" + source + "\". Use \"json\" or \"excel\".");
        }
    }
}
