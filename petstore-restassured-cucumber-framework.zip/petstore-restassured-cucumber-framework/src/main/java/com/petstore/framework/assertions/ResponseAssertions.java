package com.petstore.framework.assertions;

import com.fasterxml.jackson.databind.JsonNode;
import com.petstore.framework.utils.JsonUtils;
import com.petstore.framework.utils.TextUtils;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import java.util.List;
import org.assertj.core.api.Assertions;

/** Fluent response assertions shared by every feature. Every failure message carries the call summary and body. */
public final class ResponseAssertions {

    private final Response response;

    private ResponseAssertions(Response response) {
        this.response = response;
    }

    public static ResponseAssertions assertThat(Response response) {
        return new ResponseAssertions(response);
    }

    public ResponseAssertions hasStatus(int expected) {
        Assertions.assertThat(response.statusCode()).as(describe()).isEqualTo(expected);
        return this;
    }

    public ResponseAssertions hasStatusIn(String csv) {
        List<Integer> allowed = TextUtils.splitCsv(csv).stream().map(Integer::parseInt).toList();
        Assertions.assertThat(response.statusCode()).as(describe()).isIn(allowed);
        return this;
    }

    public ResponseAssertions bodyFieldEquals(String path, String expected) {
        Object actual = response.jsonPath().get(path);
        Assertions.assertThat(String.valueOf(actual)).as("Body field \"%s\" - %s", path, describe()).isEqualTo(expected);
        return this;
    }

    public ResponseAssertions bodyFieldExists(String path) {
        Object actual = response.jsonPath().get(path);
        Assertions.assertThat(actual).as("Body field \"%s\" should exist - %s", path, describe()).isNotNull();
        return this;
    }

    public ResponseAssertions messageContains(String text) {
        String message = response.jsonPath().getString("message");
        Assertions.assertThat(message).as(describe()).contains(text);
        return this;
    }

    public ResponseAssertions isJsonArray() {
        JsonNode body = JsonUtils.parse(response.asString());
        Assertions.assertThat(body.isArray()).as("Expected a JSON array - %s", describe()).isTrue();
        return this;
    }

    public ResponseAssertions hasHeader(String name) {
        Assertions.assertThat(response.getHeaders().hasHeaderWithName(name)).as("Header \"%s\" should be present - %s", name, describe()).isTrue();
        return this;
    }

    public ResponseAssertions respondedWithin(long maxMillis) {
        Assertions.assertThat(response.time()).as(describe()).isLessThan(maxMillis);
        return this;
    }

    /** Validates the body against {@code schemas/<name>.schema.json} on the classpath. */
    public ResponseAssertions matchesSchema(String name) {
        response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/" + name + ".schema.json"));
        return this;
    }

    private String describe() {
        return response.getStatusLine() + " (" + response.time() + " ms)\n" + TextUtils.truncate(response.asString(), 2000);
    }
}
