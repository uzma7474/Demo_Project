package com.petstore.framework.core;

import com.petstore.framework.config.ConfigManager;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.filter.Filter;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

/** Factory for the base request specification shared by every API object. */
public final class RequestSpecFactory {

    private RequestSpecFactory() {
    }

    public static RequestSpecification create(Filter... filters) {
        ConfigManager config = ConfigManager.getInstance();
        int timeout = config.timeoutMs();

        RequestSpecBuilder builder = new RequestSpecBuilder()
                .setBaseUri(config.baseUri())
                .setBasePath(config.basePath())
                // Content-Type is deliberately NOT set globally: each API method sets json / form / multipart itself.
                .setAccept(ContentType.JSON)
                .setConfig(RestAssuredConfig.config().httpClient(HttpClientConfig.httpClientConfig()
                        .setParam("http.connection.timeout", timeout)
                        .setParam("http.socket.timeout", timeout)));

        if (config.getBoolean("relaxed.https")) {
            builder.setRelaxedHTTPSValidation();
        }
        for (Filter filter : filters) {
            builder.addFilter(filter);
        }
        return builder.build();
    }
}
