package com.petstore.framework.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Properties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Singleton configuration. Lookup order: JVM system property, environment variable
 * (dots become underscores, upper case), then {@code config-<env>.properties} over {@code config.properties}.
 */
public final class ConfigManager {

    private static final Logger LOG = LogManager.getLogger(ConfigManager.class);
    private static final ConfigManager INSTANCE = new ConfigManager();

    private final Properties properties = new Properties();
    private final String environment;

    private ConfigManager() {
        load("config/config.properties", true);
        this.environment = lookup("env") == null ? "prod" : lookup("env").trim().toLowerCase(Locale.ROOT);
        load("config/config-" + environment + ".properties", false);
        LOG.info("Configuration loaded: env={}, baseUri={}{}", environment, get("base.uri"), get("base.path"));
    }

    public static ConfigManager getInstance() {
        return INSTANCE;
    }

    public String environment() {
        return environment;
    }

    public String get(String key) {
        String value = lookup(key);
        if (value == null) {
            throw new IllegalStateException("Missing configuration key: " + key);
        }
        return value.trim();
    }

    public String get(String key, String defaultValue) {
        String value = lookup(key);
        return value == null || value.isBlank() ? defaultValue : value.trim();
    }

    public int getInt(String key) {
        return Integer.parseInt(get(key));
    }

    public boolean getBoolean(String key) {
        return Boolean.parseBoolean(get(key));
    }

    public String baseUri() {
        return get("base.uri");
    }

    public String basePath() {
        return get("base.path");
    }

    public String apiKey() {
        return get("api.key");
    }

    public int timeoutMs() {
        return getInt("request.timeout.ms");
    }

    public int retryCount() {
        return getInt("retry.count");
    }

    public int retryDelayMs() {
        return getInt("retry.delay.ms");
    }

    public long maxResponseTimeMs() {
        return Long.parseLong(get("max.response.time.ms"));
    }

    public String dataSource() {
        return get("data.source", "json");
    }

    private String lookup(String key) {
        String fromSystem = System.getProperty(key);
        if (fromSystem != null && !fromSystem.isBlank()) {
            return fromSystem;
        }
        String fromEnv = System.getenv(key.toUpperCase(Locale.ROOT).replace('.', '_'));
        if (fromEnv != null && !fromEnv.isBlank()) {
            return fromEnv;
        }
        return properties.getProperty(key);
    }

    private void load(String resource, boolean mandatory) {
        try (InputStream in = ConfigManager.class.getClassLoader().getResourceAsStream(resource)) {
            if (in == null) {
                if (mandatory) {
                    throw new IllegalStateException("Configuration file not found on classpath: " + resource);
                }
                LOG.warn("Optional configuration file not found: {}", resource);
                return;
            }
            properties.load(in);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to read configuration file " + resource, e);
        }
    }
}
