package com.petstore.framework.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import io.restassured.path.json.JsonPath;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * JSON utilities: read test data from the classpath / file system, resolve placeholders,
 * (de)serialise POJOs and navigate response bodies with a path such as {@code tags[0].name}.
 */
public final class JsonUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .configure(SerializationFeature.INDENT_OUTPUT, false);

    private JsonUtils() {
    }

    public static ObjectMapper mapper() {
        return MAPPER;
    }

    public static JsonNode readTree(String path) {
        try (InputStream in = ResourceUtils.open(path)) {
            return MAPPER.readTree(in);
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to read JSON file " + path, e);
        }
    }

    public static <T> T read(String path, Class<T> type) {
        return treeToValue(readTree(path), type);
    }

    /**
     * Reads one named record from a file shaped like {@code { "KEY": { ... }, ... }},
     * resolves {{placeholders}} and converts it to {@code type}.
     */
    public static <T> T readRecord(String path, String key, Class<T> type) {
        JsonNode root = readTree(path);
        if (!root.has(key)) {
            StringBuilder available = new StringBuilder();
            root.fieldNames().forEachRemaining(name -> available.append(available.length() == 0 ? "" : ", ").append(name));
            throw new IllegalArgumentException("Key \"" + key + "\" not found in " + path + ". Available: " + available);
        }
        return treeToValue(DataResolver.resolve(root.get(key).deepCopy()), type);
    }

    public static JsonNode parse(String json) {
        try {
            return MAPPER.readTree(json);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Not valid JSON: " + TextUtils.truncate(json, 300), e);
        }
    }

    public static <T> T fromJson(String json, Class<T> type) {
        try {
            return MAPPER.readValue(json, type);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Cannot map JSON to " + type.getSimpleName() + ": " + TextUtils.truncate(json, 300), e);
        }
    }

    public static <T> T treeToValue(JsonNode node, Class<T> type) {
        try {
            return MAPPER.treeToValue(node, type);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Cannot map JSON to " + type.getSimpleName() + ": " + node, e);
        }
    }

    public static String toJson(Object value) {
        try {
            return MAPPER.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Cannot serialise " + value, e);
        }
    }

    public static String toPrettyJson(Object value) {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Cannot serialise " + value, e);
        }
    }

    public static void write(Path file, Object value) {
        try {
            if (file.getParent() != null) {
                Files.createDirectories(file.getParent());
            }
            Files.writeString(file, toPrettyJson(value));
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to write " + file, e);
        }
    }

    /** Reads a value with dot / bracket notation ({@code category.name}, {@code tags[0].name}); null when absent. */
    public static Object getByPath(String json, String path) {
        return JsonPath.from(json).get(path);
    }
}
