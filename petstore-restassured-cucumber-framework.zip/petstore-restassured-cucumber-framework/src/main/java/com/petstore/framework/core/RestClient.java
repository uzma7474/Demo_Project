package com.petstore.framework.core;

import com.petstore.framework.config.ConfigManager;
import com.petstore.framework.logging.ExchangeLogFilter;
import com.petstore.framework.utils.RetryUtils;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Thin HTTP client around REST Assured. One instance per scenario. Adds what every API object needs:
 * the shared base spec, exchange logging and safe retries for idempotent reads (GET on 502/503/504 or network errors).
 */
public class RestClient {

    private static final Logger LOG = LogManager.getLogger(RestClient.class);
    private static final Set<Integer> RETRYABLE_STATUS = Set.of(502, 503, 504);

    private final ConfigManager config = ConfigManager.getInstance();
    private final ExchangeLogFilter logFilter = new ExchangeLogFilter();
    private final RequestSpecification baseSpec = RequestSpecFactory.create(logFilter);

    /** Sends a request with no customisation; {@code pathParams} fill the {placeholders} of the path in order. */
    public Response send(Method method, String path, Object... pathParams) {
        return sendWith(method, path, spec -> { }, pathParams);
    }

    /** Sends a request after letting {@code customizer} add headers, query/form params, body, multipart parts... */
    public Response sendWith(Method method, String path, Consumer<RequestSpecification> customizer, Object... pathParams) {
        int attempts = method == Method.GET ? config.retryCount() + 1 : 1;
        RuntimeException lastError = null;

        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                RequestSpecification spec = RestAssured.given().spec(baseSpec);
                customizer.accept(spec);
                Response response = spec.request(method, path, pathParams);
                if (attempt < attempts && RETRYABLE_STATUS.contains(response.statusCode())) {
                    LOG.warn("{} {} returned {}; retry {}/{}", method, path, response.statusCode(), attempt, attempts - 1);
                    RetryUtils.sleep((long) config.retryDelayMs() * attempt);
                    continue;
                }
                return response;
            } catch (RuntimeException e) {
                lastError = e;
                if (attempt >= attempts) {
                    throw e;
                }
                LOG.warn("{} {} failed ({}); retry {}/{}", method, path, e.toString(), attempt, attempts - 1);
                RetryUtils.sleep((long) config.retryDelayMs() * attempt);
            }
        }
        throw lastError != null ? lastError : new IllegalStateException("Request was not executed: " + method + " " + path);
    }

    /** Formatted request/response pairs of every call made through this client. */
    public List<String> exchanges() {
        return logFilter.exchanges();
    }
}
