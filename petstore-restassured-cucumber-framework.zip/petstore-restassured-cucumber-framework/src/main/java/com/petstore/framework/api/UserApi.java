package com.petstore.framework.api;

import com.petstore.framework.constants.Endpoints;
import com.petstore.framework.core.RestClient;
import com.petstore.framework.models.User;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.response.Response;
import java.util.List;

/** Swagger tag {@code user} - 8 operations. */
public class UserApi extends BaseApi {

    public UserApi(RestClient client) {
        super(client);
    }

    /** POST /user */
    public Response createUser(Object user) {
        return client.sendWith(Method.POST, Endpoints.USER, spec -> spec.contentType(ContentType.JSON).body(user));
    }

    /** POST /user/createWithArray */
    public Response createWithArray(List<User> users) {
        return client.sendWith(Method.POST, Endpoints.USER_CREATE_WITH_ARRAY, spec -> spec.contentType(ContentType.JSON).body(users));
    }

    /** POST /user/createWithList */
    public Response createWithList(List<User> users) {
        return client.sendWith(Method.POST, Endpoints.USER_CREATE_WITH_LIST, spec -> spec.contentType(ContentType.JSON).body(users));
    }

    /** GET /user/login?username=&password= */
    public Response login(String username, String password) {
        return client.sendWith(Method.GET, Endpoints.USER_LOGIN,
                spec -> spec.queryParam("username", username).queryParam("password", password));
    }

    /** GET /user/logout */
    public Response logout() {
        return client.send(Method.GET, Endpoints.USER_LOGOUT);
    }

    /** GET /user/{username} */
    public Response getUser(String username) {
        return client.send(Method.GET, Endpoints.USER_BY_NAME, username);
    }

    /** PUT /user/{username} */
    public Response updateUser(String username, Object user) {
        return client.sendWith(Method.PUT, Endpoints.USER_BY_NAME, spec -> spec.contentType(ContentType.JSON).body(user), username);
    }

    /** DELETE /user/{username} */
    public Response deleteUser(String username) {
        return client.send(Method.DELETE, Endpoints.USER_BY_NAME, username);
    }
}
