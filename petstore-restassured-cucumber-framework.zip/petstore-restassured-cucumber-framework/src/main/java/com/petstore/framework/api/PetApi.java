package com.petstore.framework.api;

import com.petstore.framework.config.ConfigManager;
import com.petstore.framework.constants.Endpoints;
import com.petstore.framework.core.RestClient;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.response.Response;
import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Swagger tag {@code pet} - 8 operations. */
public class PetApi extends BaseApi {

    private static final Map<String, String> MIME_TYPES = Map.of(
            "png", "image/png",
            "jpg", "image/jpeg",
            "jpeg", "image/jpeg",
            "gif", "image/gif",
            "txt", "text/plain");

    public PetApi(RestClient client) {
        super(client);
    }

    /** POST /pet - accepts a Pet or any payload (for negative tests). */
    public Response addPet(Object pet) {
        return client.sendWith(Method.POST, Endpoints.PET, spec -> spec.contentType(ContentType.JSON).body(pet));
    }

    /** POST /pet with a hand-written body, e.g. malformed JSON (a String body is sent exactly as given). */
    public Response addPetRaw(String rawBody) {
        return client.sendWith(Method.POST, Endpoints.PET, spec -> spec.contentType(ContentType.JSON).body(rawBody));
    }

    /** PUT /pet */
    public Response updatePet(Object pet) {
        return client.sendWith(Method.PUT, Endpoints.PET, spec -> spec.contentType(ContentType.JSON).body(pet));
    }

    /** GET /pet/findByStatus?status=a&status=b */
    public Response findByStatus(List<String> statuses) {
        return client.sendWith(Method.GET, Endpoints.PET_FIND_BY_STATUS, spec -> spec.queryParam("status", statuses));
    }

    /** GET /pet/findByTags?tags=a&tags=b (deprecated in the spec, still served). */
    public Response findByTags(List<String> tags) {
        return client.sendWith(Method.GET, Endpoints.PET_FIND_BY_TAGS, spec -> spec.queryParam("tags", tags));
    }

    /** GET /pet/{petId} */
    public Response getPetById(Object petId) {
        return client.send(Method.GET, Endpoints.PET_BY_ID, petId);
    }

    /** POST /pet/{petId} - application/x-www-form-urlencoded */
    public Response updatePetWithForm(Object petId, String name, String status) {
        return client.sendWith(Method.POST, Endpoints.PET_BY_ID, spec -> {
            spec.contentType(ContentType.URLENC);
            if (name != null) {
                spec.formParam("name", name);
            }
            if (status != null) {
                spec.formParam("status", status);
            }
        }, petId);
    }

    /** DELETE /pet/{petId} - sends the optional api_key header. */
    public Response deletePet(Object petId) {
        return deletePet(petId, ConfigManager.getInstance().apiKey());
    }

    public Response deletePet(Object petId, String apiKey) {
        return client.sendWith(Method.DELETE, Endpoints.PET_BY_ID, spec -> spec.header("api_key", apiKey), petId);
    }

    /** POST /pet/{petId}/uploadImage - multipart/form-data */
    public Response uploadImage(Object petId, File file, String additionalMetadata) {
        return client.sendWith(Method.POST, Endpoints.PET_UPLOAD_IMAGE, spec -> {
            spec.contentType(ContentType.MULTIPART);
            if (additionalMetadata != null) {
                spec.multiPart("additionalMetadata", additionalMetadata);
            }
            spec.multiPart("file", file, mimeTypeOf(file));
        }, petId);
    }

    private static String mimeTypeOf(File file) {
        String name = file.getName().toLowerCase(Locale.ROOT);
        String extension = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1) : "";
        return MIME_TYPES.getOrDefault(extension, "application/octet-stream");
    }
}
