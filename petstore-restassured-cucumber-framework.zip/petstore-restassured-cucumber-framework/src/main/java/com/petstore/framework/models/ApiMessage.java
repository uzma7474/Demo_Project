package com.petstore.framework.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** The generic Swagger {@code ApiResponse} returned by most write operations. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApiMessage {

    private Integer code;
    private String type;
    private String message;

    public Integer getCode() { return code; }
    public void setCode(Integer code) { this.code = code; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
