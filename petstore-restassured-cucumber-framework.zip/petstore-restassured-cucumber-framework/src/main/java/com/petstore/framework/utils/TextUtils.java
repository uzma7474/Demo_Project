package com.petstore.framework.utils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public final class TextUtils {

    private TextUtils() {
    }

    /** "a, b,,c" -> [a, b, c] */
    public static List<String> splitCsv(String csv) {
        return split(csv, ",");
    }

    public static List<String> split(String text, String separator) {
        if (text == null || text.isBlank()) {
            return List.of();
        }
        return Arrays.stream(text.split(java.util.regex.Pattern.quote(separator)))
                .map(String::trim)
                .filter(part -> !part.isEmpty())
                .collect(Collectors.toList());
    }

    public static boolean isBlank(String text) {
        return text == null || text.isBlank();
    }

    public static String truncate(String text, int max) {
        if (text == null || text.length() <= max) {
            return text;
        }
        return text.substring(0, max) + "... [truncated " + (text.length() - max) + " chars]";
    }
}
