package com.petstore.framework.data;

import com.petstore.framework.config.ConfigManager;
import com.petstore.framework.models.Order;
import com.petstore.framework.models.Pet;
import com.petstore.framework.models.User;
import com.petstore.framework.utils.DataResolver;
import com.petstore.framework.utils.ExcelUtils;
import com.petstore.framework.utils.JsonUtils;

/** Reads sheets {@code Pets}, {@code Users} and {@code Orders} of the configured workbook (key column: TestCaseId). */
public class ExcelDataProvider implements TestDataProvider {

    private final String workbook = ConfigManager.getInstance().get("excel.file", "testdata/excel/petstore-data.xlsx");

    @Override
    public String name() {
        return "excel";
    }

    @Override
    public Pet getPet(String key) {
        return JsonUtils.treeToValue(DataResolver.resolve(ExcelMapper.pet(ExcelUtils.findRow(workbook, "Pets", key))), Pet.class);
    }

    @Override
    public User getUser(String key) {
        return JsonUtils.treeToValue(DataResolver.resolve(ExcelMapper.user(ExcelUtils.findRow(workbook, "Users", key))), User.class);
    }

    @Override
    public Order getOrder(String key) {
        return JsonUtils.treeToValue(DataResolver.resolve(ExcelMapper.order(ExcelUtils.findRow(workbook, "Orders", key))), Order.class);
    }
}
