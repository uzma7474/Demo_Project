package com.petstore.framework.data;

import com.petstore.framework.config.ConfigManager;
import com.petstore.framework.models.Order;
import com.petstore.framework.models.Pet;
import com.petstore.framework.models.User;
import com.petstore.framework.utils.JsonUtils;

/** Reads {@code <json.dir>/pets.json}, {@code users.json}, {@code orders.json} (objects keyed by test-case id). */
public class JsonDataProvider implements TestDataProvider {

    private final String directory = ConfigManager.getInstance().get("json.dir", "testdata/json");

    @Override
    public String name() {
        return "json";
    }

    @Override
    public Pet getPet(String key) {
        return JsonUtils.readRecord(directory + "/pets.json", key, Pet.class);
    }

    @Override
    public User getUser(String key) {
        return JsonUtils.readRecord(directory + "/users.json", key, User.class);
    }

    @Override
    public Order getOrder(String key) {
        return JsonUtils.readRecord(directory + "/orders.json", key, Order.class);
    }
}
