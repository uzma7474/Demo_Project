package com.petstore.framework.api;

import com.petstore.framework.core.RestClient;

/**
 * Base of the API Object Model - the REST twin of a Selenium BasePage. Each subclass models one Swagger tag
 * (pet, store, user); each public method models one operation and returns the raw {@code Response}.
 * API objects contain NO assertions and NO test data - that is what keeps them reusable.
 */
public abstract class BaseApi {

    protected final RestClient client;

    protected BaseApi(RestClient client) {
        this.client = client;
    }
}
