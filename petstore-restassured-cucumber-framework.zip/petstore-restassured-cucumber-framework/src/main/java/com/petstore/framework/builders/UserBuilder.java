package com.petstore.framework.builders;

import com.petstore.framework.models.User;
import com.petstore.framework.utils.RandomUtils;

public final class UserBuilder {

    private final User user = new User();

    private UserBuilder() {
        user.setId(RandomUtils.id());
        user.setUsername(RandomUtils.string("user"));
        user.setFirstName("Test");
        user.setLastName("User");
        user.setEmail(RandomUtils.email("test"));
        user.setPassword("Passw0rd!");
        user.setPhone("9876543210");
        user.setUserStatus(1);
    }

    public static UserBuilder aUser() {
        return new UserBuilder();
    }

    public UserBuilder withId(long id) {
        user.setId(id);
        return this;
    }

    public UserBuilder withUsername(String username) {
        user.setUsername(username);
        return this;
    }

    public UserBuilder withName(String firstName, String lastName) {
        user.setFirstName(firstName);
        user.setLastName(lastName);
        return this;
    }

    public UserBuilder withEmail(String email) {
        user.setEmail(email);
        return this;
    }

    public UserBuilder withPassword(String password) {
        user.setPassword(password);
        return this;
    }

    public User build() {
        return user;
    }
}
