package com.petstore.framework.builders;

import com.petstore.framework.models.Category;
import com.petstore.framework.models.Pet;
import com.petstore.framework.models.PetStatus;
import com.petstore.framework.models.Tag;
import com.petstore.framework.utils.RandomUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Builder: valid-by-default Pet payloads with fluent overrides. */
public final class PetBuilder {

    private final Pet pet = new Pet();

    private PetBuilder() {
        pet.setId(RandomUtils.id());
        pet.setCategory(new Category(1L, "Dogs"));
        pet.setName(RandomUtils.string("pet"));
        pet.setPhotoUrls(new ArrayList<>(List.of("https://example.com/photo.jpg")));
        pet.setTags(new ArrayList<>(List.of(new Tag(1L, "automation"))));
        pet.setStatus(PetStatus.AVAILABLE.value());
    }

    public static PetBuilder aPet() {
        return new PetBuilder();
    }

    public PetBuilder withId(long id) {
        pet.setId(id);
        return this;
    }

    public PetBuilder withName(String name) {
        pet.setName(name);
        return this;
    }

    public PetBuilder inCategory(long id, String name) {
        pet.setCategory(new Category(id, name));
        return this;
    }

    public PetBuilder withPhotoUrls(String... urls) {
        pet.setPhotoUrls(new ArrayList<>(Arrays.asList(urls)));
        return this;
    }

    public PetBuilder withTags(String... names) {
        List<Tag> tags = new ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            tags.add(new Tag((long) (i + 1), names[i]));
        }
        pet.setTags(tags);
        return this;
    }

    public PetBuilder withStatus(String status) {
        pet.setStatus(status);
        return this;
    }

    public PetBuilder withStatus(PetStatus status) {
        return withStatus(status.value());
    }

    public Pet build() {
        return pet;
    }
}
