package com.petstore.framework.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Resolves a path against the classpath first, then the file system. */
public final class ResourceUtils {

    private ResourceUtils() {
    }

    public static InputStream open(String path) {
        InputStream stream = ResourceUtils.class.getClassLoader().getResourceAsStream(path);
        if (stream != null) {
            return stream;
        }
        Path file = Path.of(path);
        if (Files.exists(file)) {
            try {
                return Files.newInputStream(file);
            } catch (IOException e) {
                throw new UncheckedIOException("Unable to open " + path, e);
            }
        }
        throw new IllegalArgumentException("Resource not found on classpath or file system: " + path);
    }

    /** Returns a real file (copies classpath resources to a temp directory when needed, e.g. for multipart upload). */
    public static File toFile(String path) {
        Path direct = Path.of(path);
        if (Files.exists(direct)) {
            return direct.toFile();
        }
        try (InputStream in = open(path)) {
            Path copy = Files.createTempDirectory("petstore-data").resolve(direct.getFileName().toString());
            Files.copy(in, copy, StandardCopyOption.REPLACE_EXISTING);
            copy.toFile().deleteOnExit();
            return copy.toFile();
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to materialise " + path, e);
        }
    }
}
