package com.petstore.framework.data;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.petstore.framework.utils.JsonUtils;
import com.petstore.framework.utils.TextUtils;
import java.util.Map;

/**
 * Maps a spreadsheet row to a JSON tree. Values stay text here (placeholders such as {{randomId}} included);
 * {@code DataResolver} resolves them and Jackson coerces "123" to Long / "true" to Boolean afterwards.
 */
public final class ExcelMapper {

    private ExcelMapper() {
    }

    public static ObjectNode pet(Map<String, String> row) {
        ObjectNode node = JsonUtils.mapper().createObjectNode();
        put(node, "id", row.get("Id"));
        put(node, "name", row.get("Name"));
        put(node, "status", row.get("Status"));

        String categoryName = row.get("CategoryName");
        if (!TextUtils.isBlank(categoryName)) {
            ObjectNode category = node.putObject("category");
            put(category, "id", row.get("CategoryId"));
            category.put("name", categoryName);
        }
        ArrayNode photoUrls = node.putArray("photoUrls");
        TextUtils.split(row.get("PhotoUrls"), ";").forEach(photoUrls::add);

        ArrayNode tags = node.putArray("tags");
        int index = 1;
        for (String tagName : TextUtils.split(row.get("Tags"), ";")) {
            ObjectNode tag = tags.addObject();
            tag.put("id", index++);
            tag.put("name", tagName);
        }
        return node;
    }

    public static ObjectNode user(Map<String, String> row) {
        ObjectNode node = JsonUtils.mapper().createObjectNode();
        put(node, "id", row.get("Id"));
        put(node, "username", row.get("Username"));
        put(node, "firstName", row.get("FirstName"));
        put(node, "lastName", row.get("LastName"));
        put(node, "email", row.get("Email"));
        put(node, "password", row.get("Password"));
        put(node, "phone", row.get("Phone"));
        put(node, "userStatus", row.get("UserStatus"));
        return node;
    }

    public static ObjectNode order(Map<String, String> row) {
        ObjectNode node = JsonUtils.mapper().createObjectNode();
        put(node, "id", row.get("Id"));
        put(node, "petId", row.get("PetId"));
        put(node, "quantity", row.get("Quantity"));
        put(node, "shipDate", row.get("ShipDate"));
        put(node, "status", row.get("Status"));
        String complete = row.get("Complete");
        put(node, "complete", complete == null ? null : complete.toLowerCase());
        return node;
    }

    private static void put(ObjectNode node, String field, String value) {
        if (!TextUtils.isBlank(value)) {
            node.put(field, value);
        }
    }
}
