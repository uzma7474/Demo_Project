package com.petstore.framework.data;

import com.petstore.framework.models.Order;
import com.petstore.framework.models.Pet;
import com.petstore.framework.models.User;

/**
 * Strategy interface: a scenario asks for "the pet PET_DOG_AVAILABLE" and does not care whether the
 * record lives in JSON or Excel.
 */
public interface TestDataProvider {

    String name();

    Pet getPet(String key);

    User getUser(String key);

    Order getOrder(String key);
}
