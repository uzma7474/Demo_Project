package com.petstore.framework.utils;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicLong;

/** Keeps generated data unique, so scenarios can run in parallel on the shared public Petstore. */
public final class RandomUtils {

    private static final AtomicLong LAST_ID = new AtomicLong();
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789";

    private RandomUtils() {
    }

    /**
     * A positive int64 id (epoch millis, about 1.7e12). Strictly increasing and thread-safe within one JVM,
     * so parallel scenarios never get the same id, and time-based so separate runs do not collide either.
     */
    public static long id() {
        return LAST_ID.updateAndGet(previous -> Math.max(previous + 1, System.currentTimeMillis()));
    }

    public static int intBetween(int min, int max) {
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

    public static String suffix(int length) {
        StringBuilder builder = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            builder.append(ALPHABET.charAt(ThreadLocalRandom.current().nextInt(ALPHABET.length())));
        }
        return builder.toString();
    }

    public static String string(String prefix) {
        return prefix + "_" + suffix(6);
    }

    public static String email(String localPart) {
        return localPart + "." + suffix(6) + "@example.com";
    }
}
