import { expect as baseExpect } from '@playwright/test';
import { ApiResult } from '../core/ApiResult';
import { JsonReader } from '../utils/JsonReader';
import { SchemaValidator } from '../utils/SchemaValidator';

const preview = (result: ApiResult): string => `${result.summary()}\n${result.rawBody.slice(0, 600)}`;

/**
 * `expect` extended with API-specific matchers. Every failure message carries the call summary and the
 * start of the response body, so a red test explains itself without opening the trace.
 *
 *   expect(result).toHaveStatus(200)
 *   expect(result).toHaveStatusIn([400, 405])
 *   expect(result).toHaveBodyField('category.name', 'Dogs')
 *   expect(result).toHaveBodyField('id')                    // only checks presence
 *   expect(result).toHaveHeader('x-rate-limit')
 *   expect(result).toRespondWithin(2000)
 *   expect(result).toMatchSchema('pet')
 *   expect(result).toBeJsonArray()
 */
export const expect = baseExpect.extend({
  toHaveStatus(received: ApiResult, expected: number) {
    const pass = received.status === expected;
    return {
      pass,
      name: 'toHaveStatus',
      expected,
      actual: received.status,
      message: () =>
        `Expected status ${this.isNot ? 'not ' : ''}${expected} but received ${received.status}\n${preview(received)}`,
    };
  },

  toHaveStatusIn(received: ApiResult, allowed: number[]) {
    const pass = allowed.includes(received.status);
    return {
      pass,
      name: 'toHaveStatusIn',
      expected: allowed,
      actual: received.status,
      message: () => `Expected status ${this.isNot ? 'not ' : ''}in [${allowed.join(', ')}] but received ${received.status}\n${preview(received)}`,
    };
  },

  /** With one argument: the JSON path must exist. With two: its value (compared as text) must equal `expected`. */
  toHaveBodyField(received: ApiResult, path: string, expected?: unknown) {
    const actual = JsonReader.getByPath(received.json(), path);
    const pass = expected === undefined ? actual !== undefined && actual !== null : String(actual) === String(expected);
    return {
      pass,
      name: 'toHaveBodyField',
      expected,
      actual,
      message: () =>
        expected === undefined
          ? `Expected body field "${path}" ${this.isNot ? 'not ' : ''}to exist\n${preview(received)}`
          : `Expected body field "${path}" ${this.isNot ? 'not ' : ''}to equal ${JSON.stringify(expected)} but received ${JSON.stringify(actual)}\n${preview(received)}`,
    };
  },

  toHaveHeader(received: ApiResult, name: string) {
    const pass = received.header(name) !== undefined;
    return {
      pass,
      name: 'toHaveHeader',
      message: () => `Expected header "${name}" ${this.isNot ? 'not ' : ''}to be present\n${preview(received)}`,
    };
  },

  toRespondWithin(received: ApiResult, maxMs: number) {
    const pass = received.durationMs < maxMs;
    return {
      pass,
      name: 'toRespondWithin',
      expected: maxMs,
      actual: received.durationMs,
      message: () => `Expected response within ${maxMs} ms but it took ${received.durationMs} ms\n${received.summary()}`,
    };
  },

  /** Validates the body against `src/schemas/<name>.schema.json`. */
  toMatchSchema(received: ApiResult, schemaName: string) {
    const body = received.json();
    const errors = body === undefined ? ['response body is not JSON'] : SchemaValidator.validate(body, SchemaValidator.load(schemaName));
    return {
      pass: errors.length === 0,
      name: 'toMatchSchema',
      message: () =>
        errors.length === 0
          ? `Expected body not to match schema "${schemaName}"`
          : `Body violates schema "${schemaName}":\n  - ${errors.join('\n  - ')}\n${preview(received)}`,
    };
  },

  toBeJsonArray(received: ApiResult) {
    const pass = Array.isArray(received.json());
    return {
      pass,
      name: 'toBeJsonArray',
      message: () => `Expected the response body ${this.isNot ? 'not ' : ''}to be a JSON array\n${preview(received)}`,
    };
  },
});
