import { ExcelDataProvider } from './ExcelDataProvider';
import { JsonDataProvider } from './JsonDataProvider';
import { TestDataProvider } from './TestDataProvider';

/** Factory + Strategy selector: `json` or `excel`. Register new sources (CSV, DB, ...) here. */
export class DataProviderFactory {
  static create(source: string): TestDataProvider {
    switch (source.trim().toLowerCase()) {
      case 'json':
        return new JsonDataProvider();
      case 'excel':
      case 'xlsx':
        return new ExcelDataProvider();
      default:
        throw new Error(`Unsupported data source "${source}". Use "json" or "excel".`);
    }
  }
}
