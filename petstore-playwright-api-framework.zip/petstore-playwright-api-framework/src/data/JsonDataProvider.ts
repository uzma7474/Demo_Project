import { Order } from '../models/Order';
import { Pet } from '../models/Pet';
import { User } from '../models/User';
import { DataResolver } from '../utils/DataResolver';
import { JsonReader } from '../utils/JsonReader';
import { TestDataProvider } from './TestDataProvider';

/** Reads `test-data/json/{pets,users,orders}.json` (objects keyed by test-case id). */
export class JsonDataProvider implements TestDataProvider {
  readonly name = 'json';

  async getPet(key: string): Promise<Pet> {
    return DataResolver.resolve(JsonReader.readRecord<Pet>('json/pets.json', key));
  }

  async getUser(key: string): Promise<User> {
    return DataResolver.resolve(JsonReader.readRecord<User>('json/users.json', key));
  }

  async getOrder(key: string): Promise<Order> {
    return DataResolver.resolve(JsonReader.readRecord<Order>('json/orders.json', key));
  }
}
