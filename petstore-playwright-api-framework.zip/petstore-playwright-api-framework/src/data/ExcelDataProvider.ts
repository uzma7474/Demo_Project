import { Order } from '../models/Order';
import { Pet } from '../models/Pet';
import { User } from '../models/User';
import { DataResolver } from '../utils/DataResolver';
import { ExcelReader } from '../utils/ExcelReader';
import { ExcelMapper } from './ExcelMapper';
import { TestDataProvider } from './TestDataProvider';

const WORKBOOK = 'excel/petstore-data.xlsx';

/** Reads sheets `Pets`, `Users` and `Orders` from `test-data/excel/petstore-data.xlsx` (key column: TestCaseId). */
export class ExcelDataProvider implements TestDataProvider {
  readonly name = 'excel';

  async getPet(key: string): Promise<Pet> {
    return DataResolver.resolve(ExcelMapper.toPet(await ExcelReader.findRow(WORKBOOK, 'Pets', key)));
  }

  async getUser(key: string): Promise<User> {
    return DataResolver.resolve(ExcelMapper.toUser(await ExcelReader.findRow(WORKBOOK, 'Users', key)));
  }

  async getOrder(key: string): Promise<Order> {
    return DataResolver.resolve(ExcelMapper.toOrder(await ExcelReader.findRow(WORKBOOK, 'Orders', key)));
  }
}
