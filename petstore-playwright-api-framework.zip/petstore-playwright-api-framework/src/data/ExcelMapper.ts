import { Order } from '../models/Order';
import { Pet } from '../models/Pet';
import { User } from '../models/User';
import { ExcelCell, ExcelRow } from '../utils/ExcelReader';

function text(cell: ExcelCell): string | undefined {
  return cell === undefined || cell === '' ? undefined : String(cell);
}

/** Placeholders such as {{randomId}} must stay strings here - DataResolver turns them into numbers later. */
function numberOrToken(cell: ExcelCell): number | string | undefined {
  if (cell === undefined || cell === '') return undefined;
  if (typeof cell === 'number') return cell;
  const asString = String(cell);
  return asString.includes('{{') || Number.isNaN(Number(asString)) ? asString : Number(asString);
}

function list(cell: ExcelCell): string[] {
  return (text(cell) ?? '')
    .split(';')
    .map((item) => item.trim())
    .filter(Boolean);
}

function bool(cell: ExcelCell): boolean | undefined {
  if (cell === undefined || cell === '') return undefined;
  return typeof cell === 'boolean' ? cell : String(cell).toLowerCase() === 'true';
}

/**
 * Maps a spreadsheet row to an API model. The result still contains raw
 * placeholders and is passed through DataResolver by the provider.
 */
export class ExcelMapper {
  static toPet(row: ExcelRow): Pet {
    const categoryName = text(row.CategoryName);
    return {
      id: numberOrToken(row.Id) as number | undefined,
      category: categoryName ? { id: numberOrToken(row.CategoryId) as number | undefined, name: categoryName } : undefined,
      name: text(row.Name) ?? '',
      photoUrls: list(row.PhotoUrls),
      tags: list(row.Tags).map((name, index) => ({ id: index + 1, name })),
      status: text(row.Status),
    };
  }

  static toUser(row: ExcelRow): User {
    return {
      id: numberOrToken(row.Id) as number | undefined,
      username: text(row.Username),
      firstName: text(row.FirstName),
      lastName: text(row.LastName),
      email: text(row.Email),
      password: text(row.Password),
      phone: text(row.Phone),
      userStatus: numberOrToken(row.UserStatus) as number | undefined,
    };
  }

  static toOrder(row: ExcelRow): Order {
    return {
      id: numberOrToken(row.Id) as number | undefined,
      petId: numberOrToken(row.PetId) as number | undefined,
      quantity: numberOrToken(row.Quantity) as number | undefined,
      shipDate: text(row.ShipDate),
      status: text(row.Status),
      complete: bool(row.Complete),
    };
  }
}
