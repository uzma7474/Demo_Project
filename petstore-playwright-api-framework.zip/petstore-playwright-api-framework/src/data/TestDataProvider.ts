import { Order } from '../models/Order';
import { Pet } from '../models/Pet';
import { User } from '../models/User';

/**
 * Strategy interface: a scenario asks for "the pet PET_DOG_AVAILABLE" and does
 * not care whether the record lives in JSON or Excel.
 */
export interface TestDataProvider {
  readonly name: string;
  getPet(key: string): Promise<Pet>;
  getUser(key: string): Promise<User>;
  getOrder(key: string): Promise<Order>;
}
