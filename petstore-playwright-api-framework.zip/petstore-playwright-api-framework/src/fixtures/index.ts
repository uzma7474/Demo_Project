import { test as base } from '@playwright/test';
import { expect } from '../assertions/matchers';
import { Config } from '../config/Config';
import { ApiClient } from '../core/ApiClient';
import { DataProviderFactory } from '../data/DataProviderFactory';
import { TestDataProvider } from '../data/TestDataProvider';
import { PetBuilder } from '../builders/PetBuilder';
import { OrderBuilder } from '../builders/OrderBuilder';
import { UserBuilder } from '../builders/UserBuilder';
import { ServiceFactory, Services } from '../factories/ServiceFactory';
import { Order } from '../models/Order';
import { Pet } from '../models/Pet';
import { User } from '../models/User';

/** Best-effort cleanups registered during a test; run in reverse order after it, while the HTTP client is still alive. */
export class CleanupRegistry {
  private readonly actions: Array<() => Promise<unknown>> = [];

  add(action: () => Promise<unknown>): void {
    this.actions.push(action);
  }

  async run(): Promise<void> {
    for (const action of this.actions.reverse()) {
      try {
        await action();
      } catch (error) {
        console.warn(`[cleanup] ignored failure: ${String(error)}`);
      }
    }
  }
}

/**
 * "Given" helpers: create a precondition through the API, assert it worked and register its cleanup.
 * Pass overrides for the fields the test cares about; everything else is valid-by-default.
 */
export interface Given {
  pet(overrides?: Partial<Pet>): Promise<Pet & { id: number }>;
  order(overrides?: Partial<Order>): Promise<Order & { id: number }>;
  user(overrides?: Partial<User>): Promise<User & { username: string }>;
}

interface Fixtures {
  /** Logging HTTP client bound to Playwright's `request` fixture. */
  client: ApiClient;
  /** Service objects: `api.pet`, `api.store`, `api.user`. */
  api: Services;
  cleanup: CleanupRegistry;
  given: Given;
  /** Test-data provider factory: `data()` uses DATA_SOURCE (default json), `data('excel')` picks one explicitly. */
  data: (source?: string) => TestDataProvider;
  /** Auto fixture: attaches the API conversation to the report (all calls when the test failed, otherwise the last one). */
  diagnostics: void;
}

export const test = base.extend<Fixtures>({
  client: async ({ request }, use) => {
    await use(new ApiClient(request));
  },

  api: async ({ client }, use) => {
    await use(ServiceFactory.create(client));
  },

  // Depends on `api` so it is torn down BEFORE the HTTP client and can still send DELETE calls.
  cleanup: async ({ api }, use) => {
    void api;
    const registry = new CleanupRegistry();
    await use(registry);
    await registry.run();
  },

  given: async ({ api, cleanup }, use) => {
    const given: Given = {
      async pet(overrides = {}) {
        const pet: Pet = { ...PetBuilder.aPet().build(), ...overrides };
        const result = await api.pet.addPet(pet);
        cleanup.add(() => api.pet.deletePet(pet.id as number));
        expect(result, 'precondition: pet could not be created').toHaveStatus(200);
        return pet as Pet & { id: number };
      },
      async order(overrides = {}) {
        const order: Order = { ...OrderBuilder.anOrder().build(), ...overrides };
        const result = await api.store.placeOrder(order);
        cleanup.add(() => api.store.deleteOrder(order.id as number));
        expect(result, 'precondition: order could not be placed').toHaveStatus(200);
        return order as Order & { id: number };
      },
      async user(overrides = {}) {
        const user: User = { ...UserBuilder.aUser().build(), ...overrides };
        const result = await api.user.createUser(user);
        cleanup.add(() => api.user.deleteUser(user.username as string));
        expect(result, 'precondition: user could not be created').toHaveStatus(200);
        return user as User & { username: string };
      },
    };
    await use(given);
  },

  data: async ({}, use) => {
    await use((source?: string) => DataProviderFactory.create(source ?? Config.get().dataSource));
  },

  diagnostics: [
    // Depends on `cleanup`, so it finishes (and snapshots the history) before the cleanup calls run.
    async ({ client, cleanup }, use, testInfo) => {
      void cleanup;
      await use();
      const failed = testInfo.status !== testInfo.expectedStatus;
      const exchanges = failed ? client.history : client.history.slice(-1);
      for (const [index, exchange] of exchanges.entries()) {
        await testInfo.attach(`api-${index + 1}-${exchange.method}-${exchange.status}`, {
          body: exchange.toAttachment(),
          contentType: 'application/json',
        });
      }
    },
    { auto: true },
  ],
});

export { expect };
