import { User } from '../models/User';
import { RandomUtil } from '../utils/RandomUtil';

export class UserBuilder {
  private user: User = {
    id: RandomUtil.id(),
    username: RandomUtil.string('user'),
    firstName: 'Test',
    lastName: 'User',
    email: RandomUtil.email('test'),
    password: 'Passw0rd!',
    phone: '9876543210',
    userStatus: 1,
  };

  static aUser(): UserBuilder {
    return new UserBuilder();
  }

  withId(id: number): this {
    this.user.id = id;
    return this;
  }

  withUsername(username: string): this {
    this.user.username = username;
    return this;
  }

  withName(firstName: string, lastName: string): this {
    this.user.firstName = firstName;
    this.user.lastName = lastName;
    return this;
  }

  withEmail(email: string): this {
    this.user.email = email;
    return this;
  }

  withPassword(password: string): this {
    this.user.password = password;
    return this;
  }

  build(): User {
    return structuredClone(this.user);
  }
}
