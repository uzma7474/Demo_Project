import { Order, OrderStatus } from '../models/Order';
import { RandomUtil } from '../utils/RandomUtil';

export class OrderBuilder {
  private order: Order = {
    id: RandomUtil.id(),
    petId: RandomUtil.id(),
    quantity: 1,
    shipDate: new Date().toISOString(),
    status: OrderStatus.Placed,
    complete: false,
  };

  static anOrder(): OrderBuilder {
    return new OrderBuilder();
  }

  withId(id: number): this {
    this.order.id = id;
    return this;
  }

  forPet(petId: number): this {
    this.order.petId = petId;
    return this;
  }

  withQuantity(quantity: number): this {
    this.order.quantity = quantity;
    return this;
  }

  withStatus(status: OrderStatus | string): this {
    this.order.status = status;
    return this;
  }

  completed(complete = true): this {
    this.order.complete = complete;
    return this;
  }

  build(): Order {
    return structuredClone(this.order);
  }
}
