import { Pet, PetStatus } from '../models/Pet';
import { RandomUtil } from '../utils/RandomUtil';

/** Builder: fluent, valid-by-default Pet payloads. Override only what the scenario cares about. */
export class PetBuilder {
  private pet: Pet = {
    id: RandomUtil.id(),
    category: { id: 1, name: 'Dogs' },
    name: RandomUtil.string('pet'),
    photoUrls: ['https://example.com/photo.jpg'],
    tags: [{ id: 1, name: 'automation' }],
    status: PetStatus.Available,
  };

  static aPet(): PetBuilder {
    return new PetBuilder();
  }

  withId(id: number): this {
    this.pet.id = id;
    return this;
  }

  withName(name: string): this {
    this.pet.name = name;
    return this;
  }

  inCategory(id: number, name: string): this {
    this.pet.category = { id, name };
    return this;
  }

  withPhotoUrls(...urls: string[]): this {
    this.pet.photoUrls = urls;
    return this;
  }

  withTags(...names: string[]): this {
    this.pet.tags = names.map((name, index) => ({ id: index + 1, name }));
    return this;
  }

  withStatus(status: PetStatus | string): this {
    this.pet.status = status;
    return this;
  }

  build(): Pet {
    return structuredClone(this.pet);
  }
}
