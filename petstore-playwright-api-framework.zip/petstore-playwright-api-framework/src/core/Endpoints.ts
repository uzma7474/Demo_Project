/**
 * Single source of truth for every Petstore v2 resource path (relative to
 * baseURL, no leading slash). Services never hard-code paths.
 */
export const Endpoints = {
  pet: {
    base: 'pet',
    byId: (petId: number | string) => `pet/${petId}`,
    findByStatus: 'pet/findByStatus',
    findByTags: 'pet/findByTags',
    uploadImage: (petId: number | string) => `pet/${petId}/uploadImage`,
  },
  store: {
    inventory: 'store/inventory',
    order: 'store/order',
    orderById: (orderId: number | string) => `store/order/${orderId}`,
  },
  user: {
    base: 'user',
    createWithArray: 'user/createWithArray',
    createWithList: 'user/createWithList',
    login: 'user/login',
    logout: 'user/logout',
    byUsername: (username: string) => `user/${encodeURIComponent(username)}`,
  },
} as const;
