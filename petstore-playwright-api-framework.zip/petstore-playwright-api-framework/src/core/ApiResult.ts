export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

export interface ApiResultInit {
  method: HttpMethod;
  url: string;
  status: number;
  statusText: string;
  headers: Record<string, string>;
  rawBody: string;
  durationMs: number;
  requestHeaders?: Record<string, string>;
  requestBody?: string;
}

/**
 * Immutable wrapper around one HTTP exchange. Services return this instead of
 * Playwright's APIResponse so the body is read once and can be inspected any
 * number of times (parsed JSON, raw text, headers, timing).
 */
export class ApiResult {
  readonly method: HttpMethod;
  readonly url: string;
  readonly status: number;
  readonly statusText: string;
  readonly headers: Record<string, string>;
  readonly rawBody: string;
  readonly durationMs: number;
  readonly requestHeaders?: Record<string, string>;
  readonly requestBody?: string;

  private parsed: { value: unknown } | undefined;

  constructor(init: ApiResultInit) {
    this.method = init.method;
    this.url = init.url;
    this.status = init.status;
    this.statusText = init.statusText;
    this.headers = init.headers;
    this.rawBody = init.rawBody;
    this.durationMs = init.durationMs;
    this.requestHeaders = init.requestHeaders;
    this.requestBody = init.requestBody;
  }

  get ok(): boolean {
    return this.status >= 200 && this.status < 300;
  }

  /** Parsed JSON body, or `undefined` when the body is empty or not JSON. */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  json<T = any>(): T | undefined {
    if (!this.parsed) {
      try {
        this.parsed = { value: JSON.parse(this.rawBody) };
      } catch {
        this.parsed = { value: undefined };
      }
    }
    return this.parsed.value as T | undefined;
  }

  /** Case-insensitive header lookup. */
  header(name: string): string | undefined {
    return this.headers[name.toLowerCase()];
  }

  summary(): string {
    return `${this.method} ${this.url} -> ${this.status} ${this.statusText} (${this.durationMs} ms)`;
  }

  /** Pretty JSON used for report attachments and failure diagnostics. */
  toAttachment(): string {
    return JSON.stringify(
      {
        request: {
          method: this.method,
          url: this.url,
          headers: this.requestHeaders,
          body: this.requestBody,
        },
        response: {
          status: this.status,
          statusText: this.statusText,
          durationMs: this.durationMs,
          headers: this.headers,
          body: this.json() ?? this.rawBody,
        },
      },
      null,
      2,
    );
  }
}
