import { APIRequestContext } from '@playwright/test';
import { Config } from '../config/Config';
import { sleep } from '../utils/RetryUtil';
import { ApiResult, HttpMethod } from './ApiResult';
import { Logger } from './Logger';

export interface MultipartFile {
  name: string;
  mimeType: string;
  buffer: Buffer;
}

export interface RequestOptions {
  /** Query string. Use URLSearchParams for repeated keys (e.g. `?status=a&status=b`). */
  params?: Record<string, string | number | boolean> | URLSearchParams;
  headers?: Record<string, string>;
  /** JSON body (objects/arrays). Pass a Buffer to send bytes exactly as given (e.g. malformed JSON). */
  data?: unknown;
  /** application/x-www-form-urlencoded body. */
  form?: Record<string, string | number | boolean>;
  /** multipart/form-data body. */
  multipart?: Record<string, string | number | boolean | MultipartFile>;
  timeoutMs?: number;
}

const RETRYABLE_STATUS = new Set([502, 503, 504]);
const SENSITIVE_HEADERS = ['api_key', 'authorization'];

function maskHeaders(headers?: Record<string, string>): Record<string, string> | undefined {
  if (!headers) return undefined;
  return Object.fromEntries(
    Object.entries(headers).map(([key, value]) => [
      key,
      SENSITIVE_HEADERS.includes(key.toLowerCase()) ? '***' : value,
    ]),
  );
}

function describeBody(options: RequestOptions): string | undefined {
  if (options.data !== undefined) {
    if (Buffer.isBuffer(options.data)) return options.data.toString('utf-8');
    return typeof options.data === 'string' ? options.data : JSON.stringify(options.data);
  }
  if (options.form) return new URLSearchParams(options.form as Record<string, string>).toString();
  if (options.multipart) {
    return JSON.stringify(
      Object.fromEntries(
        Object.entries(options.multipart).map(([key, value]) => [
          key,
          typeof value === 'object' ? `<file ${value.name}, ${value.buffer.length} bytes>` : value,
        ]),
      ),
    );
  }
  return undefined;
}

/**
 * Thin, framework-agnostic HTTP client around Playwright's APIRequestContext.
 * Responsibilities: URL normalisation, timing, logging, safe retries for
 * idempotent reads and a per-instance call history (used for report attachments).
 */
export class ApiClient {
  /** Every exchange performed through this client, in order. */
  readonly history: ApiResult[] = [];

  private readonly config = Config.get();
  private readonly logger = Logger.get();

  constructor(private readonly request: APIRequestContext) {}

  get(endpoint: string, options?: RequestOptions): Promise<ApiResult> {
    return this.send('GET', endpoint, options);
  }

  post(endpoint: string, options?: RequestOptions): Promise<ApiResult> {
    return this.send('POST', endpoint, options);
  }

  put(endpoint: string, options?: RequestOptions): Promise<ApiResult> {
    return this.send('PUT', endpoint, options);
  }

  delete(endpoint: string, options?: RequestOptions): Promise<ApiResult> {
    return this.send('DELETE', endpoint, options);
  }

  async send(method: HttpMethod, endpoint: string, options: RequestOptions = {}): Promise<ApiResult> {
    // baseURL is ".../v2/" - a leading slash would silently drop the "/v2" segment.
    const url = endpoint.replace(/^\/+/, '');
    const maxAttempts = method === 'GET' ? this.config.retryCount + 1 : 1;
    let lastError: unknown;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const result = await this.execute(method, url, options);
        if (RETRYABLE_STATUS.has(result.status) && attempt < maxAttempts) {
          this.logger.warn(`${method} ${url} returned ${result.status}; retry ${attempt}/${maxAttempts - 1}`);
          await sleep(this.config.retryDelayMs * attempt);
          continue;
        }
        return result;
      } catch (error) {
        lastError = error;
        if (attempt >= maxAttempts) break;
        this.logger.warn(`${method} ${url} failed (${String(error)}); retry ${attempt}/${maxAttempts - 1}`);
        await sleep(this.config.retryDelayMs * attempt);
      }
    }
    throw lastError instanceof Error ? lastError : new Error(String(lastError));
  }

  private async execute(method: HttpMethod, url: string, options: RequestOptions): Promise<ApiResult> {
    const startedAt = Date.now();
    const response = await this.request.fetch(url, {
      method,
      params: options.params,
      headers: options.headers,
      data: options.data,
      form: options.form,
      multipart: options.multipart,
      timeout: options.timeoutMs ?? this.config.timeoutMs,
    });
    const rawBody = await response.text();

    const result = new ApiResult({
      method,
      url: response.url(),
      status: response.status(),
      statusText: response.statusText(),
      headers: response.headers(),
      rawBody,
      durationMs: Date.now() - startedAt,
      requestHeaders: maskHeaders(options.headers),
      requestBody: describeBody(options),
    });

    this.history.push(result);
    this.logger.info(result.summary());
    this.logger.debug(result.toAttachment());
    return result;
  }
}
