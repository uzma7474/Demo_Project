import * as fs from 'fs';
import * as path from 'path';
import { Config } from '../config/Config';

type Level = 'debug' | 'info' | 'warn' | 'error';

const WEIGHT: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };

/**
 * Singleton file logger. Everything at or above LOG_LEVEL goes to
 * `logs/api-tests.log`; only warnings and errors are echoed to the console so
 * they do not drown the test runner output.
 */
export class Logger {
  private static instance: Logger | undefined;

  private readonly logFile: string;
  private readonly threshold: number;

  private constructor() {
    const config = Config.get();
    fs.mkdirSync(config.paths.logs, { recursive: true });
    this.logFile = path.join(config.paths.logs, 'api-tests.log');
    this.threshold = WEIGHT[config.logLevel as Level] ?? WEIGHT.info;
  }

  static get(): Logger {
    Logger.instance ??= new Logger();
    return Logger.instance;
  }

  debug(message: string): void {
    this.write('debug', message);
  }

  info(message: string): void {
    this.write('info', message);
  }

  warn(message: string): void {
    this.write('warn', message);
  }

  error(message: string): void {
    this.write('error', message);
  }

  private write(level: Level, message: string): void {
    if (WEIGHT[level] < this.threshold) return;
    const line = `${new Date().toISOString()} [${level.toUpperCase()}] ${message}`;
    fs.appendFileSync(this.logFile, `${line}\n`);
    if (level === 'warn') console.warn(line);
    if (level === 'error') console.error(line);
  }
}
