import * as fs from 'fs';
import * as path from 'path';
import { Config } from '../config/Config';
import { ApiResult } from '../core/ApiResult';
import { Endpoints } from '../core/Endpoints';
import { Pet } from '../models/Pet';
import { BaseService } from './BaseService';

const MIME_TYPES: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.txt': 'text/plain',
};

/** Swagger tag `pet` - 8 operations. */
export class PetService extends BaseService {
  /** POST /pet - accepts a typed Pet or any payload (for negative tests). */
  addPet(pet: Pet | Record<string, unknown>): Promise<ApiResult> {
    return this.client.post(Endpoints.pet.base, { data: pet });
  }

  /**
   * POST /pet with a hand-written body, e.g. malformed JSON.
   * The body is sent as a Buffer on purpose: Playwright re-serialises a *string* body when the
   * content type is JSON, which would silently turn broken JSON into a valid JSON string.
   */
  addPetRaw(rawBody: string): Promise<ApiResult> {
    return this.client.post(Endpoints.pet.base, {
      data: Buffer.from(rawBody, 'utf-8'),
      headers: { 'Content-Type': 'application/json' },
    });
  }

  /** PUT /pet */
  updatePet(pet: Pet | Record<string, unknown>): Promise<ApiResult> {
    return this.client.put(Endpoints.pet.base, { data: pet });
  }

  /** GET /pet/findByStatus?status=a&status=b */
  findByStatus(statuses: string[]): Promise<ApiResult> {
    const params = new URLSearchParams();
    statuses.forEach((status) => params.append('status', status));
    return this.client.get(Endpoints.pet.findByStatus, { params });
  }

  /** GET /pet/findByTags?tags=a&tags=b (deprecated in the spec, still served). */
  findByTags(tags: string[]): Promise<ApiResult> {
    const params = new URLSearchParams();
    tags.forEach((tag) => params.append('tags', tag));
    return this.client.get(Endpoints.pet.findByTags, { params });
  }

  /** GET /pet/{petId} */
  getPetById(petId: number | string): Promise<ApiResult> {
    return this.client.get(Endpoints.pet.byId(petId));
  }

  /** POST /pet/{petId} - application/x-www-form-urlencoded */
  updatePetWithForm(petId: number | string, fields: { name?: string; status?: string }): Promise<ApiResult> {
    const form: Record<string, string> = {};
    if (fields.name !== undefined) form.name = fields.name;
    if (fields.status !== undefined) form.status = fields.status;
    return this.client.post(Endpoints.pet.byId(petId), { form });
  }

  /** DELETE /pet/{petId} - sends the optional api_key header. */
  deletePet(petId: number | string, apiKey: string = Config.get().apiKey): Promise<ApiResult> {
    return this.client.delete(Endpoints.pet.byId(petId), { headers: { api_key: apiKey } });
  }

  /** POST /pet/{petId}/uploadImage - multipart/form-data */
  uploadImage(petId: number | string, filePath: string, additionalMetadata?: string): Promise<ApiResult> {
    const multipart: Record<string, string | { name: string; mimeType: string; buffer: Buffer }> = {
      file: {
        name: path.basename(filePath),
        mimeType: MIME_TYPES[path.extname(filePath).toLowerCase()] ?? 'application/octet-stream',
        buffer: fs.readFileSync(filePath),
      },
    };
    if (additionalMetadata !== undefined) multipart.additionalMetadata = additionalMetadata;
    return this.client.post(Endpoints.pet.uploadImage(petId), { multipart });
  }
}
