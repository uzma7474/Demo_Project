import { ApiClient } from '../core/ApiClient';

/** Base of the Service Object Model: one subclass per Swagger tag (pet, store, user). */
export abstract class BaseService {
  constructor(protected readonly client: ApiClient) {}
}
