import { Config } from '../config/Config';
import { ApiResult } from '../core/ApiResult';
import { Endpoints } from '../core/Endpoints';
import { Order } from '../models/Order';
import { BaseService } from './BaseService';

/** Swagger tag `store` - 4 operations. */
export class StoreService extends BaseService {
  /** GET /store/inventory - requires the api_key header. */
  getInventory(apiKey: string = Config.get().apiKey): Promise<ApiResult> {
    return this.client.get(Endpoints.store.inventory, { headers: { api_key: apiKey } });
  }

  /** POST /store/order */
  placeOrder(order: Order | Record<string, unknown>): Promise<ApiResult> {
    return this.client.post(Endpoints.store.order, { data: order });
  }

  /** GET /store/order/{orderId} */
  getOrderById(orderId: number | string): Promise<ApiResult> {
    return this.client.get(Endpoints.store.orderById(orderId));
  }

  /** DELETE /store/order/{orderId} */
  deleteOrder(orderId: number | string): Promise<ApiResult> {
    return this.client.delete(Endpoints.store.orderById(orderId));
  }
}
