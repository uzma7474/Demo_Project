import { ApiResult } from '../core/ApiResult';
import { Endpoints } from '../core/Endpoints';
import { User } from '../models/User';
import { BaseService } from './BaseService';

/** Swagger tag `user` - 8 operations. */
export class UserService extends BaseService {
  /** POST /user */
  createUser(user: User | Record<string, unknown>): Promise<ApiResult> {
    return this.client.post(Endpoints.user.base, { data: user });
  }

  /** POST /user/createWithArray */
  createWithArray(users: User[]): Promise<ApiResult> {
    return this.client.post(Endpoints.user.createWithArray, { data: users });
  }

  /** POST /user/createWithList */
  createWithList(users: User[]): Promise<ApiResult> {
    return this.client.post(Endpoints.user.createWithList, { data: users });
  }

  /** GET /user/login?username=&password= */
  login(username: string, password: string): Promise<ApiResult> {
    return this.client.get(Endpoints.user.login, { params: { username, password } });
  }

  /** GET /user/logout */
  logout(): Promise<ApiResult> {
    return this.client.get(Endpoints.user.logout);
  }

  /** GET /user/{username} */
  getUser(username: string): Promise<ApiResult> {
    return this.client.get(Endpoints.user.byUsername(username));
  }

  /** PUT /user/{username} */
  updateUser(username: string, user: User | Record<string, unknown>): Promise<ApiResult> {
    return this.client.put(Endpoints.user.byUsername(username), { data: user });
  }

  /** DELETE /user/{username} */
  deleteUser(username: string): Promise<ApiResult> {
    return this.client.delete(Endpoints.user.byUsername(username));
  }
}
