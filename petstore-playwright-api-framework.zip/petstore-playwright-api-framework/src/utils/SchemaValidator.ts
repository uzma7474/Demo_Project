import * as fs from 'fs';
import * as path from 'path';

/** The small JSON-Schema subset the Petstore contracts need - no extra dependency required. */
export interface JsonSchema {
  type?: 'object' | 'array' | 'string' | 'integer' | 'number' | 'boolean';
  required?: string[];
  properties?: Record<string, JsonSchema>;
  additionalProperties?: JsonSchema;
  items?: JsonSchema;
  enum?: unknown[];
}

export class SchemaValidator {
  /** Loads `src/schemas/<name>.schema.json`. */
  static load(name: string): JsonSchema {
    const file = path.resolve(__dirname, '..', 'schemas', `${name}.schema.json`);
    if (!fs.existsSync(file)) {
      const available = fs
        .readdirSync(path.dirname(file))
        .filter((entry) => entry.endsWith('.schema.json'))
        .map((entry) => entry.replace('.schema.json', ''));
      throw new Error(`Unknown schema "${name}". Available: ${available.join(', ')}`);
    }
    return JSON.parse(fs.readFileSync(file, 'utf-8')) as JsonSchema;
  }

  /** Returns a list of human-readable violations (empty = valid). */
  static validate(data: unknown, schema: JsonSchema, location = '$'): string[] {
    const errors: string[] = [];

    if (schema.type && !SchemaValidator.matchesType(data, schema.type)) {
      errors.push(`${location}: expected ${schema.type} but got ${SchemaValidator.describe(data)}`);
      return errors;
    }
    if (schema.enum && !schema.enum.includes(data)) {
      errors.push(`${location}: "${String(data)}" is not one of [${schema.enum.join(', ')}]`);
    }

    if (schema.type === 'object' && data !== null && typeof data === 'object') {
      const record = data as Record<string, unknown>;
      for (const key of schema.required ?? []) {
        if (record[key] === undefined || record[key] === null) errors.push(`${location}.${key}: required property is missing`);
      }
      for (const [key, value] of Object.entries(record)) {
        const propertySchema = schema.properties?.[key] ?? schema.additionalProperties;
        if (propertySchema && value !== undefined && value !== null) {
          errors.push(...SchemaValidator.validate(value, propertySchema, `${location}.${key}`));
        }
      }
    }

    if (schema.type === 'array' && Array.isArray(data) && schema.items) {
      data.forEach((item, index) => errors.push(...SchemaValidator.validate(item, schema.items as JsonSchema, `${location}[${index}]`)));
    }
    return errors;
  }

  private static matchesType(value: unknown, type: NonNullable<JsonSchema['type']>): boolean {
    switch (type) {
      case 'array':
        return Array.isArray(value);
      case 'object':
        return value !== null && typeof value === 'object' && !Array.isArray(value);
      case 'integer':
        return typeof value === 'number' && Number.isInteger(value);
      case 'number':
        return typeof value === 'number';
      case 'string':
        return typeof value === 'string';
      case 'boolean':
        return typeof value === 'boolean';
    }
  }

  private static describe(value: unknown): string {
    if (value === null) return 'null';
    if (Array.isArray(value)) return 'array';
    return typeof value;
  }
}
