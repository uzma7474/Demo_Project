/** Small helpers that keep test data unique, so scenarios can run in parallel on a shared public API. */
export class RandomUtil {
  static int(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  /** A positive int64-safe id (about 1.7e12) that is unique enough across parallel workers. */
  static id(): number {
    return Math.floor(Date.now() / 1000) * 1000 + RandomUtil.int(0, 999);
  }

  static suffix(length = 6): string {
    return Math.random()
      .toString(36)
      .slice(2, 2 + length)
      .padEnd(length, '0');
  }

  static string(prefix = 'data'): string {
    return `${prefix}_${RandomUtil.suffix()}`;
  }

  static email(localPart = 'user'): string {
    return `${localPart}.${RandomUtil.suffix()}@example.com`;
  }

  static pick<T>(items: readonly T[]): T {
    return items[RandomUtil.int(0, items.length - 1)];
  }
}
