export const sleep = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

export class RetryUtil {
  /**
   * Repeats `action` until `isDone` returns true (or the attempts run out) and
   * returns the last value. The public Petstore is eventually consistent, so
   * read-after-write checks use this instead of a single GET.
   */
  static async pollUntil<T>(
    action: () => Promise<T>,
    isDone: (value: T) => boolean,
    options: { attempts?: number; delayMs?: number } = {},
  ): Promise<T> {
    const attempts = options.attempts ?? 5;
    const delayMs = options.delayMs ?? 600;
    let last!: T;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      last = await action();
      if (isDone(last)) return last;
      if (attempt < attempts) await sleep(delayMs);
    }
    return last;
  }
}
