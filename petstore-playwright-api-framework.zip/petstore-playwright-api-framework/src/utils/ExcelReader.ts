import * as path from 'path';
import ExcelJS from 'exceljs';
import { Config } from '../config/Config';

export type ExcelCell = string | number | boolean | Date | undefined;
export type ExcelRow = Record<string, ExcelCell>;

/**
 * Excel utilities (exceljs). Row 1 is the header; every following non-empty row
 * becomes an object keyed by header name. Formula cells return their cached
 * result, rich-text and hyperlink cells return their text.
 */
export class ExcelReader {
  private static cache = new Map<string, ExcelRow[]>();

  /** Resolves a path relative to `test-data/` (absolute paths are used as-is). */
  static resolvePath(filePath: string): string {
    return path.isAbsolute(filePath) ? filePath : path.join(Config.get().paths.testData, filePath);
  }

  static async readSheet(filePath: string, sheetName: string): Promise<ExcelRow[]> {
    const file = ExcelReader.resolvePath(filePath);
    const cacheKey = `${file}::${sheetName}`;
    const cached = ExcelReader.cache.get(cacheKey);
    if (cached) return cached.map((row) => ({ ...row }));

    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(file);
    const sheet = workbook.getWorksheet(sheetName);
    if (!sheet) {
      throw new Error(
        `Sheet "${sheetName}" not found in ${file}. Available: ${workbook.worksheets.map((s) => s.name).join(', ')}`,
      );
    }

    const headers: string[] = [];
    sheet.getRow(1).eachCell({ includeEmpty: false }, (cell: ExcelJS.Cell, column: number) => {
      headers[column] = String(cell.value ?? '').trim();
    });

    const rows: ExcelRow[] = [];
    sheet.eachRow({ includeEmpty: false }, (row: ExcelJS.Row, rowNumber: number) => {
      if (rowNumber === 1) return;
      const record: ExcelRow = {};
      let hasValue = false;
      headers.forEach((header, column) => {
        if (!header) return;
        const value = ExcelReader.normalise(row.getCell(column).value);
        if (value !== undefined && value !== '') hasValue = true;
        record[header] = value;
      });
      if (hasValue) rows.push(record);
    });

    ExcelReader.cache.set(cacheKey, rows);
    return rows.map((row) => ({ ...row }));
  }

  /** Finds the first row where `keyColumn` equals `key` (default column: TestCaseId). */
  static async findRow(filePath: string, sheetName: string, key: string, keyColumn = 'TestCaseId'): Promise<ExcelRow> {
    const rows = await ExcelReader.readSheet(filePath, sheetName);
    const row = rows.find((candidate) => String(candidate[keyColumn]) === key);
    if (!row) {
      throw new Error(
        `No row with ${keyColumn}="${key}" in sheet "${sheetName}". Available: ${rows
          .map((candidate) => String(candidate[keyColumn]))
          .join(', ')}`,
      );
    }
    return row;
  }

  private static normalise(value: ExcelJS.CellValue): ExcelCell {
    if (value === null || value === undefined) return undefined;
    if (typeof value !== 'object' || value instanceof Date) return value as ExcelCell;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const complex = value as any;
    if ('result' in complex) return ExcelReader.normalise(complex.result);
    if ('richText' in complex) return complex.richText.map((part: { text: string }) => part.text).join('');
    if ('text' in complex) return String(complex.text);
    if ('error' in complex) return String(complex.error);
    return String(value);
  }
}
