import * as fs from 'fs';
import * as path from 'path';
import ExcelJS from 'exceljs';
import { ExcelReader, ExcelRow } from './ExcelReader';

/** Writes rows (objects) to a sheet - handy for exporting execution summaries or generating test data. */
export class ExcelWriter {
  static async writeSheet(filePath: string, sheetName: string, rows: ExcelRow[]): Promise<string> {
    const file = ExcelReader.resolvePath(filePath);
    fs.mkdirSync(path.dirname(file), { recursive: true });

    const workbook = new ExcelJS.Workbook();
    if (fs.existsSync(file)) await workbook.xlsx.readFile(file);
    const existing = workbook.getWorksheet(sheetName);
    if (existing) workbook.removeWorksheet(existing.id);

    const sheet = workbook.addWorksheet(sheetName);
    const columns = Array.from(new Set(rows.flatMap((row) => Object.keys(row))));
    sheet.columns = columns.map((key) => ({ header: key, key, width: Math.max(14, key.length + 4) }));
    sheet.getRow(1).font = { bold: true };
    rows.forEach((row) => sheet.addRow(row));

    await workbook.xlsx.writeFile(file);
    return file;
  }
}
