import * as fs from 'fs';
import * as path from 'path';
import { Config } from '../config/Config';

/** JSON utilities: read/write test data and navigate parsed bodies with a simple path syntax. */
export class JsonReader {
  /** Resolves a path relative to `test-data/` (absolute paths are used as-is). */
  static resolvePath(relativePath: string): string {
    return path.isAbsolute(relativePath) ? relativePath : path.join(Config.get().paths.testData, relativePath);
  }

  static read<T = unknown>(relativePath: string): T {
    const file = JsonReader.resolvePath(relativePath);
    try {
      return JSON.parse(fs.readFileSync(file, 'utf-8')) as T;
    } catch (error) {
      throw new Error(`Unable to read JSON file ${file}: ${String(error)}`);
    }
  }

  /** Reads one named record from a file shaped like `{ "KEY": { ... }, ... }`. Returns a deep copy. */
  static readRecord<T>(relativePath: string, key: string): T {
    const records = JsonReader.read<Record<string, T>>(relativePath);
    if (!Object.prototype.hasOwnProperty.call(records, key)) {
      throw new Error(`Key "${key}" not found in ${relativePath}. Available: ${Object.keys(records).join(', ')}`);
    }
    return structuredClone(records[key]);
  }

  static write(relativePath: string, data: unknown): void {
    const file = JsonReader.resolvePath(relativePath);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf-8');
  }

  /**
   * Reads a value using dot / bracket notation: `name`, `category.name`, `tags[0].name`.
   * Returns `undefined` when any segment is missing.
   */
  static getByPath(source: unknown, pointer: string): unknown {
    const segments = pointer.replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean);
    let current: unknown = source;
    for (const segment of segments) {
      if (current === null || typeof current !== 'object') return undefined;
      current = (current as Record<string, unknown>)[segment];
    }
    return current;
  }
}
