import { RandomUtil } from './RandomUtil';

const TOKEN = /\{\{\s*([a-zA-Z]+)(?::([^}]*?))?\s*\}\}/g;
const WHOLE_TOKEN = /^\{\{\s*([a-zA-Z]+)(?::([^}]*?))?\s*\}\}$/;

/**
 * Resolves dynamic placeholders inside JSON / Excel test data so the same data
 * file can be reused run after run on a shared environment.
 *
 *   {{randomId}}            -> unique number (keeps its numeric type when it is the whole value)
 *   {{randomString:Rex}}    -> "Rex_k3j9x2"
 *   {{randomEmail:john}}    -> "john.k3j9x2@example.com"
 *   {{randomInt:1:10}}      -> number between 1 and 10
 *   {{timestamp}}           -> epoch millis
 *   {{now}}                 -> ISO-8601 date-time
 *   {{env:API_KEY}}         -> value of an environment variable
 */
export class DataResolver {
  static resolve<T>(input: T): T {
    return DataResolver.walk(input) as T;
  }

  private static walk(value: unknown): unknown {
    if (typeof value === 'string') return DataResolver.resolveString(value);
    if (Array.isArray(value)) return value.map((item) => DataResolver.walk(item));
    if (value !== null && typeof value === 'object' && !(value instanceof Date)) {
      return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, DataResolver.walk(item)]));
    }
    return value;
  }

  private static resolveString(text: string): unknown {
    const whole = WHOLE_TOKEN.exec(text);
    if (whole) return DataResolver.token(whole[1], whole[2]);
    return text.replace(TOKEN, (_match, name: string, arg?: string) => String(DataResolver.token(name, arg)));
  }

  private static token(name: string, arg?: string): unknown {
    switch (name) {
      case 'randomId':
        return RandomUtil.id();
      case 'randomString':
        return RandomUtil.string(arg || 'data');
      case 'randomEmail':
        return RandomUtil.email(arg || 'user');
      case 'randomInt': {
        const [min, max] = (arg || '1:100').split(':').map(Number);
        return RandomUtil.int(min, max);
      }
      case 'timestamp':
        return Date.now();
      case 'now':
        return new Date().toISOString();
      case 'env':
        return process.env[arg ?? ''] ?? '';
      default:
        throw new Error(`Unknown test-data placeholder {{${name}}}`);
    }
  }
}
