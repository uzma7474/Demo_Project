/** The generic `ApiResponse` definition used by most Petstore write operations. */
export interface ApiMessage {
  code?: number;
  type?: string;
  message?: string;
}
