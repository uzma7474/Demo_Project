import { ApiClient } from '../core/ApiClient';
import { PetService } from '../services/PetService';
import { StoreService } from '../services/StoreService';
import { UserService } from '../services/UserService';

export interface Services {
  pet: PetService;
  store: StoreService;
  user: UserService;
}

/** Factory: builds every service object on top of one shared ApiClient. */
export class ServiceFactory {
  static create(client: ApiClient): Services {
    return {
      pet: new PetService(client),
      store: new StoreService(client),
      user: new UserService(client),
    };
  }
}
