/**
 * Regenerates test-data/excel/petstore-data.xlsx (sheets: Pets, Users, Orders).
 * Run with `npm run generate:excel`. Edit the arrays below, or just open the
 * workbook in Excel - the framework only needs the header names to stay the same.
 */
import { ExcelRow } from '../src/utils/ExcelReader';
import { ExcelWriter } from '../src/utils/ExcelWriter';

const FILE = 'excel/petstore-data.xlsx';

const pets: ExcelRow[] = [
  { TestCaseId: 'PET_DOG_AVAILABLE', Id: '{{randomId}}', Name: '{{randomString:Rex}}', CategoryId: 1, CategoryName: 'Dogs', PhotoUrls: 'https://example.com/dog1.jpg;https://example.com/dog2.jpg', Tags: 'friendly;trained', Status: 'available' },
  { TestCaseId: 'PET_CAT_PENDING', Id: '{{randomId}}', Name: '{{randomString:Whiskers}}', CategoryId: 2, CategoryName: 'Cats', PhotoUrls: 'https://example.com/cat.jpg', Tags: 'indoor', Status: 'pending' },
  { TestCaseId: 'PET_BIRD_SOLD', Id: '{{randomId}}', Name: '{{randomString:Tweety}}', CategoryId: 3, CategoryName: 'Birds', PhotoUrls: 'https://example.com/bird.jpg', Tags: 'singing;colorful', Status: 'sold' },
];

const users: ExcelRow[] = [
  { TestCaseId: 'USER_JOHN', Id: '{{randomId}}', Username: '{{randomString:john}}', FirstName: 'John', LastName: 'Doe', Email: '{{randomEmail:john}}', Password: 'Passw0rd!', Phone: '9876543210', UserStatus: 1 },
  { TestCaseId: 'USER_JANE', Id: '{{randomId}}', Username: '{{randomString:jane}}', FirstName: 'Jane', LastName: 'Smith', Email: '{{randomEmail:jane}}', Password: 'S3cret#Pass', Phone: '9123456780', UserStatus: 1 },
];

const orders: ExcelRow[] = [
  { TestCaseId: 'ORDER_PLACED', Id: '{{randomId}}', PetId: '{{randomId}}', Quantity: 2, ShipDate: '{{now}}', Status: 'placed', Complete: false },
  { TestCaseId: 'ORDER_APPROVED', Id: '{{randomId}}', PetId: '{{randomId}}', Quantity: 1, ShipDate: '{{now}}', Status: 'approved', Complete: false },
  { TestCaseId: 'ORDER_DELIVERED', Id: '{{randomId}}', PetId: '{{randomId}}', Quantity: 3, ShipDate: '{{now}}', Status: 'delivered', Complete: true },
];

(async () => {
  await ExcelWriter.writeSheet(FILE, 'Pets', pets);
  await ExcelWriter.writeSheet(FILE, 'Users', users);
  const file = await ExcelWriter.writeSheet(FILE, 'Orders', orders);
  console.log(`Wrote ${file}`);
})();
