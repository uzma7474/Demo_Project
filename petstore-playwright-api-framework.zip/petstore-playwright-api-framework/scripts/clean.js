// Removes generated output folders. Works on every OS without extra dependencies.
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
for (const folder of ['reports', 'logs', 'dist', 'test-results', 'playwright-report', '.features-gen']) {
  fs.rmSync(path.join(root, folder), { recursive: true, force: true });
}
console.log('Cleaned reports, logs and generated folders.');
