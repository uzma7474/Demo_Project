import { defineConfig } from '@playwright/test';
import { Config } from './src/config/Config';

const config = Config.get();

/**
 * Pure API project: no browsers are launched. Scenarios use unique data and clean up after themselves,
 * so the whole suite can run fully parallel.
 *   npx playwright test                       everything
 *   npx playwright test --grep @smoke         by tag
 *   npx playwright test tests/pet.api.spec.ts one file
 *   ENV=local npx playwright test             against http://localhost:8080/v2/
 */
export default defineConfig({
  testDir: './tests',
  testMatch: '**/*.api.spec.ts',
  timeout: 60_000,
  expect: { timeout: 15_000 },
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  workers: process.env.CI ? 2 : 4,
  outputDir: 'reports/test-results',
  reporter: [
    ['list'],
    ['html', { open: 'never', outputFolder: 'reports/html' }],
    ['json', { outputFile: 'reports/results.json' }],
    ['junit', { outputFile: 'reports/junit.xml' }],
  ],
  use: {
    baseURL: config.baseUrl,
    extraHTTPHeaders: { Accept: 'application/json' },
  },
  projects: [{ name: 'petstore-api' }],
});
