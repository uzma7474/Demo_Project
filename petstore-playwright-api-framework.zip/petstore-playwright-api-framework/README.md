# Petstore API Framework - Playwright Test + TypeScript

Pure API framework (no browser, no Cucumber) for the [Swagger Petstore v2](https://petstore.swagger.io/), covering **all 20 operations**
of the tags `pet`, `store` and `user`. Built on Playwright's own runner, fixtures and `APIRequestContext`.

## Quick start

```bash
npm install
cp .env.example .env              # optional
npx playwright test               # everything (4 workers, fully parallel)
npx playwright test --grep @smoke # by tag: @smoke @regression @negative @e2e @pet @store @user @json @excel
npx playwright test tests/pet.api.spec.ts
npx playwright test --grep-invert @excel
npm run report                    # open the HTML report
ENV=local npx playwright test     # self-hosted: docker run -p 8080:8080 swaggerapi/petstore
```

Reports: `reports/html` (Playwright HTML), `reports/results.json`, `reports/junit.xml`. Every test gets its last API call
attached (request + response + timing); a failed test gets the whole conversation. Logs: `logs/api-tests.log`.
Requires Node 18+.

## API coverage

| Tag | Operation | Endpoint | Service method |
| --- | --- | --- | --- |
| pet | Add pet | `POST /pet` | `api.pet.addPet` |
| pet | Update pet | `PUT /pet` | `api.pet.updatePet` |
| pet | Find by status | `GET /pet/findByStatus` | `api.pet.findByStatus` |
| pet | Find by tags | `GET /pet/findByTags` | `api.pet.findByTags` |
| pet | Get pet | `GET /pet/{petId}` | `api.pet.getPetById` |
| pet | Update with form | `POST /pet/{petId}` | `api.pet.updatePetWithForm` |
| pet | Delete pet | `DELETE /pet/{petId}` | `api.pet.deletePet` |
| pet | Upload image | `POST /pet/{petId}/uploadImage` | `api.pet.uploadImage` |
| store | Inventory | `GET /store/inventory` | `api.store.getInventory` |
| store | Place order | `POST /store/order` | `api.store.placeOrder` |
| store | Get order | `GET /store/order/{orderId}` | `api.store.getOrderById` |
| store | Delete order | `DELETE /store/order/{orderId}` | `api.store.deleteOrder` |
| user | Create user | `POST /user` | `api.user.createUser` |
| user | Create with array | `POST /user/createWithArray` | `api.user.createWithArray` |
| user | Create with list | `POST /user/createWithList` | `api.user.createWithList` |
| user | Login | `GET /user/login` | `api.user.login` |
| user | Logout | `GET /user/logout` | `api.user.logout` |
| user | Get user | `GET /user/{username}` | `api.user.getUser` |
| user | Update user | `PUT /user/{username}` | `api.user.updateUser` |
| user | Delete user | `DELETE /user/{username}` | `api.user.deleteUser` |

39 tests run on JSON data plus 7 more on Excel data (46 total): positive, negative (404 / malformed body), schema, header and
response-time checks, data-driven suites and one end-to-end purchase journey.

## Design - which pattern solves what

An API has no pages, so the right fit is the **Service Object Model**: one class per Swagger tag, one method per operation.

| Pattern | Where | Why |
| --- | --- | --- |
| Service Object Model (API twin of Page Object) | `src/services` | Tests never build URLs, headers or bodies |
| Builder | `src/builders` | Valid-by-default payloads, override only what the test cares about |
| Factory | `ServiceFactory`, `DataProviderFactory` | Central object creation |
| Strategy | `src/data` (`TestDataProvider`: JSON / Excel) | Same test, interchangeable data source |
| Singleton | `Config`, `Logger` | One configuration and one log file per process |
| Fixture-based dependency injection | `src/fixtures` | Playwright builds `api`, `given`, `cleanup`, `data` per test and tears them down in order |
| Facade ("Given" helpers) | `given.pet()`, `given.order()`, `given.user()` | One line to create a precondition, assert it worked and register its cleanup |
| Response wrapper | `ApiResult` | Body read once; JSON, headers and timing available to every assertion |
| Custom matchers | `src/assertions/matchers.ts` | `expect(result).toHaveStatus(200)` - failures show the call and body |
| Contract (schema) testing | `src/schemas` | Response shape checked with `toMatchSchema('pet')` |

Control flow: `spec -> fixtures -> service object -> ApiClient -> APIRequestContext -> Petstore`

```
petstore-playwright-api-framework/
├── playwright.config.ts
├── tests/                         # pet, store, user, data-driven, e2e  (*.api.spec.ts)
├── src/
│   ├── config/Config.ts           # Singleton: env + .env
│   ├── core/                      # ApiClient (retry, timing, logging), ApiResult, Endpoints, Logger
│   ├── services/                  # PetService, StoreService, UserService  (the "pages")
│   ├── factories/ServiceFactory.ts
│   ├── builders/                  # PetBuilder, OrderBuilder, UserBuilder
│   ├── models/                    # Pet, Order, User, ApiMessage
│   ├── fixtures/index.ts          # test = base.extend({ client, api, cleanup, given, data, diagnostics })
│   ├── assertions/matchers.ts     # expect = baseExpect.extend({ toHaveStatus, toMatchSchema, ... })
│   ├── data/                      # TestDataProvider, JsonDataProvider, ExcelDataProvider, ExcelMapper, DataProviderFactory
│   ├── schemas/                   # *.schema.json contracts
│   └── utils/                     # JsonReader, ExcelReader, ExcelWriter, DataResolver, SchemaValidator, RandomUtil, RetryUtil
├── test-data/                     # json/*.json, excel/petstore-data.xlsx, files/sample-pet.png
└── scripts/                       # generate-excel.ts, clean.js
```

### What a test looks like

```ts
import { test, expect } from '../src/fixtures';

test('delete a pet', { tag: '@smoke' }, async ({ api, given }) => {
  const pet = await given.pet({ name: 'Luna' });      // created via API, auto-deleted after the test

  const result = await api.pet.deletePet(pet.id);

  expect(result).toHaveStatus(200);
  expect(result).toHaveBodyField('message', pet.id);
  await expect.poll(async () => (await api.pet.getPetById(pet.id)).status).toBe(404);   // eventual consistency
});
```

Matchers: `toHaveStatus`, `toHaveStatusIn`, `toHaveBodyField(path[, value])`, `toHaveHeader`, `toRespondWithin`, `toMatchSchema`, `toBeJsonArray`.

## JSON and Excel utilities

* `JsonReader` - `read`, `readRecord(file, key)`, `write`, `getByPath(body, "tags[0].name")`.
* `ExcelReader` - `readSheet(file, sheet)` returns row objects keyed by header (formulas evaluated); `findRow(file, sheet, key)` (key column `TestCaseId`).
* `ExcelWriter` - `writeSheet(file, sheet, rows)`, e.g. to export an execution summary.
* `DataResolver` - placeholders for JSON **and** Excel cells so data files can be reused on a shared server:
  `{{randomId}}` (stays numeric), `{{randomString:Rex}}`, `{{randomEmail:john}}`, `{{randomInt:1:10}}`, `{{timestamp}}`, `{{now}}`, `{{env:NAME}}`.

Excel layout (`test-data/excel/petstore-data.xlsx`): sheets `Pets`, `Users`, `Orders`; first column `TestCaseId`; list columns
(`PhotoUrls`, `Tags`) are `;`-separated. The JSON files use the **same keys**, so the `data` fixture switches source with one word:

```ts
const pet = await data('excel').getPet('PET_DOG_AVAILABLE');   // data() uses DATA_SOURCE, default json
```

Regenerate the workbook with `npm run generate:excel`.

## Adding a new endpoint or test

1. Add the path to `src/core/Endpoints.ts` and a method to the right service in `src/services`.
2. Write the test in `tests/` using the `api` fixture and the custom matchers.
3. Need a new kind of precondition? Add it to `Given` in `src/fixtures/index.ts`.

## Notes about the public Petstore

* It is a shared sandbox: anybody can change or delete data. Every test creates unique ids/usernames, registers its own cleanup,
  and read-after-write checks use `expect.poll` because the service is eventually consistent.
* `findByStatus` returns junk created by other users, so the `pets` schema is deliberately loose.
* GET requests retry on 502/503/504 and network errors (`RETRY_COUNT`, `RETRY_DELAY_MS`); writes never retry.
* Leading slashes are stripped before a request is sent: Playwright resolves `/pet` against the host root, which would drop the `/v2` base path.
