import { OrderBuilder } from '../src/builders/OrderBuilder';
import { expect, test } from '../src/fixtures';
import { PetStatus } from '../src/models/Pet';

test.describe('Pet purchase journey', { tag: '@e2e' }, () => {
  test('customer signs in, buys an available pet and the shop closes the sale', { tag: ['@smoke', '@regression'] }, async ({ api, given }) => {
    const customer = await test.step('a customer account exists', () => given.user());

    await test.step('the customer logs in', async () => {
      const login = await api.user.login(customer.username, customer.password!);
      expect(login).toHaveStatus(200);
    });

    const pet = await test.step('an available pet is in the shop', () => given.pet({ name: 'Goldie', status: PetStatus.Available }));

    const order = OrderBuilder.anOrder().forPet(pet.id).withQuantity(1).build();
    await test.step('the customer places an order for the pet', async () => {
      const placed = await api.store.placeOrder(order);
      expect(placed).toHaveStatus(200);
      expect(placed.json()).toMatchObject({ id: order.id, petId: pet.id, status: 'placed' });
    });

    await test.step('the order can be read back', async () => {
      await expect
        .poll(async () => (await api.store.getOrderById(order.id!)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
        .toBe(200);
    });

    await test.step('the shop marks the pet as sold', async () => {
      const sold = await api.pet.updatePet({ ...pet, status: PetStatus.Sold });
      expect(sold).toHaveStatus(200);
      expect(sold).toHaveBodyField('status', 'sold');
    });

    await test.step('the order is closed and the pet removed', async () => {
      expect(await api.store.deleteOrder(order.id!)).toHaveStatus(200);
      expect(await api.pet.deletePet(pet.id)).toHaveStatus(200);
    });

    await test.step('the customer logs out', async () => {
      expect(await api.user.logout()).toHaveStatus(200);
    });
  });
});
