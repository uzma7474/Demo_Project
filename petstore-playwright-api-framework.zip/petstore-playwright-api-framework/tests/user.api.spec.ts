import { UserBuilder } from '../src/builders/UserBuilder';
import { expect, test } from '../src/fixtures';
import { RandomUtil } from '../src/utils/RandomUtil';

test.describe('User API', { tag: '@user' }, () => {
  test('create a user', { tag: ['@smoke', '@regression'] }, async ({ api, cleanup }) => {
    const user = UserBuilder.aUser().withUsername(RandomUtil.string('john')).build();

    const result = await api.user.createUser(user);
    cleanup.add(() => api.user.deleteUser(user.username!));

    expect(result).toHaveStatus(200);
    expect(result).toMatchSchema('apiResponse');
    expect(result).toHaveBodyField('message', user.id);
  });

  test('retrieve a user by username', { tag: ['@smoke', '@regression'] }, async ({ api, given }) => {
    const user = await given.user({ firstName: 'Jane' });

    await expect
      .poll(async () => (await api.user.getUser(user.username)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
      .toBe(200);

    const result = await api.user.getUser(user.username);
    expect(result).toMatchSchema('user');
    expect(result.json()).toMatchObject({ username: user.username, firstName: 'Jane', email: user.email });
  });

  test('update a user', { tag: '@regression' }, async ({ api, given }) => {
    const user = await given.user();

    const update = await api.user.updateUser(user.username, { ...user, email: 'alice.updated@example.com' });

    expect(update).toHaveStatus(200);
    expect(update).toHaveBodyField('message', user.id);
    await expect
      .poll(async () => (await api.user.getUser(user.username)).json<{ email: string }>()?.email, { intervals: [300, 600, 1200], timeout: 15_000 })
      .toBe('alice.updated@example.com');
  });

  test('delete a user', { tag: '@regression' }, async ({ api, given }) => {
    const user = await given.user();

    const result = await api.user.deleteUser(user.username);

    expect(result).toHaveStatus(200);
    expect(result).toHaveBodyField('message', user.username);
    await expect
      .poll(async () => (await api.user.getUser(user.username)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
      .toBe(404);
  });

  test('log a user in', { tag: ['@smoke', '@regression'] }, async ({ api, given }) => {
    const user = await given.user();

    const result = await api.user.login(user.username, user.password!);

    expect(result).toHaveStatus(200);
    expect(result.json<{ message: string }>()!.message).toContain('logged in user session');
    expect(result).toHaveHeader('x-expires-after');
    expect(result).toHaveHeader('x-rate-limit');
  });

  test('log a user out', { tag: '@regression' }, async ({ api }) => {
    const result = await api.user.logout();

    expect(result).toHaveStatus(200);
    expect(result).toHaveBodyField('message', 'ok');
  });

  for (const endpoint of ['createWithArray', 'createWithList'] as const) {
    test(`create several users with ${endpoint}`, { tag: '@regression' }, async ({ api, cleanup }) => {
      const users = ['dave', 'erin'].map((name) => UserBuilder.aUser().withUsername(RandomUtil.string(name)).build());
      users.forEach((user) => cleanup.add(() => api.user.deleteUser(user.username!)));

      const result = await api.user[endpoint](users);

      expect(result).toHaveStatus(200);
      expect(result).toHaveBodyField('message', 'ok');
      for (const user of users) {
        await expect
          .poll(async () => (await api.user.getUser(user.username!)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
          .toBe(200);
      }
    });
  }

  test.describe('negative cases', { tag: ['@negative', '@regression'] }, () => {
    test('get a user that does not exist', async ({ api }) => {
      const result = await api.user.getUser('no_such_user_987654321');

      expect(result).toHaveStatus(404);
      expect(result).toHaveBodyField('message', 'User not found');
    });

    test('delete a user that does not exist', async ({ api }) => {
      expect(await api.user.deleteUser('no_such_user_987654322')).toHaveStatus(404);
    });
  });
});
