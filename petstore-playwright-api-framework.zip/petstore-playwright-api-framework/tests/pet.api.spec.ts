import * as path from 'path';
import { PetBuilder } from '../src/builders/PetBuilder';
import { Config } from '../src/config/Config';
import { expect, test } from '../src/fixtures';
import { PetStatus } from '../src/models/Pet';

const config = Config.get();

test.describe('Pet API', { tag: '@pet' }, () => {
  test('add a new pet', { tag: ['@smoke', '@regression'] }, async ({ api, cleanup }) => {
    const pet = PetBuilder.aPet().withName('Rex').withStatus(PetStatus.Available).build();

    const result = await api.pet.addPet(pet);
    cleanup.add(() => api.pet.deletePet(pet.id!));

    expect(result).toHaveStatus(200);
    expect(result).toHaveBodyField('id');
    expect(result).toMatchSchema('pet');
    expect(result.json()).toMatchObject({ id: pet.id, name: 'Rex', status: 'available', photoUrls: pet.photoUrls });
    expect(result).toRespondWithin(config.maxResponseTimeMs);
  });

  test('retrieve a pet by its id', { tag: ['@smoke', '@regression'] }, async ({ api, given }) => {
    const pet = await given.pet({ name: 'Bella' });

    await expect
      .poll(async () => (await api.pet.getPetById(pet.id)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
      .toBe(200);

    const result = await api.pet.getPetById(pet.id);
    expect(result).toHaveBodyField('name', 'Bella');
    expect(result).toHaveBodyField('status', 'available');
    expect(result).toHaveBodyField('category.name', pet.category!.name);
    expect(result).toMatchSchema('pet');
  });

  test('update an existing pet with PUT', { tag: '@regression' }, async ({ api, given }) => {
    const pet = await given.pet({ name: 'Max' });

    const result = await api.pet.updatePet({ ...pet, name: 'Max Updated', status: PetStatus.Sold });

    expect(result).toHaveStatus(200);
    expect(result).toHaveBodyField('name', 'Max Updated');
    expect(result).toHaveBodyField('status', 'sold');
  });

  test('update a pet using form data', { tag: '@regression' }, async ({ api, given }) => {
    const pet = await given.pet({ name: 'Charlie' });

    const result = await api.pet.updatePetWithForm(pet.id, { name: 'Charlie Form', status: PetStatus.Pending });

    expect(result).toHaveStatus(200);
    expect(result).toMatchSchema('apiResponse');
    expect(result).toHaveBodyField('message', pet.id);
  });

  for (const statuses of [['available'], ['pending'], ['sold'], ['available', 'pending']]) {
    test(`find pets by status "${statuses.join(',')}"`, { tag: '@regression' }, async ({ api }) => {
      const result = await api.pet.findByStatus(statuses);

      expect(result).toHaveStatus(200);
      expect(result).toMatchSchema('pets');
      const outsideFilter = result.json<Array<{ id: number; status: string }>>()!.filter((pet) => !statuses.includes(pet.status));
      expect(outsideFilter, `pets whose status is not in [${statuses}]`).toEqual([]);
    });
  }

  test('find pets by tags', { tag: '@regression' }, async ({ api, given }) => {
    await given.pet({ tags: [{ id: 1, name: 'automation' }] });

    const result = await api.pet.findByTags(['automation']);

    expect(result).toHaveStatus(200);
    expect(result).toBeJsonArray();
  });

  test('delete a pet', { tag: ['@smoke', '@regression'] }, async ({ api, given }) => {
    const pet = await given.pet({ name: 'Luna' });

    const result = await api.pet.deletePet(pet.id);

    expect(result).toHaveStatus(200);
    expect(result).toHaveBodyField('message', pet.id);
    await expect
      .poll(async () => (await api.pet.getPetById(pet.id)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
      .toBe(404);
  });

  test('upload an image for a pet', { tag: '@regression' }, async ({ api, given }) => {
    const pet = await given.pet({ name: 'Daisy' });

    const result = await api.pet.uploadImage(pet.id, path.join(config.paths.testData, 'files', 'sample-pet.png'), 'profile photo');

    expect(result).toHaveStatus(200);
    expect(result).toMatchSchema('apiResponse');
    expect(result.json<{ message: string }>()!.message).toContain('profile photo');
  });

  test.describe('negative cases', { tag: ['@negative', '@regression'] }, () => {
    test('get a pet that does not exist', async ({ api }) => {
      const result = await api.pet.getPetById(987654321012);

      expect(result).toHaveStatus(404);
      expect(result).toHaveBodyField('message', 'Pet not found');
    });

    test('delete a pet that does not exist', async ({ api }) => {
      expect(await api.pet.deletePet(987654321013)).toHaveStatus(404);
    });

    test('add a pet with a malformed JSON body', async ({ api }) => {
      const result = await api.pet.addPetRaw('{ "id": 1, "name": ');

      expect(result).toHaveStatusIn([400, 405, 500]);
    });

    test('get a pet with a non-numeric id', async ({ api }) => {
      const result = await api.pet.getPetById('not-a-number');

      expect(result).toHaveStatusIn([400, 404]);
    });
  });
});
