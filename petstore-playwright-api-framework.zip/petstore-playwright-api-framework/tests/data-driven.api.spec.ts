import { expect, test } from '../src/fixtures';

/**
 * Data-driven suite: one test per record and per data source.
 * JSON (test-data/json/*.json) and Excel (test-data/excel/petstore-data.xlsx) use the SAME keys,
 * so adding a record means adding one JSON entry plus one Excel row and one key below.
 */
const PET_KEYS = ['PET_DOG_AVAILABLE', 'PET_CAT_PENDING', 'PET_BIRD_SOLD'];
const USER_KEYS = ['USER_JOHN', 'USER_JANE'];
const ORDER_KEYS = ['ORDER_PLACED', 'ORDER_DELIVERED'];

for (const source of ['json', 'excel']) {
  test.describe(`Data-driven from ${source}`, { tag: ['@data-driven', '@regression', `@${source}`] }, () => {
    for (const key of PET_KEYS) {
      test(`add pet ${key}`, async ({ api, data, cleanup }) => {
        const pet = await data(source).getPet(key);

        const result = await api.pet.addPet(pet);
        cleanup.add(() => api.pet.deletePet(pet.id!));

        expect(result).toHaveStatus(200);
        expect(result.json()).toMatchObject({ id: pet.id, name: pet.name, status: pet.status, photoUrls: pet.photoUrls });
      });
    }

    for (const key of USER_KEYS) {
      test(`create and read back user ${key}`, async ({ api, data, cleanup }) => {
        const user = await data(source).getUser(key);

        const created = await api.user.createUser(user);
        cleanup.add(() => api.user.deleteUser(user.username!));
        expect(created).toHaveStatus(200);

        await expect
          .poll(async () => (await api.user.getUser(user.username!)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
          .toBe(200);
        const fetched = await api.user.getUser(user.username!);
        expect(fetched.json()).toMatchObject({ username: user.username, firstName: user.firstName, email: user.email });
      });
    }

    for (const key of ORDER_KEYS) {
      test(`place and read back order ${key}`, async ({ api, data, cleanup }) => {
        const order = await data(source).getOrder(key);

        const placed = await api.store.placeOrder(order);
        cleanup.add(() => api.store.deleteOrder(order.id!));
        expect(placed).toHaveStatus(200);
        expect(placed.json()).toMatchObject({ id: order.id, petId: order.petId, quantity: order.quantity, status: order.status });

        await expect
          .poll(async () => (await api.store.getOrderById(order.id!)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
          .toBe(200);
      });
    }
  });
}
