import { OrderBuilder } from '../src/builders/OrderBuilder';
import { expect, test } from '../src/fixtures';
import { OrderStatus } from '../src/models/Order';

test.describe('Store API', { tag: '@store' }, () => {
  test('read the store inventory', { tag: ['@smoke', '@regression'] }, async ({ api }) => {
    const result = await api.store.getInventory();

    expect(result).toHaveStatus(200);
    expect(result).toMatchSchema('inventory');
  });

  test('place an order for a pet', { tag: ['@smoke', '@regression'] }, async ({ api, given, cleanup }) => {
    const pet = await given.pet({ name: 'Rocky' });
    const order = OrderBuilder.anOrder().forPet(pet.id).withQuantity(2).build();

    const result = await api.store.placeOrder(order);
    cleanup.add(() => api.store.deleteOrder(order.id!));

    expect(result).toHaveStatus(200);
    expect(result).toMatchSchema('order');
    expect(result.json()).toMatchObject({ id: order.id, petId: pet.id, quantity: 2, status: 'placed' });
  });

  test('retrieve an order by its id', { tag: '@regression' }, async ({ api, given }) => {
    const order = await given.order({ quantity: 1, status: OrderStatus.Placed });

    await expect
      .poll(async () => (await api.store.getOrderById(order.id)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
      .toBe(200);

    const result = await api.store.getOrderById(order.id);
    expect(result).toHaveBodyField('quantity', 1);
    expect(result).toHaveBodyField('status', 'placed');
  });

  test('delete an order', { tag: '@regression' }, async ({ api, given }) => {
    const order = await given.order({ quantity: 3 });

    const result = await api.store.deleteOrder(order.id);

    expect(result).toHaveStatus(200);
    expect(result).toHaveBodyField('message', order.id);
    await expect
      .poll(async () => (await api.store.getOrderById(order.id)).status, { intervals: [300, 600, 1200], timeout: 15_000 })
      .toBe(404);
  });

  test.describe('negative cases', { tag: ['@negative', '@regression'] }, () => {
    test('get an order that does not exist', async ({ api }) => {
      const result = await api.store.getOrderById(987654321014);

      expect(result).toHaveStatus(404);
      expect(result).toHaveBodyField('message', 'Order not found');
    });

    test('delete an order that does not exist', async ({ api }) => {
      expect(await api.store.deleteOrder(987654321015)).toHaveStatus(404);
    });
  });
});
