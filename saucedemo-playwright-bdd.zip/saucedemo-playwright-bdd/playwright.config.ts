import { defineConfig, devices } from '@playwright/test';
import { cucumberReporter, defineBddConfig } from 'playwright-bdd';
import { env } from './src/config/env';

/**
 * playwright-bdd generates Playwright spec files from the .feature files into
 * `.features-gen` (run `npx bddgen`, which `npm test` does for you via `pretest`).
 * `testDir` returned here points Playwright at those generated specs.
 *
 * Step definitions, hooks and fixtures live in `src/steps` and `src/fixtures`.
 */
const testDir = defineBddConfig({
  features: 'features/**/*.feature',
  steps: ['src/steps/**/*.ts', 'src/fixtures/**/*.ts'],
  outputDir: '.features-gen',
});

export default defineConfig({
  testDir,
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: env.retries,
  workers: env.workers,
  timeout: env.timeout,
  expect: { timeout: env.expectTimeout },
  outputDir: 'test-results',

  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    cucumberReporter('html', { outputFile: 'cucumber-report/report.html' }),
    cucumberReporter('json', { outputFile: 'cucumber-report/report.json' }),
  ],

  use: {
    baseURL: env.baseUrl,
    headless: env.headless,
    // SauceDemo exposes its stable hooks as `data-test` attributes, so
    // page.getByTestId('login-button') resolves to [data-test="login-button"].
    testIdAttribute: 'data-test',
    viewport: { width: 1366, height: 768 },
    actionTimeout: env.actionTimeout,
    navigationTimeout: env.navigationTimeout,
    launchOptions: { slowMo: env.slowMo },
    // Failure screenshots are attached by the `After` hook (src/steps/hooks.ts).
    screenshot: 'off',
    trace: 'retain-on-failure',
    video: 'retain-on-failure',
  },

  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
    { name: 'webkit', use: { ...devices['Desktop Safari'] } },
  ],
});
