# SauceDemo – Playwright + TypeScript BDD framework (`playwright-bdd`)

BDD automation framework for <https://www.saucedemo.com>, built on **Playwright Test** with
**[playwright-bdd](https://github.com/vitalets/playwright-bdd)**. Gherkin `.feature` files are
compiled into native Playwright specs, so you keep Playwright's runner, fixtures, parallelism,
tracing and reporters, and still write scenarios in Gherkin.

## Quick start

```bash
npm install
npx playwright install --with-deps chromium   # or: npm run install:browsers
npm test                                      # bddgen + run on chromium
```

| Command | What it does |
|---|---|
| `npm test` | Generate specs (`bddgen`) and run everything on Chromium |
| `npm run test:smoke` | Only scenarios tagged `@smoke` |
| `npm run test:negative` | Only scenarios tagged `@negative` |
| `npm run test:all-browsers` | Chromium + Firefox + WebKit |
| `npm run test:headed` / `test:debug` / `test:ui` | Headed run / Playwright inspector / UI mode |
| `npm run report` | Open the Playwright HTML report |
| `npm run report:cucumber` | Open the Cucumber HTML report (`cucumber-report/report.html`) |
| `npm run generate:data` | Regenerate `test-data/checkout-data.xlsx` |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run clean` | Remove generated folders (`.features-gen`, reports, logs) |

Run a single tag or title: `npx bddgen && npx playwright test --grep "@checkout"`.

## Project layout

```
├── features/                     Gherkin scenarios (login, inventory, cart, checkout)
├── src/
│   ├── config/                   env.ts (typed .env loader), paths.ts
│   ├── data/testData.ts          TestDataProvider: one entry point for JSON + Excel data
│   ├── fixtures/
│   │   ├── index.ts              custom `test` (page objects, world, testData, log) + Given/When/Then/hooks
│   │   └── world.ts              ScenarioContext - per-scenario shared state ("CustomWorld")
│   ├── pages/                    Page Object Model
│   │   ├── BasePage.ts           shared behaviour + logged click/fill
│   │   ├── LoginPage / InventoryPage / CartPage / CheckoutInfoPage / CheckoutOverviewPage / CheckoutCompletePage
│   │   └── components/           HeaderComponent (menu, cart badge), ErrorBanner
│   ├── steps/                    step definitions per feature area + hooks.ts
│   ├── types/testdata.ts         interfaces for the test data
│   └── utils/                    logger (winston), jsonReader, excelReader, helpers
├── test-data/                    users.json, products.json, checkout-data.xlsx
├── scripts/generate-excel.ts     builds the Excel workbook from code
├── playwright.config.ts          defineBddConfig + projects + reporters
└── .github/workflows/            CI pipeline
```

## How the pieces fit

1. **`playwright.config.ts`** calls `defineBddConfig({ features, steps })`. `npx bddgen` reads the
   features and writes Playwright specs to `.features-gen/`; Playwright runs those.
2. **Fixtures** (`src/fixtures/index.ts`) extend the base test. Each page object, the `world`, `testData`
   and a scenario `log` are fixtures, created per scenario and only when a step asks for them.
   Steps destructure what they need: `async ({ loginPage, world }) => ...`.
3. **CustomWorld**: playwright-bdd has no Cucumber-style `this`; the idiomatic replacement is a
   fixture. `ScenarioContext` (`world`) carries state between steps of one scenario, e.g. the
   products added to the cart, which the overview steps later assert against.
4. **Page objects** hold locators and actions; assertions on page state are `expect*` methods, so
   step definitions stay one-liners. Locators use SauceDemo's `data-test` attributes
   (`testIdAttribute: 'data-test'` in the config).
5. **Hooks** (`src/steps/hooks.ts`):
   - `BeforeAll` / `AfterAll` - once per worker (logging).
   - `Before` - logs the scenario start and its tags.
   - `Before({ tags: '@loggedin' })` - logs in as the `standard` user before the Background, so
     features tagged `@loggedin` start authenticated without repeating login steps.
   - `After` - logs the result and attaches a full-page screenshot on failure.
6. **Test data**
   - `test-data/users.json` - user accounts and expected login errors.
   - `test-data/products.json` - catalogue (names, prices) used to verify the inventory and order totals.
   - `test-data/checkout-data.xlsx` (sheet `Checkout`) - data-driven checkout cases keyed by `TestCaseId`.
     Steps reference a row by id: `I fill the checkout form using Excel test case "TC_VALID_01"`.
7. **Logging**: `src/utils/logger.ts` (winston) writes to the console and `logs/test-run.log`;
   every page object and scenario gets a child logger with a `[context]` prefix.
8. **Reports**: Playwright HTML (`playwright-report/`), Cucumber HTML + JSON (`cucumber-report/`),
   traces and videos on failure (`test-results/`).

## Configuration

Copy `.env.example` to `.env`. Everything is optional and has a default.
Use `TEST_ENV=staging npm test` to load `.env.staging` instead.

| Variable | Default | Purpose |
|---|---|---|
| `BASE_URL` | `https://www.saucedemo.com` | Application under test |
| `HEADLESS` | `true` | Run browsers headless |
| `RETRIES` / `WORKERS` | `0` (`1` on CI) / Playwright default | Retry and parallelism |
| `TEST_TIMEOUT`, `EXPECT_TIMEOUT`, `ACTION_TIMEOUT`, `NAVIGATION_TIMEOUT` | 30000 / 5000 / 10000 / 20000 | Timeouts in ms |
| `SLOW_MO` | `0` | Slow actions down (ms) when debugging |
| `LOG_LEVEL`, `LOG_TO_CONSOLE` | `info`, `true` | Logger behaviour |

## Adding a test

1. Add a scenario to a `.feature` file (reuse existing step text where you can).
2. If a step is missing, `bddgen` tells you; add it in the matching `src/steps/*.steps.ts` file using
   the fixtures it needs.
3. New screen? Add a class in `src/pages/`, register it as a fixture in `src/fixtures/index.ts`.
4. New data? Add it to the JSON/Excel file and read it through `TestDataProvider`.

## Notes

- Step keywords (`Given/When/Then`) are kept consistent per step text across features.
- Excel cell values are always read as trimmed strings; empty cells are `''`.
- Scenarios run in parallel and are fully independent (each has its own browser context and `world`).
- Commit `package-lock.json` after the first `npm install`, then switch CI to `npm ci`.
