import { Then, When } from '../fixtures';

When('I log in as the {string} user from test data', async ({ loginPage, testData, world }, userKey: string) => {
  const user = testData.user(userKey);
  world.currentUser = user;
  await loginPage.login(user.username, user.password);
});

When('I log in with username {string} and password {string}', async ({ loginPage }, username: string, password: string) => {
  await loginPage.login(username, password);
});

Then('I should see the login error from test data for {string}', async ({ testData, errorBanner }, userKey: string) => {
  const { expectedError } = testData.user(userKey);
  if (!expectedError) {
    throw new Error(`User "${userKey}" has no "expectedError" defined in test-data/users.json`);
  }
  await errorBanner.expectMessage(expectedError);
});

When('I log out', async ({ header }) => {
  await header.logout();
});

Then('I should be back on the login page', async ({ loginPage }) => {
  await loginPage.expectLoaded();
});
