import { expect, Then, When } from '../fixtures';
import { SORT_OPTIONS, type SortOption } from '../pages/InventoryPage';
import type { GherkinTable } from '../utils/helpers';

Then('I should see {int} products', async ({ inventoryPage }, count: number) => {
  await inventoryPage.expectProductCount(count);
});

Then('I should see all products from test data with their prices', async ({ inventoryPage, testData }) => {
  const names = await inventoryPage.getProductNames();
  const prices = await inventoryPage.getProductPrices();
  const displayed = new Map(names.map((name, index) => [name, prices[index]]));
  const catalogue = testData.products();

  expect(names).toHaveLength(catalogue.length);
  for (const product of catalogue) {
    expect(displayed.get(product.name), `price of "${product.name}"`).toBe(product.price);
  }
});

When('I sort products by {string}', async ({ inventoryPage }, option: string) => {
  expect(SORT_OPTIONS, `unknown sort option "${option}"`).toContain(option);
  await inventoryPage.sortBy(option as SortOption);
});

Then('the products should be ordered by {string}', async ({ inventoryPage, testData }, option: string) => {
  const catalogue = testData.products();
  const namesAsc = catalogue.map((p) => p.name).sort((a, b) => a.localeCompare(b));
  const pricesAsc = catalogue.map((p) => p.price).sort((a, b) => a - b);

  switch (option as SortOption) {
    case 'Name (A to Z)':
      await expect.poll(() => inventoryPage.getProductNames()).toEqual(namesAsc);
      break;
    case 'Name (Z to A)':
      await expect.poll(() => inventoryPage.getProductNames()).toEqual([...namesAsc].reverse());
      break;
    case 'Price (low to high)':
      await expect.poll(() => inventoryPage.getProductPrices()).toEqual(pricesAsc);
      break;
    case 'Price (high to low)':
      await expect.poll(() => inventoryPage.getProductPrices()).toEqual([...pricesAsc].reverse());
      break;
    default:
      throw new Error(`Unsupported sort option: ${option}`);
  }
});

When('I add {string} to the cart', async ({ inventoryPage, world }, productName: string) => {
  await inventoryPage.addToCart(productName);
  world.addProduct(productName);
});

When('I add the following products to the cart:', async ({ inventoryPage, world }, table: GherkinTable) => {
  for (const productName of table.raw().flat()) {
    await inventoryPage.addToCart(productName);
    world.addProduct(productName);
  }
});

When('I remove {string} from the cart', async ({ inventoryPage, world }, productName: string) => {
  await inventoryPage.removeFromCart(productName);
  world.removeProduct(productName);
});

Then('the cart badge should show {int}', async ({ header }, count: number) => {
  await header.expectCartCount(count);
});

Then('the button for {string} should offer {string}', async ({ inventoryPage }, productName: string, action: string) => {
  const state = action.toLowerCase().startsWith('remove') ? 'remove' : 'add';
  await inventoryPage.expectButtonState(productName, state);
});
