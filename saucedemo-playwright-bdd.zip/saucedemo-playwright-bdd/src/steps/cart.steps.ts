import { Then, When } from '../fixtures';
import type { GherkinTable } from '../utils/helpers';

When('I open the cart', async ({ header }) => {
  await header.openCart();
});

Then('the cart should contain the following products:', async ({ cartPage }, table: GherkinTable) => {
  await cartPage.expectProducts(table.raw().flat());
});

When('I remove {string} from the cart page', async ({ cartPage, world }, productName: string) => {
  await cartPage.removeProduct(productName);
  world.removeProduct(productName);
});

Then('the cart should be empty', async ({ cartPage }) => {
  await cartPage.expectEmpty();
});

When('I continue shopping', async ({ cartPage }) => {
  await cartPage.continueShopping();
});

Then('I should see the cart page', async ({ cartPage }) => {
  await cartPage.expectLoaded();
});
