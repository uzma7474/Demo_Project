import { After, AfterAll, Before, BeforeAll } from '../fixtures';
import { logger } from '../utils/logger';

/**
 * Hooks.
 *
 * Order of execution for a scenario:
 *   BeforeAll (once per worker) -> Before hooks in file order -> Background -> steps -> After hooks -> AfterAll
 *
 * Tag-scoped hooks only run for scenarios (or features) carrying that tag.
 */

// ---------------------------------------------------------------------------
// Worker level
// ---------------------------------------------------------------------------
BeforeAll(async () => {
  logger.info('================ Worker started ================');
});

AfterAll(async () => {
  logger.info('================ Worker finished ===============');
});

// ---------------------------------------------------------------------------
// Scenario level
// ---------------------------------------------------------------------------
Before(async ({ log, $testInfo }) => {
  log.info(`START  ${$testInfo.title} | tags: ${$testInfo.tags.join(' ') || '-'}`);
});

/**
 * @loggedin - the scenario starts from an authenticated session.
 * Logs in as the "standard" user from test-data/users.json before the Background runs,
 * so feature files do not repeat the login steps.
 */
Before({ tags: '@loggedin' }, async ({ loginPage, inventoryPage, testData, world }) => {
  const user = testData.user('standard');
  world.currentUser = user;
  await loginPage.open();
  await loginPage.login(user.username, user.password);
  await inventoryPage.expectLoaded();
});

After(async ({ page, log, $testInfo }) => {
  const failed = $testInfo.status !== $testInfo.expectedStatus;

  if (failed) {
    log.error(`FAILED ${$testInfo.title} | url: ${page.url()}`);
    try {
      await $testInfo.attach('failure-screenshot', {
        body: await page.screenshot({ fullPage: true }),
        contentType: 'image/png',
      });
    } catch (error) {
      log.warn(`Could not capture screenshot: ${(error as Error).message}`);
    }
  } else {
    log.info(`PASSED ${$testInfo.title}`);
  }
});
