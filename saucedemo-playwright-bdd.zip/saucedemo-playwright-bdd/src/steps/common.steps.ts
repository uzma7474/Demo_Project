import { Given, Then } from '../fixtures';

Given('I am on the login page', async ({ loginPage }) => {
  await loginPage.open();
});

Given('I am on the products page', async ({ inventoryPage }) => {
  await inventoryPage.expectLoaded();
});

Then('I should land on the products page', async ({ inventoryPage }) => {
  await inventoryPage.expectLoaded();
});

/** Shared by the login form and the checkout form (same red banner on both). */
Then('I should see the error message {string}', async ({ errorBanner }, message: string) => {
  await errorBanner.expectMessage(message);
});
