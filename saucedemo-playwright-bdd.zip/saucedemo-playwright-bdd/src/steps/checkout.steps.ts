import { expect, Then, When } from '../fixtures';
import { toCents } from '../utils/helpers';

/** SauceDemo charges 8% sales tax on the item total. */
const SALES_TAX_RATE = 0.08;

When('I proceed to checkout', async ({ cartPage }) => {
  await cartPage.checkout();
});

When('I fill the checkout form using Excel test case {string}', async ({ checkoutInfoPage, testData, world }, testCaseId: string) => {
  const row = await testData.checkoutCase(testCaseId);
  world.checkoutCase = row;
  await checkoutInfoPage.fillForm({
    firstName: row.FirstName,
    lastName: row.LastName,
    postalCode: row.PostalCode,
  });
});

When('I continue to the order overview', async ({ checkoutInfoPage }) => {
  await checkoutInfoPage.continue();
});

When('I cancel the checkout', async ({ checkoutInfoPage }) => {
  await checkoutInfoPage.cancel();
});

Then('I should see the checkout error defined for Excel test case {string}', async ({ testData, errorBanner }, testCaseId: string) => {
  const { ExpectedError } = await testData.checkoutCase(testCaseId);
  if (!ExpectedError) {
    throw new Error(`Excel test case "${testCaseId}" has no ExpectedError value`);
  }
  await errorBanner.expectMessage(ExpectedError);
});

Then('I should be on the order overview page', async ({ checkoutOverviewPage }) => {
  await checkoutOverviewPage.expectLoaded();
});

Then('the order overview should list the selected products', async ({ checkoutOverviewPage, world }) => {
  await checkoutOverviewPage.expectProducts([...world.selectedProducts]);
});

Then('the item total should equal the sum of the selected product prices', async ({ checkoutOverviewPage, testData, world }) => {
  const expectedCents = world.selectedProducts.reduce((sum, name) => sum + toCents(testData.product(name).price), 0);
  const itemTotal = await checkoutOverviewPage.getItemTotal();
  expect(toCents(itemTotal)).toBe(expectedCents);
});

Then('the order total should be the item total plus sales tax', async ({ checkoutOverviewPage }) => {
  const itemTotal = await checkoutOverviewPage.getItemTotal();
  const tax = await checkoutOverviewPage.getTax();
  const total = await checkoutOverviewPage.getTotal();

  // The app rounds tax to the cent, so allow a one cent difference against our own calculation.
  expect(Math.abs(toCents(tax) - toCents(itemTotal * SALES_TAX_RATE))).toBeLessThanOrEqual(1);
  expect(toCents(total)).toBe(toCents(itemTotal) + toCents(tax));
});

When('I finish the order', async ({ checkoutOverviewPage }) => {
  await checkoutOverviewPage.finish();
});

Then('I should see the order confirmation message {string}', async ({ checkoutCompletePage }, message: string) => {
  await checkoutCompletePage.expectConfirmation(message);
});

When('I go back to the products page', async ({ checkoutCompletePage }) => {
  await checkoutCompletePage.backToProducts();
});
