import fs from 'node:fs';
import path from 'node:path';
import winston from 'winston';
import { env } from '../config/env';
import { LOGS_DIR } from '../config/paths';

fs.mkdirSync(LOGS_DIR, { recursive: true });

const lineFormat = winston.format.printf(({ timestamp, level, message, context, stack }) => {
  const scope = context ? ` [${context}]` : '';
  return `${timestamp} ${String(level).toUpperCase().padEnd(5)}${scope} ${stack ?? message}`;
});

const transports: winston.transport[] = [
  new winston.transports.File({ filename: path.join(LOGS_DIR, 'test-run.log') }),
];
if (env.logToConsole) {
  transports.push(new winston.transports.Console());
}

/** Root logger shared by every worker. */
export const logger = winston.createLogger({
  level: env.logLevel,
  format: winston.format.combine(
    winston.format.errors({ stack: true }),
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
    lineFormat,
  ),
  transports,
});

export type Logger = winston.Logger;

/** Child logger that prefixes every line with `[context]` (page name, scenario title, ...). */
export const createLogger = (context: string): Logger => logger.child({ context });
