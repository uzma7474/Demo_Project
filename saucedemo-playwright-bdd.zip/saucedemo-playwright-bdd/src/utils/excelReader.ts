import ExcelJS from 'exceljs';
import fs from 'node:fs';
import path from 'node:path';
import { TEST_DATA_DIR } from '../config/paths';

export type ExcelRow = Record<string, string>;

/**
 * Reads `.xlsx` files from the `test-data` folder.
 * Row 1 is the header; every following row becomes an object keyed by header.
 * All cell values are returned as trimmed strings (empty cell -> '').
 */
export class ExcelReader {
  private static readonly workbooks = new Map<string, Promise<ExcelJS.Workbook>>();

  private static load(fileName: string): Promise<ExcelJS.Workbook> {
    const fullPath = path.resolve(TEST_DATA_DIR, fileName);

    if (!this.workbooks.has(fullPath)) {
      if (!fs.existsSync(fullPath)) {
        throw new Error(`Excel test data file not found: ${fullPath}`);
      }
      this.workbooks.set(fullPath, new ExcelJS.Workbook().xlsx.readFile(fullPath));
    }
    return this.workbooks.get(fullPath)!;
  }

  /** Returns every data row of a sheet. */
  static async readSheet<T = ExcelRow>(fileName: string, sheetName: string): Promise<T[]> {
    const workbook = await this.load(fileName);
    const sheet = workbook.getWorksheet(sheetName);
    if (!sheet) {
      const available = workbook.worksheets.map((ws) => ws.name).join(', ');
      throw new Error(`Sheet "${sheetName}" not found in ${fileName}. Available sheets: ${available}`);
    }

    const headers: string[] = [];
    sheet.getRow(1).eachCell({ includeEmpty: false }, (cell, columnNumber) => {
      headers[columnNumber] = cell.text.trim();
    });

    const rows: T[] = [];
    sheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      if (rowNumber === 1) return;
      const record: ExcelRow = {};
      headers.forEach((header, columnNumber) => {
        if (header) record[header] = row.getCell(columnNumber).text.trim();
      });
      rows.push(record as unknown as T);
    });
    return rows;
  }

  /** Returns the single row whose `keyColumn` equals `keyValue`. Throws if there is none. */
  static async findRow<T = ExcelRow>(
    fileName: string,
    sheetName: string,
    keyColumn: string,
    keyValue: string,
  ): Promise<T> {
    const rows = await this.readSheet<ExcelRow>(fileName, sheetName);
    const match = rows.find((row) => row[keyColumn] === keyValue);
    if (!match) {
      throw new Error(`No row with ${keyColumn}="${keyValue}" in sheet "${sheetName}" of ${fileName}`);
    }
    return match as unknown as T;
  }
}
