import fs from 'node:fs';
import path from 'node:path';
import { TEST_DATA_DIR } from '../config/paths';

/**
 * Reads JSON files from the `test-data` folder.
 * Files are parsed once per worker and every caller gets its own deep copy,
 * so a step can mutate the data without affecting other scenarios.
 */
export class JsonReader {
  private static readonly cache = new Map<string, unknown>();

  static read<T>(fileName: string): T {
    const fullPath = path.resolve(TEST_DATA_DIR, fileName);

    if (!this.cache.has(fullPath)) {
      if (!fs.existsSync(fullPath)) {
        throw new Error(`JSON test data file not found: ${fullPath}`);
      }
      try {
        this.cache.set(fullPath, JSON.parse(fs.readFileSync(fullPath, 'utf-8')));
      } catch (error) {
        throw new Error(`Invalid JSON in ${fullPath}: ${(error as Error).message}`);
      }
    }

    return structuredClone(this.cache.get(fullPath)) as T;
  }
}
