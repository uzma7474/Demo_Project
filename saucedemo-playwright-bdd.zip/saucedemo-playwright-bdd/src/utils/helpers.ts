/** "$29.99" or "Item total: $39.98" -> 29.99 / 39.98 */
export const parsePrice = (text: string): number => {
  const match = text.match(/\$\s*([\d,]+(?:\.\d+)?)/);
  if (!match) {
    throw new Error(`Could not find a price in text: "${text}"`);
  }
  return Number(match[1].replace(/,/g, ''));
};

/** Money arithmetic in integer cents avoids floating point surprises (0.1 + 0.2). */
export const toCents = (amount: number): number => Math.round(amount * 100);

export const escapeRegExp = (text: string): string => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** Minimal shape of a Gherkin data table, enough for the steps in this project. */
export interface GherkinTable {
  raw(): string[][];
}
