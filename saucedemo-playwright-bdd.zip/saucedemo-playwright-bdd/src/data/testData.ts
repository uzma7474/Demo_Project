import type { CheckoutCase, Product, UserCredentials, UsersFile } from '../types/testdata';
import { ExcelReader } from '../utils/excelReader';
import { JsonReader } from '../utils/jsonReader';

export const USERS_FILE = 'users.json';
export const PRODUCTS_FILE = 'products.json';
export const CHECKOUT_FILE = 'checkout-data.xlsx';
export const CHECKOUT_SHEET = 'Checkout';

/**
 * Single entry point for test data, exposed to steps through the `testData` fixture.
 * JSON holds static reference data (users, catalogue); Excel holds data-driven cases.
 */
export class TestDataProvider {
  user(key: string): UserCredentials {
    const users = JsonReader.read<UsersFile>(USERS_FILE);
    const user = users[key];
    if (!user) {
      throw new Error(`Unknown user key "${key}" in ${USERS_FILE}. Known keys: ${Object.keys(users).join(', ')}`);
    }
    return user;
  }

  products(): Product[] {
    return JsonReader.read<Product[]>(PRODUCTS_FILE);
  }

  product(name: string): Product {
    const product = this.products().find((p) => p.name === name);
    if (!product) {
      throw new Error(`Product "${name}" not found in ${PRODUCTS_FILE}`);
    }
    return product;
  }

  checkoutCase(testCaseId: string): Promise<CheckoutCase> {
    return ExcelReader.findRow<CheckoutCase>(CHECKOUT_FILE, CHECKOUT_SHEET, 'TestCaseId', testCaseId);
  }
}
