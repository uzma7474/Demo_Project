import type { CheckoutCase, UserCredentials } from '../types/testdata';

/**
 * Scenario "world": state shared between the steps of ONE scenario.
 *
 * playwright-bdd has no Cucumber-style `this`, so the CustomWorld pattern is a
 * fixture. A new instance is created for every scenario (see `world` in
 * src/fixtures/index.ts), which keeps parallel scenarios isolated.
 */
export class ScenarioContext {
  currentUser?: UserCredentials;
  checkoutCase?: CheckoutCase;

  /** Products added to the cart in this scenario, in the order they were added. */
  private readonly products: string[] = [];

  get selectedProducts(): readonly string[] {
    return this.products;
  }

  addProduct(name: string): void {
    if (!this.products.includes(name)) this.products.push(name);
  }

  removeProduct(name: string): void {
    const index = this.products.indexOf(name);
    if (index >= 0) this.products.splice(index, 1);
  }

  /** Free-form key/value store for one-off values that do not deserve a field. */
  private readonly store = new Map<string, unknown>();

  set<T>(key: string, value: T): void {
    this.store.set(key, value);
  }

  get<T>(key: string): T | undefined {
    return this.store.get(key) as T | undefined;
  }
}
