import { test as base, createBdd } from 'playwright-bdd';
import { TestDataProvider } from '../data/testData';
import { CartPage } from '../pages/CartPage';
import { CheckoutCompletePage } from '../pages/CheckoutCompletePage';
import { CheckoutInfoPage } from '../pages/CheckoutInfoPage';
import { CheckoutOverviewPage } from '../pages/CheckoutOverviewPage';
import { ErrorBanner } from '../pages/components/ErrorBanner';
import { HeaderComponent } from '../pages/components/HeaderComponent';
import { InventoryPage } from '../pages/InventoryPage';
import { LoginPage } from '../pages/LoginPage';
import { createLogger, type Logger } from '../utils/logger';
import { ScenarioContext } from './world';

type PageFixtures = {
  loginPage: LoginPage;
  inventoryPage: InventoryPage;
  cartPage: CartPage;
  checkoutInfoPage: CheckoutInfoPage;
  checkoutOverviewPage: CheckoutOverviewPage;
  checkoutCompletePage: CheckoutCompletePage;
  header: HeaderComponent;
  errorBanner: ErrorBanner;
};

type SupportFixtures = {
  /** Per-scenario shared state (the "CustomWorld"). */
  world: ScenarioContext;
  /** Access to JSON / Excel test data. */
  testData: TestDataProvider;
  /** Logger prefixed with the scenario title. */
  log: Logger;
};

/**
 * Every fixture is created lazily and per scenario: a page object is only
 * constructed when a step (or hook) actually asks for it.
 */
export const test = base.extend<PageFixtures & SupportFixtures>({
  loginPage: async ({ page }, use) => use(new LoginPage(page)),
  inventoryPage: async ({ page }, use) => use(new InventoryPage(page)),
  cartPage: async ({ page }, use) => use(new CartPage(page)),
  checkoutInfoPage: async ({ page }, use) => use(new CheckoutInfoPage(page)),
  checkoutOverviewPage: async ({ page }, use) => use(new CheckoutOverviewPage(page)),
  checkoutCompletePage: async ({ page }, use) => use(new CheckoutCompletePage(page)),
  header: async ({ page }, use) => use(new HeaderComponent(page)),
  errorBanner: async ({ page }, use) => use(new ErrorBanner(page)),

  world: async ({}, use) => use(new ScenarioContext()),
  testData: async ({}, use) => use(new TestDataProvider()),
  log: async ({}, use, testInfo) => use(createLogger(testInfo.title)),
});

export const { Given, When, Then, Before, After, BeforeAll, AfterAll } = createBdd(test);

export { expect } from '@playwright/test';
