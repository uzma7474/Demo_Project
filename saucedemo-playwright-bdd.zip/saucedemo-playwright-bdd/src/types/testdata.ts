export interface UserCredentials {
  username: string;
  password: string;
  description?: string;
  /** Message shown by the app when this user tries to log in (negative scenarios). */
  expectedError?: string;
}

export type UsersFile = Record<string, UserCredentials>;

export interface Product {
  name: string;
  price: number;
  description?: string;
}

/** One row of `test-data/checkout-data.xlsx`, sheet "Checkout". */
export type CheckoutCase = {
  TestCaseId: string;
  Description: string;
  FirstName: string;
  LastName: string;
  PostalCode: string;
  /** Empty for the happy path. */
  ExpectedError: string;
};

export interface CheckoutInfo {
  firstName: string;
  lastName: string;
  postalCode: string;
}
