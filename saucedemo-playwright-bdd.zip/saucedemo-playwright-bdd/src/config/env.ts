import dotenv from 'dotenv';
import path from 'node:path';
import { ROOT_DIR } from './paths';

/**
 * Loads `.env` by default, or `.env.<TEST_ENV>` when TEST_ENV is set
 * (e.g. `TEST_ENV=staging npm test` loads `.env.staging`).
 * Real environment variables always win over values from the file.
 */
const envFile = process.env.TEST_ENV ? `.env.${process.env.TEST_ENV}` : '.env';
dotenv.config({ path: path.join(ROOT_DIR, envFile) });

const toBool = (value: string | undefined, fallback: boolean): boolean =>
  value === undefined || value === '' ? fallback : ['1', 'true', 'yes', 'on'].includes(value.toLowerCase());

const toNumber = (value: string | undefined, fallback: number): number => {
  if (value === undefined || value === '') return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

export const env = Object.freeze({
  baseUrl: process.env.BASE_URL || 'https://www.saucedemo.com',
  headless: toBool(process.env.HEADLESS, true),
  slowMo: toNumber(process.env.SLOW_MO, 0),
  retries: toNumber(process.env.RETRIES, process.env.CI ? 1 : 0),
  workers: process.env.WORKERS ? toNumber(process.env.WORKERS, 1) : undefined,
  timeout: toNumber(process.env.TEST_TIMEOUT, 30_000),
  expectTimeout: toNumber(process.env.EXPECT_TIMEOUT, 5_000),
  actionTimeout: toNumber(process.env.ACTION_TIMEOUT, 10_000),
  navigationTimeout: toNumber(process.env.NAVIGATION_TIMEOUT, 20_000),
  logLevel: process.env.LOG_LEVEL || 'info',
  logToConsole: toBool(process.env.LOG_TO_CONSOLE, true),
});
