import path from 'node:path';

/** Absolute project root (this file lives in <root>/src/config). */
export const ROOT_DIR = path.resolve(__dirname, '..', '..');
export const TEST_DATA_DIR = path.join(ROOT_DIR, 'test-data');
export const LOGS_DIR = path.join(ROOT_DIR, 'logs');
