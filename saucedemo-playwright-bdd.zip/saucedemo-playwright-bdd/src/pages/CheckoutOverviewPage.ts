import { expect, type Locator, type Page } from '@playwright/test';
import { parsePrice } from '../utils/helpers';
import { BasePage } from './BasePage';

/** Checkout step two: "Overview". */
export class CheckoutOverviewPage extends BasePage {
  protected readonly path = '/checkout-step-two.html';

  private readonly itemNames: Locator;
  private readonly subtotalLabel: Locator;
  private readonly taxLabel: Locator;
  private readonly totalLabel: Locator;
  private readonly finishButton: Locator;

  constructor(page: Page) {
    super(page, 'CheckoutOverviewPage');
    this.itemNames = page.getByTestId('inventory-item-name');
    this.subtotalLabel = page.getByTestId('subtotal-label');
    this.taxLabel = page.getByTestId('tax-label');
    this.totalLabel = page.getByTestId('total-label');
    this.finishButton = page.getByTestId('finish');
  }

  async expectProducts(expectedNames: string[]): Promise<void> {
    await expect(this.itemNames).toHaveText(expectedNames);
  }

  async getItemTotal(): Promise<number> {
    return parsePrice(await this.subtotalLabel.innerText());
  }

  async getTax(): Promise<number> {
    return parsePrice(await this.taxLabel.innerText());
  }

  async getTotal(): Promise<number> {
    return parsePrice(await this.totalLabel.innerText());
  }

  async finish(): Promise<void> {
    await this.click(this.finishButton, 'finish button');
  }
}
