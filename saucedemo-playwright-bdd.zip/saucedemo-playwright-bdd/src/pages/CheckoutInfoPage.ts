import type { Locator, Page } from '@playwright/test';
import type { CheckoutInfo } from '../types/testdata';
import { BasePage } from './BasePage';

/** Checkout step one: "Your Information". */
export class CheckoutInfoPage extends BasePage {
  protected readonly path = '/checkout-step-one.html';

  private readonly firstNameInput: Locator;
  private readonly lastNameInput: Locator;
  private readonly postalCodeInput: Locator;
  private readonly continueButton: Locator;
  private readonly cancelButton: Locator;

  constructor(page: Page) {
    super(page, 'CheckoutInfoPage');
    this.firstNameInput = page.getByTestId('firstName');
    this.lastNameInput = page.getByTestId('lastName');
    this.postalCodeInput = page.getByTestId('postalCode');
    this.continueButton = page.getByTestId('continue');
    this.cancelButton = page.getByTestId('cancel');
  }

  async fillForm(info: CheckoutInfo): Promise<void> {
    await this.fill(this.firstNameInput, info.firstName, 'first name');
    await this.fill(this.lastNameInput, info.lastName, 'last name');
    await this.fill(this.postalCodeInput, info.postalCode, 'postal code');
  }

  async continue(): Promise<void> {
    await this.click(this.continueButton, 'continue button');
  }

  async cancel(): Promise<void> {
    await this.click(this.cancelButton, 'cancel button');
  }
}
