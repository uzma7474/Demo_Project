import { expect, type Locator, type Page } from '@playwright/test';
import { parsePrice } from '../utils/helpers';
import { BasePage } from './BasePage';

export const SORT_OPTIONS = [
  'Name (A to Z)',
  'Name (Z to A)',
  'Price (low to high)',
  'Price (high to low)',
] as const;
export type SortOption = (typeof SORT_OPTIONS)[number];

export class InventoryPage extends BasePage {
  protected readonly path = '/inventory.html';

  private readonly items: Locator;
  private readonly itemNames: Locator;
  private readonly itemPrices: Locator;
  private readonly sortDropdown: Locator;

  constructor(page: Page) {
    super(page, 'InventoryPage');
    this.items = page.getByTestId('inventory-item');
    this.itemNames = page.getByTestId('inventory-item-name');
    this.itemPrices = page.getByTestId('inventory-item-price');
    this.sortDropdown = page.getByTestId('product-sort-container');
  }

  /** The card of one product, matched on its exact name. */
  private itemCard(productName: string): Locator {
    return this.items.filter({ has: this.page.getByText(productName, { exact: true }) });
  }

  async addToCart(productName: string): Promise<void> {
    await this.click(this.itemCard(productName).getByRole('button', { name: /add to cart/i }), `add "${productName}"`);
  }

  async removeFromCart(productName: string): Promise<void> {
    await this.click(this.itemCard(productName).getByRole('button', { name: /remove/i }), `remove "${productName}"`);
  }

  async sortBy(option: SortOption): Promise<void> {
    this.log.info(`Sorting by "${option}"`);
    await this.sortDropdown.selectOption({ label: option });
  }

  async getProductNames(): Promise<string[]> {
    return this.itemNames.allInnerTexts();
  }

  async getProductPrices(): Promise<number[]> {
    const texts = await this.itemPrices.allInnerTexts();
    return texts.map(parsePrice);
  }

  async expectProductCount(expected: number): Promise<void> {
    await expect(this.items).toHaveCount(expected);
  }

  async expectButtonState(productName: string, state: 'add' | 'remove'): Promise<void> {
    const name = state === 'add' ? /add to cart/i : /remove/i;
    await expect(this.itemCard(productName).getByRole('button', { name })).toBeVisible();
  }
}
