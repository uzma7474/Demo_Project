import { expect, type Locator, type Page } from '@playwright/test';

/** The red error banner used by both the login form and the checkout form. */
export class ErrorBanner {
  private readonly banner: Locator;

  constructor(page: Page) {
    this.banner = page.getByTestId('error');
  }

  async expectMessage(message: string): Promise<void> {
    await expect(this.banner).toBeVisible();
    await expect(this.banner).toHaveText(message);
  }

  async expectHidden(): Promise<void> {
    await expect(this.banner).toBeHidden();
  }
}
