import { expect, type Locator, type Page } from '@playwright/test';
import { createLogger } from '../../utils/logger';

/** Header + side menu shared by every page after login. */
export class HeaderComponent {
  private readonly log = createLogger('HeaderComponent');

  private readonly menuButton: Locator;
  private readonly logoutLink: Locator;
  private readonly cartLink: Locator;
  private readonly cartBadge: Locator;

  constructor(page: Page) {
    this.menuButton = page.locator('#react-burger-menu-btn');
    this.logoutLink = page.getByTestId('logout-sidebar-link');
    this.cartLink = page.getByTestId('shopping-cart-link');
    this.cartBadge = page.getByTestId('shopping-cart-badge');
  }

  async openCart(): Promise<void> {
    this.log.info('Opening cart');
    await this.cartLink.click();
  }

  async logout(): Promise<void> {
    this.log.info('Logging out');
    await this.menuButton.click();
    await this.logoutLink.click();
  }

  /** The badge is not rendered at all when the cart is empty. */
  async getCartCount(): Promise<number> {
    if ((await this.cartBadge.count()) === 0) return 0;
    return Number(await this.cartBadge.innerText());
  }

  async expectCartCount(expected: number): Promise<void> {
    if (expected === 0) {
      await expect(this.cartBadge).toHaveCount(0);
    } else {
      await expect(this.cartBadge).toHaveText(String(expected));
    }
  }
}
