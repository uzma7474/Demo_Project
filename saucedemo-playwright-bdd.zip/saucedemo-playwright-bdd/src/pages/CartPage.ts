import { expect, type Locator, type Page } from '@playwright/test';
import { BasePage } from './BasePage';

export class CartPage extends BasePage {
  protected readonly path = '/cart.html';

  private readonly items: Locator;
  private readonly itemNames: Locator;
  private readonly checkoutButton: Locator;
  private readonly continueShoppingButton: Locator;

  constructor(page: Page) {
    super(page, 'CartPage');
    this.items = page.getByTestId('inventory-item');
    this.itemNames = page.getByTestId('inventory-item-name');
    this.checkoutButton = page.getByTestId('checkout');
    this.continueShoppingButton = page.getByTestId('continue-shopping');
  }

  async removeProduct(productName: string): Promise<void> {
    const card = this.items.filter({ has: this.page.getByText(productName, { exact: true }) });
    await this.click(card.getByRole('button', { name: /remove/i }), `remove "${productName}"`);
  }

  async checkout(): Promise<void> {
    await this.click(this.checkoutButton, 'checkout button');
  }

  async continueShopping(): Promise<void> {
    await this.click(this.continueShoppingButton, 'continue shopping button');
  }

  /** Exact, ordered comparison of the product names listed in the cart. */
  async expectProducts(expectedNames: string[]): Promise<void> {
    await expect(this.itemNames).toHaveText(expectedNames);
  }

  async expectEmpty(): Promise<void> {
    await expect(this.items).toHaveCount(0);
  }
}
