import { expect, type Locator, type Page } from '@playwright/test';
import { BasePage } from './BasePage';

/** Final "Thank you for your order!" page. */
export class CheckoutCompletePage extends BasePage {
  protected readonly path = '/checkout-complete.html';

  private readonly header: Locator;
  private readonly backHomeButton: Locator;

  constructor(page: Page) {
    super(page, 'CheckoutCompletePage');
    this.header = page.getByTestId('complete-header');
    this.backHomeButton = page.getByTestId('back-to-products');
  }

  async expectConfirmation(message: string): Promise<void> {
    await expect(this.header).toHaveText(message);
  }

  async backToProducts(): Promise<void> {
    await this.click(this.backHomeButton, 'back home button');
  }
}
