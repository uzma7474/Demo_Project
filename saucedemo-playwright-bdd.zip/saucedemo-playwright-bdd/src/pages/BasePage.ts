import { expect, type Locator, type Page } from '@playwright/test';
import { escapeRegExp } from '../utils/helpers';
import { createLogger, type Logger } from '../utils/logger';

/**
 * Base class for every page object.
 * - Holds the Playwright `page` and a logger scoped to the page name.
 * - Provides logged `click` / `fill` wrappers so every interaction shows up in logs/test-run.log.
 * - Page objects expose actions and state; assertions on page state live in `expect*` methods
 *   so step definitions stay one-liners.
 */
export abstract class BasePage {
  protected readonly log: Logger;

  /** Path relative to baseURL, e.g. `/inventory.html`. */
  protected abstract readonly path: string;

  protected constructor(
    protected readonly page: Page,
    pageName: string,
  ) {
    this.log = createLogger(pageName);
  }

  async open(): Promise<void> {
    this.log.info(`Opening ${this.path}`);
    await this.page.goto(this.path);
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(new RegExp(`${escapeRegExp(this.path)}$`));
  }

  protected async click(locator: Locator, description: string): Promise<void> {
    this.log.info(`Click: ${description}`);
    await locator.click();
  }

  protected async fill(locator: Locator, value: string, description: string): Promise<void> {
    this.log.info(`Fill: ${description}`);
    await locator.fill(value);
  }
}
