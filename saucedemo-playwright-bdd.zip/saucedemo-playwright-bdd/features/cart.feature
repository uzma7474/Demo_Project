@loggedin @cart
Feature: Shopping cart
  As a logged in shopper
  I want to review and change the contents of my cart
  So that I only buy what I need

  Background:
    Given I am on the products page

  @smoke
  Scenario: Added products appear in the cart
    When I add the following products to the cart:
      | Sauce Labs Backpack   |
      | Sauce Labs Bike Light |
    And I open the cart
    Then the cart should contain the following products:
      | Sauce Labs Backpack   |
      | Sauce Labs Bike Light |

  Scenario: A product can be removed from the cart page
    When I add the following products to the cart:
      | Sauce Labs Onesie |
      | Sauce Labs Fleece Jacket |
    And I open the cart
    And I remove "Sauce Labs Onesie" from the cart page
    Then the cart should contain the following products:
      | Sauce Labs Fleece Jacket |

  Scenario: Removing the last product empties the cart
    When I add "Sauce Labs Bolt T-Shirt" to the cart
    And I open the cart
    And I remove "Sauce Labs Bolt T-Shirt" from the cart page
    Then the cart should be empty
    And the cart badge should show 0

  Scenario: Continue shopping returns to the product list
    When I open the cart
    And I continue shopping
    Then I should land on the products page
