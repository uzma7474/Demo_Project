@loggedin @checkout
Feature: Checkout
  As a logged in shopper
  I want to complete my purchase
  So that my order is placed

  Background:
    Given I am on the products page

  @smoke @e2e
  Scenario: Complete an end-to-end purchase
    When I add the following products to the cart:
      | Sauce Labs Backpack |
      | Sauce Labs Onesie   |
    And I open the cart
    And I proceed to checkout
    And I fill the checkout form using Excel test case "TC_VALID_01"
    And I continue to the order overview
    Then I should be on the order overview page
    And the order overview should list the selected products
    And the item total should equal the sum of the selected product prices
    And the order total should be the item total plus sales tax
    When I finish the order
    Then I should see the order confirmation message "Thank you for your order!"
    When I go back to the products page
    Then I should land on the products page
    And the cart badge should show 0

  @negative
  Scenario Outline: Checkout form validation driven by Excel data
    When I add "Sauce Labs Backpack" to the cart
    And I open the cart
    And I proceed to checkout
    And I fill the checkout form using Excel test case "<testCaseId>"
    And I continue to the order overview
    Then I should see the checkout error defined for Excel test case "<testCaseId>"

    Examples:
      | testCaseId        |
      | TC_MISSING_FIRST  |
      | TC_MISSING_LAST   |
      | TC_MISSING_POSTAL |

  Scenario: Cancelling checkout returns to the cart
    When I add "Sauce Labs Bike Light" to the cart
    And I open the cart
    And I proceed to checkout
    And I cancel the checkout
    Then I should see the cart page
