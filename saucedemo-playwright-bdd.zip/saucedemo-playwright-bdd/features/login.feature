@login
Feature: Login
  As a registered shopper
  I want to log in with my credentials
  So that I can browse and buy products

  Background:
    Given I am on the login page

  @smoke
  Scenario: Successful login with a standard user
    When I log in as the "standard" user from test data
    Then I should land on the products page

  Scenario Outline: Non-blocked users can log in
    When I log in as the "<userKey>" user from test data
    Then I should land on the products page

    Examples:
      | userKey           |
      | problem           |
      | performanceGlitch |
      | error             |
      | visual            |

  @negative
  Scenario Outline: Login is rejected for locked out and unknown users
    When I log in as the "<userKey>" user from test data
    Then I should see the login error from test data for "<userKey>"

    Examples:
      | userKey   |
      | lockedOut |
      | invalid   |

  @negative
  Scenario Outline: Mandatory field validation
    When I log in with username "<username>" and password "<password>"
    Then I should see the error message "<message>"

    Examples:
      | username      | password     | message                                    |
      |               |              | Epic sadface: Username is required         |
      | standard_user |              | Epic sadface: Password is required         |
      |               | secret_sauce | Epic sadface: Username is required         |
      | standard_user | wrong_pass   | Epic sadface: Username and password do not match any user in this service |

  @loggedin @smoke
  Scenario: A logged in user can log out
    When I log out
    Then I should be back on the login page
