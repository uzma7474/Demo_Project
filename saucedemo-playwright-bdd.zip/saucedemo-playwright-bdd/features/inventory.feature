@loggedin @inventory
Feature: Product inventory
  As a logged in shopper
  I want to browse, sort and select products
  So that I can find what I want to buy

  Background:
    Given I am on the products page

  @smoke
  Scenario: The catalogue lists every product with the right price
    Then I should see 6 products
    And I should see all products from test data with their prices

  Scenario Outline: Products can be sorted
    When I sort products by "<option>"
    Then the products should be ordered by "<option>"

    Examples:
      | option              |
      | Name (A to Z)       |
      | Name (Z to A)       |
      | Price (low to high) |
      | Price (high to low) |

  @smoke
  Scenario: Adding and removing products updates the cart badge
    When I add "Sauce Labs Backpack" to the cart
    And I add "Sauce Labs Bike Light" to the cart
    Then the cart badge should show 2
    When I remove "Sauce Labs Backpack" from the cart
    Then the cart badge should show 1
    And the button for "Sauce Labs Backpack" should offer "Add to cart"
    And the button for "Sauce Labs Bike Light" should offer "Remove"
