/**
 * Regenerates test-data/checkout-data.xlsx.
 * Run with: npm run generate:data
 *
 * Handy when you want to add columns/rows in code; otherwise just edit the
 * workbook in Excel - the framework reads whatever is in the "Checkout" sheet.
 */
import ExcelJS from 'exceljs';
import path from 'node:path';
import { TEST_DATA_DIR } from '../src/config/paths';
import { CHECKOUT_SHEET } from '../src/data/testData';

const header = ['TestCaseId', 'Description', 'FirstName', 'LastName', 'PostalCode', 'ExpectedError'];

const rows: string[][] = [
  ['TC_VALID_01', 'All fields supplied - happy path', 'John', 'Smith', '411001', ''],
  ['TC_VALID_02', 'Alternate valid customer', 'Jane', 'Doe', '90210', ''],
  ['TC_MISSING_FIRST', 'First name omitted', '', 'Smith', '411001', 'Error: First Name is required'],
  ['TC_MISSING_LAST', 'Last name omitted', 'John', '', '411001', 'Error: Last Name is required'],
  ['TC_MISSING_POSTAL', 'Postal code omitted', 'John', 'Smith', '', 'Error: Postal Code is required'],
];

async function main(): Promise<void> {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet(CHECKOUT_SHEET);

  sheet.addRow(header);
  rows.forEach((row) => sheet.addRow(row));

  sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E78' } };
  [20, 34, 14, 14, 14, 36].forEach((width, index) => {
    sheet.getColumn(index + 1).width = width;
  });
  sheet.views = [{ state: 'frozen', ySplit: 1 }];

  const target = path.join(TEST_DATA_DIR, 'checkout-data.xlsx');
  await workbook.xlsx.writeFile(target);
  console.log(`Written ${target}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
