# Restful Booker - Playwright + Cucumber + TypeScript API Framework

BDD API automation for https://restful-booker.herokuapp.com/apidoc/index.html using
Playwright's `APIRequestContext`, Cucumber-js, TypeScript, Winston logging, ExcelJS / JSON data utilities.

| Group   | Endpoint                | Feature file                  |
|---------|-------------------------|-------------------------------|
| Auth    | POST /auth              | auth.feature                  |
| Booking | GET /booking (+filters) | get_bookings.feature          |
| Booking | GET /booking/{id}       | get_bookings.feature          |
| Booking | POST /booking           | create_booking.feature        |
| Booking | PUT /booking/{id}       | update_booking.feature        |
| Booking | PATCH /booking/{id}     | partial_update_booking.feature|
| Booking | DELETE /booking/{id}    | delete_booking.feature        |
| Ping    | GET /ping               | ping.feature                  |

## Setup & run
```
npm install
cp .env.example .env            # optional; defaults point to the public sandbox
npm test                        # all 34 scenario executions
npm run test:smoke              # @smoke   (also: test:regression, test:negative)
TAGS="@excel-data or @json-data" npm test
npm run test:parallel           # PARALLEL=4 workers
RETRY=1 npm test                # retry failed scenarios once (Heroku cold starts)
npm run test:report             # clean, run, build the multi-page HTML report
npm run typecheck
```

## Structure
```
features/                 Gherkin scenarios (tags: @smoke @regression @negative @excel-data @json-data)
src/config/env.ts         dotenv + typed config (.env, .env.<ENV>, process env wins)
src/core/ApiClient.ts     wraps APIRequestContext: timing, logging, secret masking, transcript sink
src/core/TokenManager.ts  one cached admin token per worker process
src/api/                  AuthApi, BookingApi (token / basic / none auth modes), PingApi
src/models/booking.ts     TypeScript interfaces for payloads and responses
src/utils/                logger (winston), excelUtils (exceljs), jsonUtils, payloadBuilder (faker), schemaValidator (ajv)
src/support/world.ts      per-scenario World (request context, state, API objects)
src/support/hooks.ts      Before/After: logger context, cleanup of created bookings, dispose
src/steps/                step definitions (common, auth, booking, ping)
test-data/                bookings.xlsx (sheet CreateBooking, key testCaseId), bookings.json
schemas/                  JSON schemas for response validation
scripts/generate-report.ts  multiple-cucumber-html-reporter
```

## Reports and logs
* `reports/cucumber-report.html` - built-in Cucumber HTML (HTTP transcripts attached per scenario)
* `reports/json/cucumber-report.json` - raw results, feeds `npm run report` -> `reports/html/index.html`
* `logs/automation-<date>.log` (rotating, zipped, 14 days) and `logs/error.log`; scenario name on each line

## API behaviours encoded in the tests
* Bad credentials return 200 `{"reason":"Bad credentials"}`.
* DELETE success is 201 `Created`; PUT/DELETE on a missing id is 405.
* PUT/PATCH/DELETE without a valid token or basic auth is 403.
* POST with missing fields is 500; malformed JSON is expected to be 400 (adjust in `create_booking.feature` if the live service differs).
