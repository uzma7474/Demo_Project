import Ajv from 'ajv';
import { readJson } from './jsonUtils';

const ajv = new Ajv({ allErrors: true, strict: false });

/** Validates data against schemas/<schemaFile>. Returns a list of readable errors (empty = valid). */
export function validateSchema(schemaFile: string, data: unknown): string[] {
  const schema = readJson<object>(`schemas/${schemaFile}`);
  const validate = ajv.compile(schema);
  validate(data);
  return (validate.errors ?? []).map((e) => `${e.instancePath || '/'} ${e.message}`);
}
