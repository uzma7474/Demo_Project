import * as winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import { config } from '../config/env';

const line = winston.format.printf(({ timestamp, level, message, scenario }) => {
  const tag = scenario ? ` [${scenario}]` : '';
  return `${timestamp} ${level.toUpperCase().padEnd(5)}${tag} - ${message}`;
});

/** Root logger: coloured console + rotating daily file + separate error file. */
export const logger = winston.createLogger({
  level: config.logLevel,
  format: winston.format.combine(winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }), line),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(winston.format.colorize({ all: false }), winston.format.timestamp({ format: 'HH:mm:ss.SSS' }), line),
    }),
    new DailyRotateFile({
      dirname: 'logs',
      filename: 'automation-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxSize: '10m',
      maxFiles: '14d',
      zippedArchive: true,
    }),
    new winston.transports.File({ dirname: 'logs', filename: 'error.log', level: 'error' }),
  ],
});

/** Child logger that stamps every line with the scenario name. */
export const scenarioLogger = (scenario: string): winston.Logger => logger.child({ scenario });
export type Logger = winston.Logger;
