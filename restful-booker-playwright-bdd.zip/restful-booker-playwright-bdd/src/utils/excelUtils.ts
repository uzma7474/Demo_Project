import * as ExcelJS from 'exceljs';
import * as fs from 'fs';
import * as path from 'path';

export type Row = Record<string, string>;

/**
 * Excel helpers (ExcelJS). Row 1 of each sheet is the header; each following row becomes
 * an object { header: value }. All values are returned as trimmed strings.
 */
export async function readSheet(file: string, sheetName: string): Promise<Row[]> {
  const full = path.resolve(process.cwd(), file);
  if (!fs.existsSync(full)) throw new Error(`Excel file not found: ${full}`);

  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(full);
  const sheet = wb.getWorksheet(sheetName);
  if (!sheet) throw new Error(`Sheet not found: ${sheetName}`);

  const headers: string[] = [];
  sheet.getRow(1).eachCell({ includeEmpty: true }, (cell, col) => {
    headers[col] = cell.text.trim();
  });

  const rows: Row[] = [];
  sheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    const item: Row = {};
    headers.forEach((h, col) => {
      if (h) item[h] = row.getCell(col).text.trim();
    });
    rows.push(item);
  });
  return rows;
}

/** Returns the row whose "testCaseId" column equals the given id. */
export async function getRow(file: string, sheetName: string, testCaseId: string): Promise<Row> {
  const rows = await readSheet(file, sheetName);
  const row = rows.find((r) => r.testCaseId === testCaseId);
  if (!row) throw new Error(`No row with testCaseId=${testCaseId} in sheet ${sheetName}`);
  return row;
}

/** Writes rows to a new workbook (e.g. an execution-summary export). */
export async function writeSheet(file: string, sheetName: string, rows: Row[]): Promise<void> {
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet(sheetName);
  if (rows.length > 0) {
    const headers = Object.keys(rows[0]);
    sheet.columns = headers.map((h) => ({ header: h, key: h, width: Math.max(14, h.length + 4) }));
    sheet.getRow(1).font = { bold: true };
    rows.forEach((r) => sheet.addRow(r));
  }
  const full = path.resolve(process.cwd(), file);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  await wb.xlsx.writeFile(full);
}
