import * as fs from 'fs';
import * as path from 'path';

/** Reads and parses a JSON file relative to the project root. */
export function readJson<T>(relativePath: string): T {
  const full = path.resolve(process.cwd(), relativePath);
  if (!fs.existsSync(full)) throw new Error(`JSON file not found: ${full}`);
  return JSON.parse(fs.readFileSync(full, 'utf-8')) as T;
}

export function writeJson(relativePath: string, data: unknown): void {
  const full = path.resolve(process.cwd(), relativePath);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, JSON.stringify(data, null, 2), 'utf-8');
}
