import { faker } from '@faker-js/faker';
import { Booking, PartialBooking } from '../models/booking';
import { Row } from './excelUtils';

const NEEDS = ['Breakfast', 'Lunch', 'Dinner', 'Late checkout', 'Parking'];
const iso = (d: Date): string => d.toISOString().slice(0, 10);

/** Random, valid booking (dates in the future, checkout after checkin). */
export function randomBooking(): Booking {
  const checkin = faker.date.soon({ days: 30 });
  const checkout = new Date(checkin.getTime() + faker.number.int({ min: 1, max: 14 }) * 86_400_000);
  return {
    firstname: faker.person.firstName(),
    lastname: faker.person.lastName(),
    totalprice: faker.number.int({ min: 100, max: 2000 }),
    depositpaid: faker.datatype.boolean(),
    bookingdates: { checkin: iso(checkin), checkout: iso(checkout) },
    additionalneeds: faker.helpers.arrayElement(NEEDS),
  };
}

/** Builds a booking from an Excel row (columns: firstname,lastname,totalprice,depositpaid,checkin,checkout,additionalneeds). */
export function bookingFromRow(row: Row): Booking {
  return {
    firstname: row.firstname,
    lastname: row.lastname,
    totalprice: Number(row.totalprice),
    depositpaid: row.depositpaid.toLowerCase() === 'true',
    bookingdates: { checkin: row.checkin, checkout: row.checkout },
    additionalneeds: row.additionalneeds,
  };
}

export const partialBooking = (fields: PartialBooking): PartialBooking => fields;
