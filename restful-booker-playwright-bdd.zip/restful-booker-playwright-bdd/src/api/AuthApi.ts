import { ApiClient, ApiResponse } from '../core/ApiClient';
import { AuthRequest } from '../models/booking';

/** POST /auth - CreateToken */
export class AuthApi {
  constructor(private readonly client: ApiClient) {}

  createToken(username: string, password: string): Promise<ApiResponse<{ token?: string; reason?: string }>> {
    const body: AuthRequest = { username, password };
    return this.client.send('POST', '/auth', { data: body });
  }
}
