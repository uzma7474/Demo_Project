import { ApiClient, ApiResponse } from '../core/ApiClient';

/** GET /ping - HealthCheck */
export class PingApi {
  constructor(private readonly client: ApiClient) {}

  healthCheck(): Promise<ApiResponse> {
    return this.client.send('GET', '/ping');
  }
}
