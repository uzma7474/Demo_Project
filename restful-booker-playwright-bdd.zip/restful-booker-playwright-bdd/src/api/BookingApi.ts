import { ApiClient, ApiResponse } from '../core/ApiClient';
import { Booking, BookingIdItem, CreateBookingResponse, PartialBooking } from '../models/booking';

/** Auth strategies supported by the API for PUT / PATCH / DELETE. */
export type AuthMode =
  | { type: 'none' }
  | { type: 'token'; token: string }
  | { type: 'basic'; username: string; password: string };

const authHeaders = (auth: AuthMode): Record<string, string> => {
  switch (auth.type) {
    case 'token':
      return { Cookie: `token=${auth.token}` };
    case 'basic':
      return { Authorization: `Basic ${Buffer.from(`${auth.username}:${auth.password}`).toString('base64')}` };
    default:
      return {};
  }
};

/** All /booking endpoints: GetBookingIds, GetBooking, CreateBooking, UpdateBooking, PartialUpdateBooking, DeleteBooking. */
export class BookingApi {
  constructor(private readonly client: ApiClient) {}

  getBookingIds(filters?: Record<string, string>): Promise<ApiResponse<BookingIdItem[]>> {
    return this.client.send('GET', '/booking', { params: filters });
  }

  getBooking(id: number | string): Promise<ApiResponse<Booking>> {
    return this.client.send('GET', `/booking/${id}`);
  }

  createBooking(booking: Booking): Promise<ApiResponse<CreateBookingResponse>> {
    return this.client.send('POST', '/booking', { data: booking });
  }

  /** Raw string body for negative tests (malformed / incomplete JSON). */
  createBookingRaw(rawBody: string): Promise<ApiResponse> {
    return this.client.send('POST', '/booking', { data: rawBody });
  }

  updateBooking(id: number | string, booking: Booking, auth: AuthMode): Promise<ApiResponse<Booking>> {
    return this.client.send('PUT', `/booking/${id}`, { data: booking, headers: authHeaders(auth) });
  }

  partialUpdateBooking(id: number | string, partial: PartialBooking, auth: AuthMode): Promise<ApiResponse<Booking>> {
    return this.client.send('PATCH', `/booking/${id}`, { data: partial, headers: authHeaders(auth) });
  }

  deleteBooking(id: number | string, auth: AuthMode): Promise<ApiResponse> {
    return this.client.send('DELETE', `/booking/${id}`, { headers: authHeaders(auth) });
  }
}
