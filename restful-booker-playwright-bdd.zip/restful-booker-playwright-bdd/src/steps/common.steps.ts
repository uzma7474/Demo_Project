import { Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { validateSchema } from '../utils/schemaValidator';
import { CustomWorld } from '../support/world';

Then('the response status code should be {int}', function (this: CustomWorld, expected: number) {
  expect(this.requireResponse().status, 'HTTP status code').toBe(expected);
});

Then('the response time should be under {int} ms', function (this: CustomWorld, maxMs: number) {
  expect(this.requireResponse().durationMs, 'Response time (ms)').toBeLessThan(maxMs);
});

Then('the response body should be {string}', function (this: CustomWorld, expected: string) {
  expect(this.requireResponse().text.trim()).toBe(expected);
});

Then('the response should match JSON schema {string}', function (this: CustomWorld, schemaFile: string) {
  const errors = validateSchema(schemaFile, this.requireResponse().json);
  expect(errors, `Schema violations against ${schemaFile}`).toEqual([]);
});
