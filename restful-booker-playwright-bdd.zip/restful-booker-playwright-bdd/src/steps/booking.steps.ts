import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { config } from '../config/env';
import { Booking, CreateBookingResponse } from '../models/booking';
import { getRow } from '../utils/excelUtils';
import { readJson } from '../utils/jsonUtils';
import { bookingFromRow, partialBooking, randomBooking } from '../utils/payloadBuilder';
import { CustomWorld } from '../support/world';

const NON_EXISTENT_TOKEN = 'invalid-token';

async function create(world: CustomWorld, booking: Booking): Promise<void> {
  world.requestBooking = booking;
  const res = await world.bookingApi.createBooking(booking);
  world.response = res;
  if (res.status === 200 && res.json) world.bookingId = res.json.bookingid;
}

// ------------------------------------------------------------------ Given
Given('a booking exists', async function (this: CustomWorld) {
  const payload = randomBooking();
  const res = await this.bookingApi.createBooking(payload);
  expect(res.status, 'precondition: create booking').toBe(200);
  this.requestBooking = payload;
  this.bookingId = res.json!.bookingid;
});

// ------------------------------------------------------------------ Create
When('I create a booking with random data', async function (this: CustomWorld) {
  await create(this, randomBooking());
});

When(
  'I create a booking from Excel row {string} of sheet {string}',
  async function (this: CustomWorld, testCaseId: string, sheet: string) {
    const row = await getRow(config.testDataExcel, sheet, testCaseId);
    await create(this, bookingFromRow(row));
  },
);

When('I create a booking from JSON test data {string}', async function (this: CustomWorld, key: string) {
  const data = readJson<Record<string, Booking>>(config.testDataJson);
  expect(Object.keys(data), 'JSON test data key').toContain(key);
  await create(this, data[key]);
});

When('I create a booking with the raw payload:', async function (this: CustomWorld, payload: string) {
  this.response = await this.bookingApi.createBookingRaw(payload);
});

// ------------------------------------------------------------------ Read
When('I get all booking ids', async function (this: CustomWorld) {
  this.response = await this.bookingApi.getBookingIds();
});

When('I get booking ids filtered by the {word} of the created booking', async function (this: CustomWorld, field: string) {
  const b = this.requireRequestBooking();
  const values: Record<string, string> = {
    firstname: b.firstname,
    lastname: b.lastname,
    checkin: b.bookingdates.checkin,
    checkout: b.bookingdates.checkout,
  };
  expect(Object.keys(values), 'supported filter').toContain(field);
  this.response = await this.bookingApi.getBookingIds({ [field]: values[field] });
});

When("I get booking ids filtered by the created booking's firstname and lastname", async function (this: CustomWorld) {
  const b = this.requireRequestBooking();
  this.response = await this.bookingApi.getBookingIds({ firstname: b.firstname, lastname: b.lastname });
});

When(
  'I get booking ids filtered by firstname {string} and lastname {string}',
  async function (this: CustomWorld, firstname: string, lastname: string) {
    this.response = await this.bookingApi.getBookingIds({ firstname, lastname });
  },
);

When('I get the booking by its id', async function (this: CustomWorld) {
  this.response = await this.bookingApi.getBooking(this.requireBookingId());
});

When('I get the booking with id {int}', async function (this: CustomWorld, id: number) {
  this.response = await this.bookingApi.getBooking(id);
});

// ------------------------------------------------------------------ Update (PUT)
When('I update the booking with new data using a valid token', async function (this: CustomWorld) {
  const updated = randomBooking();
  this.requestBooking = updated;
  this.response = await this.bookingApi.updateBooking(this.requireBookingId(), updated, await this.adminAuth());
});

When('I update the booking with new data using basic auth', async function (this: CustomWorld) {
  const updated = randomBooking();
  this.requestBooking = updated;
  this.response = await this.bookingApi.updateBooking(this.requireBookingId(), updated, {
    type: 'basic',
    username: config.username,
    password: config.password,
  });
});

When('I update the booking with new data without authentication', async function (this: CustomWorld) {
  this.response = await this.bookingApi.updateBooking(this.requireBookingId(), randomBooking(), { type: 'none' });
});

When('I update the booking with new data using an invalid token', async function (this: CustomWorld) {
  this.response = await this.bookingApi.updateBooking(this.requireBookingId(), randomBooking(), {
    type: 'token',
    token: NON_EXISTENT_TOKEN,
  });
});

When(
  'I update the non-existent booking {int} with new data using a valid token',
  async function (this: CustomWorld, id: number) {
    this.response = await this.bookingApi.updateBooking(id, randomBooking(), await this.adminAuth());
  },
);

// ------------------------------------------------------------------ Partial update (PATCH)
When(
  'I partially update the booking firstname to {string} and lastname to {string} using a valid token',
  async function (this: CustomWorld, firstname: string, lastname: string) {
    this.response = await this.bookingApi.partialUpdateBooking(
      this.requireBookingId(),
      partialBooking({ firstname, lastname }),
      await this.adminAuth(),
    );
  },
);

When(
  'I partially update the booking firstname to {string} without authentication',
  async function (this: CustomWorld, firstname: string) {
    this.response = await this.bookingApi.partialUpdateBooking(
      this.requireBookingId(),
      partialBooking({ firstname }),
      { type: 'none' },
    );
  },
);

// ------------------------------------------------------------------ Delete
When('I delete the booking using a valid token', async function (this: CustomWorld) {
  this.response = await this.bookingApi.deleteBooking(this.requireBookingId(), await this.adminAuth());
});

When('I delete the booking using basic auth', async function (this: CustomWorld) {
  this.response = await this.bookingApi.deleteBooking(this.requireBookingId(), {
    type: 'basic',
    username: config.username,
    password: config.password,
  });
});

When('I delete the booking without authentication', async function (this: CustomWorld) {
  this.response = await this.bookingApi.deleteBooking(this.requireBookingId(), { type: 'none' });
});

When('I delete the non-existent booking {int} using a valid token', async function (this: CustomWorld, id: number) {
  this.response = await this.bookingApi.deleteBooking(id, await this.adminAuth());
});

// ------------------------------------------------------------------ Assertions
Then('the created booking id should be returned', function (this: CustomWorld) {
  const body = this.requireResponse().json as CreateBookingResponse;
  expect(body.bookingid).toBeGreaterThan(0);
});

Then('the response booking should match the request data', function (this: CustomWorld) {
  const json = this.requireResponse().json as Booking | CreateBookingResponse;
  const actual = 'booking' in json ? json.booking : json;
  expect(actual).toEqual(this.requireRequestBooking());
});

Then('the booking ids list should contain the created booking id', function (this: CustomWorld) {
  const ids = (this.requireResponse().json as { bookingid: number }[]).map((i) => i.bookingid);
  expect(ids).toContain(this.requireBookingId());
});

Then('the booking ids list should be empty', function (this: CustomWorld) {
  expect(this.requireResponse().json as unknown[]).toHaveLength(0);
});

Then('the booking ids list should be a non-empty list', function (this: CustomWorld) {
  expect((this.requireResponse().json as unknown[]).length).toBeGreaterThan(0);
});

Then(
  'the booking firstname should be {string} and lastname should be {string}',
  function (this: CustomWorld, firstname: string, lastname: string) {
    const b = this.requireResponse().json as Booking;
    expect(b.firstname).toBe(firstname);
    expect(b.lastname).toBe(lastname);
  },
);

Then('the other booking fields should be unchanged', function (this: CustomWorld) {
  const { firstname: _f, lastname: _l, ...original } = this.requireRequestBooking();
  const { firstname: _f2, lastname: _l2, ...actual } = this.requireResponse().json as Booking;
  expect(actual).toEqual(original);
});

Then('the booking should no longer exist', async function (this: CustomWorld) {
  const res = await this.bookingApi.getBooking(this.requireBookingId());
  expect(res.status).toBe(404);
  this.bookingId = undefined; // already removed - skip cleanup
});
