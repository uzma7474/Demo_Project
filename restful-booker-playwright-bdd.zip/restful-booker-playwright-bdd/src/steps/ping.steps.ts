import { When } from '@cucumber/cucumber';
import { CustomWorld } from '../support/world';

When('I call the health check endpoint', async function (this: CustomWorld) {
  this.response = await this.pingApi.healthCheck();
});
