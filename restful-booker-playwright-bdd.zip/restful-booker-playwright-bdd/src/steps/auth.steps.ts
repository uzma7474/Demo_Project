import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { config } from '../config/env';
import { CustomWorld } from '../support/world';

type AuthBody = { token?: string; reason?: string };

When('I request an auth token with valid admin credentials', async function (this: CustomWorld) {
  this.response = await this.authApi.createToken(config.username, config.password);
});

When(
  'I request an auth token with username {string} and password {string}',
  async function (this: CustomWorld, username: string, password: string) {
    this.response = await this.authApi.createToken(username, password);
  },
);

Then('the response should contain a non-empty token', function (this: CustomWorld) {
  const body = this.requireResponse().json as AuthBody | undefined;
  expect(body?.token, 'token').toBeTruthy();
});

Then('the response should contain the reason {string}', function (this: CustomWorld, reason: string) {
  const body = this.requireResponse().json as AuthBody | undefined;
  expect(body?.reason).toBe(reason);
});

Then('the response should not contain a token', function (this: CustomWorld) {
  const body = this.requireResponse().json as AuthBody | undefined;
  expect(body?.token).toBeUndefined();
});
