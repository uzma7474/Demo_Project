import * as dotenv from 'dotenv';
import * as path from 'path';

// Load .env first, then .env.<ENV> (e.g. .env.qa) - real process env always wins.
dotenv.config();
if (process.env.ENV) {
  dotenv.config({ path: path.resolve(process.cwd(), `.env.${process.env.ENV}`) });
}

const required = (key: string, fallback?: string): string => {
  const value = process.env[key] ?? fallback;
  if (value === undefined || value === '') {
    throw new Error(`Missing required config value: ${key}`);
  }
  return value;
};

export const config = {
  env: process.env.ENV ?? 'qa',
  baseUrl: required('BASE_URL', 'https://restful-booker.herokuapp.com'),
  username: required('AUTH_USERNAME', 'admin'),
  password: required('AUTH_PASSWORD', 'password123'),
  timeoutMs: Number(required('REQUEST_TIMEOUT_MS', '30000')),
  logLevel: required('LOG_LEVEL', 'debug'),
  logHttp: (process.env.LOG_HTTP ?? 'true') === 'true',
  testDataExcel: required('TESTDATA_EXCEL', 'test-data/bookings.xlsx'),
  testDataJson: required('TESTDATA_JSON', 'test-data/bookings.json'),
} as const;
