export interface BookingDates {
  checkin: string;
  checkout: string;
}

export interface Booking {
  firstname: string;
  lastname: string;
  totalprice: number;
  depositpaid: boolean;
  bookingdates: BookingDates;
  additionalneeds?: string;
}

/** Body used by PATCH - any subset of Booking. */
export type PartialBooking = Partial<Booking>;

export interface CreateBookingResponse {
  bookingid: number;
  booking: Booking;
}

export interface BookingIdItem {
  bookingid: number;
}

export interface AuthRequest {
  username: string;
  password: string;
}
