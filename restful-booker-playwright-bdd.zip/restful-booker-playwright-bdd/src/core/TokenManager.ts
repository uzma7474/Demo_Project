import { AuthApi } from '../api/AuthApi';

/**
 * Fetches the admin token once per worker process and caches the promise, so concurrent
 * scenarios in the same process share a single /auth call.
 */
let cached: Promise<string> | undefined;

export function getAdminToken(authApi: AuthApi, username: string, password: string): Promise<string> {
  if (!cached) {
    cached = authApi.createToken(username, password).then((res) => {
      if (res.status !== 200 || !res.json?.token) {
        cached = undefined; // do not cache a failure
        throw new Error(`Unable to obtain admin token (status ${res.status}): ${res.text}`);
      }
      return res.json.token;
    });
  }
  return cached;
}
