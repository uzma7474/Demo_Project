import { APIRequestContext } from '@playwright/test';
import { config } from '../config/env';
import { Logger } from '../utils/logger';

export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export interface ApiResponse<T = unknown> {
  status: number;
  statusText: string;
  headers: Record<string, string>;
  /** Raw response text (the API returns plain text for some calls, e.g. "Created"). */
  text: string;
  /** Parsed JSON, or undefined when the body is not JSON. */
  json?: T;
  durationMs: number;
}

export interface SendOptions {
  /** Object (serialised to JSON) or raw string (sent as-is, for malformed-payload tests). */
  data?: unknown;
  headers?: Record<string, string>;
  params?: Record<string, string | number | boolean>;
}

type TranscriptSink = (transcript: string) => void;

const SECRET = /(token=)[^;\s]+|("token"\s*:\s*")[^"]+|("password"\s*:\s*")[^"]+|("Authorization"\s*:\s*")[^"]+/gi;
const mask = (s: string): string =>
  s.replace(SECRET, (_m, a, b, c, d) => `${a ?? b ?? c ?? d}****`);

/**
 * Thin wrapper over Playwright's APIRequestContext. Every call is timed, logged (secrets masked)
 * and forwarded to a sink so the HTTP transcript can be attached to the Cucumber report.
 */
export class ApiClient {
  constructor(
    private readonly ctx: APIRequestContext,
    private readonly log: Logger,
    private readonly sink?: TranscriptSink,
  ) {}

  async send<T = unknown>(method: HttpMethod, url: string, opts: SendOptions = {}): Promise<ApiResponse<T>> {
    const started = Date.now();
    const res = await this.ctx.fetch(url, {
      method,
      data: opts.data as never,
      headers: opts.headers,
      params: opts.params,
      failOnStatusCode: false, // negative tests assert on 4xx/5xx themselves
    });
    const durationMs = Date.now() - started;
    const text = await res.text();
    let json: T | undefined;
    try {
      json = text ? (JSON.parse(text) as T) : undefined;
    } catch {
      json = undefined; // plain-text body
    }

    const response: ApiResponse<T> = {
      status: res.status(),
      statusText: res.statusText(),
      headers: res.headers(),
      text,
      json,
      durationMs,
    };
    this.record(method, url, opts, response);
    return response;
  }

  private record(method: HttpMethod, url: string, opts: SendOptions, res: ApiResponse): void {
    const lines: string[] = [`${method} ${config.baseUrl}${url}`];
    if (opts.params) lines.push(`  Query: ${JSON.stringify(opts.params)}`);
    if (opts.headers) lines.push(`  Headers: ${mask(JSON.stringify(opts.headers))}`);
    if (opts.data !== undefined) {
      const body = typeof opts.data === 'string' ? opts.data : JSON.stringify(opts.data);
      lines.push(`  Request body: ${mask(body)}`);
    }
    lines.push(`  <- ${res.status} ${res.statusText} (${res.durationMs} ms)`);
    if (res.text) lines.push(`  Response body: ${mask(res.text)}`);

    const transcript = lines.join('\n');
    if (config.logHttp) this.log.info(`API call\n${transcript}`);
    this.sink?.(transcript);
  }
}
