import { After, AfterAll, Before, BeforeAll, Status } from '@cucumber/cucumber';
import * as fs from 'fs';
import { config } from '../config/env';
import { logger } from '../utils/logger';
import { CustomWorld } from './world';

BeforeAll(async function () {
  fs.mkdirSync('reports/json', { recursive: true });
  fs.mkdirSync('logs', { recursive: true });
  logger.info(`Suite starting | env=${config.env} | baseUrl=${config.baseUrl}`);
});

Before(async function (this: CustomWorld, { pickle }) {
  await this.init(pickle.name);
  this.scenarioLog.info(`=== START: ${pickle.name} [${pickle.tags.map((t) => t.name).join(' ')}] ===`);
});

After(async function (this: CustomWorld, { pickle, result }) {
  // Keep the shared sandbox tidy: delete any booking this scenario created (and did not delete itself).
  if (this.bookingId !== undefined) {
    try {
      const res = await this.bookingApi.deleteBooking(this.bookingId, await this.adminAuth());
      this.scenarioLog.info(`Cleanup of booking ${this.bookingId} -> ${res.status}`);
    } catch (e) {
      this.scenarioLog.warn(`Cleanup failed for booking ${this.bookingId}: ${(e as Error).message}`);
    }
  }
  const status = result?.status ?? Status.UNKNOWN;
  this.scenarioLog.info(`=== END: ${pickle.name} -> ${status} ===`);
  await this.dispose();
});

AfterAll(async function () {
  logger.info('Suite finished');
});
