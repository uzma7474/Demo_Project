import { IWorldOptions, World, setWorldConstructor } from '@cucumber/cucumber';
import { APIRequestContext, request } from '@playwright/test';
import { AuthApi } from '../api/AuthApi';
import { AuthMode, BookingApi } from '../api/BookingApi';
import { PingApi } from '../api/PingApi';
import { config } from '../config/env';
import { ApiClient, ApiResponse } from '../core/ApiClient';
import { getAdminToken } from '../core/TokenManager';
import { Booking } from '../models/booking';
import { Logger, scenarioLogger } from '../utils/logger';

/**
 * Scenario-scoped state. Cucumber creates one World per scenario, so state is isolated
 * even when running with --parallel.
 */
export class CustomWorld extends World {
  private context!: APIRequestContext;
  scenarioLog!: Logger;
  authApi!: AuthApi;
  bookingApi!: BookingApi;
  pingApi!: PingApi;

  response?: ApiResponse;
  requestBooking?: Booking;
  bookingId?: number;

  constructor(options: IWorldOptions) {
    super(options);
  }

  async init(scenarioName: string): Promise<void> {
    this.scenarioLog = scenarioLogger(scenarioName);
    this.context = await request.newContext({
      baseURL: config.baseUrl,
      timeout: config.timeoutMs,
      extraHTTPHeaders: { Accept: 'application/json', 'Content-Type': 'application/json' },
    });
    // Every HTTP transcript is attached to the Cucumber report as it happens.
    const client = new ApiClient(this.context, this.scenarioLog, (t) => this.attach(t, 'text/plain'));
    this.authApi = new AuthApi(client);
    this.bookingApi = new BookingApi(client);
    this.pingApi = new PingApi(client);
  }

  async dispose(): Promise<void> {
    await this.context?.dispose();
  }

  async adminAuth(): Promise<AuthMode> {
    const token = await getAdminToken(this.authApi, config.username, config.password);
    return { type: 'token', token };
  }

  requireResponse(): ApiResponse {
    if (!this.response) throw new Error('No response captured - did a "When" step run?');
    return this.response;
  }

  requireBookingId(): number {
    if (this.bookingId === undefined) throw new Error('No booking id in scenario context');
    return this.bookingId;
  }

  requireRequestBooking(): Booking {
    if (!this.requestBooking) throw new Error('No request booking in scenario context');
    return this.requestBooking;
  }
}

setWorldConstructor(CustomWorld);
