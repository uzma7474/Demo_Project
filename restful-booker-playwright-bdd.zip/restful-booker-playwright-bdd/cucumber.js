// Cucumber-js profile. Override from CLI/env: TAGS="@smoke" PARALLEL=4 RETRY=1 npm test
require('dotenv').config();

const common = {
  requireModule: ['ts-node/register'],
  require: ['src/support/**/*.ts', 'src/steps/**/*.ts'],
  paths: ['features/**/*.feature'],
  format: [
    'progress-bar',
    'summary',
    'html:reports/cucumber-report.html',
    'json:reports/json/cucumber-report.json',
  ],
  formatOptions: { snippetInterface: 'async-await' },
  parallel: Number(process.env.PARALLEL || 1),
  retry: Number(process.env.RETRY || 0),
  tags: process.env.TAGS || undefined,
};

module.exports = { default: common };
