import * as report from 'multiple-cucumber-html-reporter';
import * as os from 'os';
import { config } from '../src/config/env';

report.generate({
  jsonDir: 'reports/json',
  reportPath: 'reports/html',
  reportName: 'Restful Booker API - Test Report',
  pageTitle: 'Restful Booker API Automation',
  displayDuration: true,
  metadata: {
    browser: { name: 'chrome', version: 'n/a (API tests)' },
    device: os.hostname(),
    platform: { name: os.platform(), version: os.release() },
  },
  customData: {
    title: 'Run info',
    data: [
      { label: 'Project', value: 'Restful Booker API' },
      { label: 'Environment', value: config.env },
      { label: 'Base URL', value: config.baseUrl },
      { label: 'Stack', value: 'Playwright + Cucumber + TypeScript' },
      { label: 'Executed', value: new Date().toISOString() },
    ],
  },
});
console.log('HTML report generated: reports/html/index.html');
