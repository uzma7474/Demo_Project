import { IWorldOptions, setWorldConstructor, World } from '@cucumber/cucumber';
import { TestContext } from '../../core/TestContext';

/**
 * cucumber-js World: one instance per scenario. The Before hook creates `ctx`
 * (request context + services + scenario state); steps reach it via `this.ctx`.
 */
export class CustomWorld extends World {
  ctx!: TestContext;

  constructor(options: IWorldOptions) {
    super(options);
  }
}

setWorldConstructor(CustomWorld);
