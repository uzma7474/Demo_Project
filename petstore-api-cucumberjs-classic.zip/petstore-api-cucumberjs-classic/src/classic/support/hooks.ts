import { After, Before, ITestCaseHookParameter, Status, setDefaultTimeout } from '@cucumber/cucumber';
import { request } from '@playwright/test';
import { Logger } from '../../core/Logger';
import { TestContext } from '../../core/TestContext';
import { CustomWorld } from './CustomWorld';

setDefaultTimeout(60_000);

Before(async function (this: CustomWorld, scenario: ITestCaseHookParameter) {
  Logger.get().info(`>>> ${scenario.pickle.name}`);
  this.ctx = await TestContext.create(request);
});

After(async function (this: CustomWorld, scenario: ITestCaseHookParameter) {
  const history = this.ctx.client.history;
  const failed = scenario.result?.status === Status.FAILED;

  // Always attach the last exchange; attach the whole conversation when the scenario failed.
  const toAttach = failed ? history : history.slice(-1);
  toAttach.forEach((exchange) => this.attach(exchange.toAttachment(), 'application/json'));

  Logger.get().info(`<<< ${scenario.pickle.name} [${scenario.result?.status ?? 'UNKNOWN'}]`);
  await this.ctx.dispose();
});
