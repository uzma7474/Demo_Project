// Classic cucumber-js configuration (CommonJS). Run with `npx cucumber-js` or the npm scripts.
const common = {
  paths: ['features/**/*.feature'],
  requireModule: ['ts-node/register'],
  require: ['src/classic/support/**/*.ts', 'src/classic/steps/**/*.ts'],
  format: [
    'progress-bar',
    'html:reports/cucumber-report.html',
    'json:reports/cucumber-report.json',
  ],
  formatOptions: { snippetInterface: 'async-await' },
};

module.exports = {
  default: common,
  smoke: { ...common, tags: '@smoke' },
  regression: { ...common, tags: '@regression' },
  e2e: { ...common, tags: '@e2e' },
  negative: { ...common, tags: '@negative' },
  json: { ...common, tags: '@json' },
  excel: { ...common, tags: '@excel' },
  parallel: { ...common, parallel: 4 },
};
