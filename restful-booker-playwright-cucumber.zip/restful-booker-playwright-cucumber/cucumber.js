// Cucumber-js (classic) configuration. Profiles are selected with `--profile <name>`.
const retry = Number(process.env.RETRY || 0);
const parallel = Number(process.env.PARALLEL || 0);

const common = {
  requireModule: ['ts-node/register'],
  require: ['src/support/**/*.ts', 'src/steps/**/*.ts'],
  paths: ['features/**/*.feature'],
  format: [
    process.env.CI ? 'progress' : 'progress-bar',
    'json:reports/cucumber-json/cucumber-report.json',
    'html:reports/cucumber-report.html',
    'rerun:reports/@rerun.txt'
  ],
  formatOptions: { snippetInterface: 'async-await' },
  publishQuiet: true,
  retry,
  parallel
};

module.exports = {
  default: common,
  smoke: { ...common, tags: '@smoke' },
  regression: { ...common, tags: '@regression and not @known-behavior' },
  negative: { ...common, tags: '@negative' }
};
