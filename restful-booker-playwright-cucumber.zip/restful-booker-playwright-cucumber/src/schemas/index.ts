const bookingSchema = {
  type: 'object',
  required: ['firstname', 'lastname', 'totalprice', 'depositpaid', 'bookingdates'],
  properties: {
    firstname: { type: 'string' },
    lastname: { type: 'string' },
    totalprice: { type: 'number' },
    depositpaid: { type: 'boolean' },
    bookingdates: {
      type: 'object',
      required: ['checkin', 'checkout'],
      properties: {
        checkin: { type: 'string', format: 'date' },
        checkout: { type: 'string', format: 'date' }
      }
    },
    additionalneeds: { type: 'string' }
  }
};

export const schemas = {
  booking: bookingSchema,
  createBookingResponse: {
    type: 'object',
    required: ['bookingid', 'booking'],
    properties: { bookingid: { type: 'integer' }, booking: bookingSchema }
  },
  bookingIds: {
    type: 'array',
    items: {
      type: 'object',
      required: ['bookingid'],
      properties: { bookingid: { type: 'integer' } }
    }
  },
  token: {
    type: 'object',
    required: ['token'],
    properties: { token: { type: 'string', minLength: 1 } }
  }
} as const;

export type SchemaName = keyof typeof schemas;
