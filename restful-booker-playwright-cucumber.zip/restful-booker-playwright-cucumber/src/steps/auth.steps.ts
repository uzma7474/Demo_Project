import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { env } from '../config/env';
import { CustomWorld } from '../support/world';

Given('I have a valid auth token', async function (this: CustomWorld) {
  this.token = await this.auth.getValidToken();
});

When('I request an auth token with valid credentials', async function (this: CustomWorld) {
  this.response = await this.auth.createToken({ username: env.username, password: env.password });
});

When(
  'I request an auth token with username {string} and password {string}',
  async function (this: CustomWorld, username: string, password: string) {
    this.response = await this.auth.createToken({ username, password });
  }
);

Then('the response should contain a token', function (this: CustomWorld) {
  expect(this.lastResponse.body.token).toBeTruthy();
});

Then('the response should contain the reason {string}', function (this: CustomWorld, reason: string) {
  expect(this.lastResponse.body.reason).toBe(reason);
});
