import { Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { env } from '../config/env';
import { SchemaName, schemas } from '../schemas';
import { validateSchema } from '../utils/schemaValidator';
import { CustomWorld } from '../support/world';

Then('the response status code should be {int}', function (this: CustomWorld, expected: number) {
  expect(this.lastResponse.status, `Unexpected status. Body: ${this.lastResponse.text}`).toBe(expected);
});

Then('the response body should be {string}', function (this: CustomWorld, expected: string) {
  expect(this.lastResponse.text.trim()).toBe(expected);
});

Then('the response time should be within the configured limit', function (this: CustomWorld) {
  expect(this.lastResponse.durationMs).toBeLessThan(env.maxResponseTimeMs);
});

Then('the response body should match the {string} schema', function (this: CustomWorld, name: string) {
  if (!(name in schemas)) throw new Error(`Unknown schema "${name}". Available: ${Object.keys(schemas).join(', ')}`);
  const { valid, errors } = validateSchema(name as SchemaName, this.lastResponse.body);
  expect(valid, `Schema "${name}" validation failed: ${errors}`).toBe(true);
});
