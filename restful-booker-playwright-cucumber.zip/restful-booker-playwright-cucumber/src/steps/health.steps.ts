import { When } from '@cucumber/cucumber';
import { CustomWorld } from '../support/world';

When('I send a health check request', async function (this: CustomWorld) {
  this.response = await this.health.ping();
});
