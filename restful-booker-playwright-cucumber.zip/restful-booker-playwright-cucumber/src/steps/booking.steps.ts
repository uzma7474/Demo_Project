import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { Booking, BookingIdItem } from '../models/booking';
import { CustomWorld } from '../support/world';
import { buildBooking } from '../utils/dataFactory';
import { JsonUtil } from '../utils/jsonUtil';

// ---------------------------------------------------------------- Given
Given('I have a new booking payload', function (this: CustomWorld) {
  this.bookingPayload = buildBooking();
});

Given(
  'I have a booking payload with firstname {string} and lastname {string}',
  function (this: CustomWorld, firstname: string, lastname: string) {
    this.bookingPayload = buildBooking({ firstname, lastname });
  }
);

Given('a booking exists', async function (this: CustomWorld) {
  const payload = buildBooking();
  const res = await this.bookings.createBooking(payload);
  expect(res.status, `Could not create precondition booking: ${res.text}`).toBe(200);
  this.bookingPayload = payload;
  this.bookingId = res.body.bookingid;
  this.createdBookingIds.push(res.body.bookingid);
});

// ---------------------------------------------------------------- When: read
When('I request all booking ids', async function (this: CustomWorld) {
  this.response = await this.bookings.getBookingIds();
});

When(
  'I request booking ids filtered by firstname {string} and lastname {string}',
  async function (this: CustomWorld, firstname: string, lastname: string) {
    this.response = await this.bookings.getBookingIds({ firstname, lastname });
  }
);

When(
  'I request booking ids filtered by checkin {string} and checkout {string}',
  async function (this: CustomWorld, checkin: string, checkout: string) {
    this.response = await this.bookings.getBookingIds({ checkin, checkout });
  }
);

When("I filter booking ids by the booking's firstname and lastname", async function (this: CustomWorld) {
  const { firstname, lastname } = this.requirePayload();
  this.response = await this.bookings.getBookingIds({ firstname, lastname });
});

When("I filter booking ids by the booking's checkin and checkout dates", async function (this: CustomWorld) {
  const { checkin, checkout } = this.requirePayload().bookingdates;
  this.response = await this.bookings.getBookingIds({ checkin, checkout });
});

When('I request the booking details', async function (this: CustomWorld) {
  this.response = await this.bookings.getBooking(this.requireBookingId());
});

When('I request the booking with id {int}', async function (this: CustomWorld, id: number) {
  this.response = await this.bookings.getBooking(id);
});

// ---------------------------------------------------------------- When: write
When('I create the booking', async function (this: CustomWorld) {
  this.response = await this.bookings.createBooking(this.requirePayload());
  const id = this.response.body?.bookingid;
  if (this.response.status === 200 && typeof id === 'number') {
    this.bookingId = id;
    this.createdBookingIds.push(id);
  }
});

When('I create bookings from the test data file {string}', async function (this: CustomWorld, fileName: string) {
  const records = JsonUtil.readTestData<Booking[]>(fileName);
  for (const record of records) {
    const res = await this.bookings.createBooking(record);
    expect(res.status, `Create failed for ${record.firstname}: ${res.text}`).toBe(200);
    expect(res.body.booking).toMatchObject(record);
    this.createdBookingIds.push(res.body.bookingid);
    this.response = res;
  }
});

When(
  'I update the booking with new details using {string} authentication',
  async function (this: CustomWorld, authType: string) {
    const updated = buildBooking();
    this.bookingPayload = updated;
    this.response = await this.bookings.updateBooking(this.requireBookingId(), updated, this.authHeaders(authType));
  }
);

When(
  'I partially update the booking firstname to {string} and lastname to {string} using {string} authentication',
  async function (this: CustomWorld, firstname: string, lastname: string, authType: string) {
    this.bookingPayload = { ...this.requirePayload(), firstname, lastname };
    this.response = await this.bookings.partialUpdateBooking(
      this.requireBookingId(),
      { firstname, lastname },
      this.authHeaders(authType)
    );
  }
);

When('I delete the booking using {string} authentication', async function (this: CustomWorld, authType: string) {
  const id = this.requireBookingId();
  this.response = await this.bookings.deleteBooking(id, this.authHeaders(authType));
  if (this.response.status === 201) {
    this.createdBookingIds = this.createdBookingIds.filter((x) => x !== id);
  }
});

When(
  'I delete the booking with id {int} using {string} authentication',
  async function (this: CustomWorld, id: number, authType: string) {
    this.response = await this.bookings.deleteBooking(id, this.authHeaders(authType));
  }
);

// ---------------------------------------------------------------- Then
Then('the response should contain a booking id', function (this: CustomWorld) {
  expect(this.lastResponse.body.bookingid).toBeGreaterThan(0);
});

Then('the created booking should match the payload', function (this: CustomWorld) {
  expect(this.lastResponse.body.booking).toMatchObject(this.requirePayload());
});

Then('the booking details should match the payload', function (this: CustomWorld) {
  expect(this.lastResponse.body).toMatchObject(this.requirePayload());
});

Then('the response should contain at least {int} booking id(s)', function (this: CustomWorld, min: number) {
  expect((this.lastResponse.body as BookingIdItem[]).length).toBeGreaterThanOrEqual(min);
});

Then('the booking id list should contain the booking id', function (this: CustomWorld) {
  const ids = (this.lastResponse.body as BookingIdItem[]).map((b) => b.bookingid);
  expect(ids).toContain(this.requireBookingId());
});

Then('the booking id list should be empty', function (this: CustomWorld) {
  expect(this.lastResponse.body as BookingIdItem[]).toHaveLength(0);
});

Then('the booking should no longer exist', async function (this: CustomWorld) {
  const res = await this.bookings.getBooking(this.requireBookingId());
  expect(res.status).toBe(404);
});

Then('the booking should still exist', async function (this: CustomWorld) {
  const res = await this.bookings.getBooking(this.requireBookingId());
  expect(res.status).toBe(200);
});
