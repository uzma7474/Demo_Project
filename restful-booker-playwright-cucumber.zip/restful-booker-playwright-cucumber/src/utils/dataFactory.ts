import { faker } from '@faker-js/faker';
import { Booking } from '../models/booking';

const isoDate = (d: Date): string => d.toISOString().slice(0, 10);

/** Builds a random, valid booking payload. Pass overrides to pin specific fields. */
export function buildBooking(overrides: Partial<Booking> = {}): Booking {
  const checkin = faker.date.soon({ days: 30 });
  const checkout = faker.date.soon({ days: 10, refDate: checkin });
  return {
    firstname: faker.person.firstName(),
    lastname: faker.person.lastName(),
    totalprice: faker.number.int({ min: 100, max: 1000 }),
    depositpaid: faker.datatype.boolean(),
    bookingdates: { checkin: isoDate(checkin), checkout: isoDate(checkout) },
    additionalneeds: faker.helpers.arrayElement(['Breakfast', 'Lunch', 'Dinner', 'Late checkout']),
    ...overrides
  };
}
