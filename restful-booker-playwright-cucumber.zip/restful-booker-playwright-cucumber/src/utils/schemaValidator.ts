import Ajv from 'ajv';
import addFormats from 'ajv-formats';
import { schemas, SchemaName } from '../schemas';

const ajv = new Ajv({ allErrors: true, strict: false });
addFormats(ajv);

export function validateSchema(name: SchemaName, data: unknown): { valid: boolean; errors: string } {
  const validate = ajv.compile(schemas[name]);
  const valid = validate(data) as boolean;
  const errors = (validate.errors ?? []).map((e) => `${e.instancePath || '/'} ${e.message}`).join('; ');
  return { valid, errors };
}
