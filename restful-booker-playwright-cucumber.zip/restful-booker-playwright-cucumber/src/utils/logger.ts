import winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import { env } from '../config/env';

const { combine, timestamp, printf, colorize, errors } = winston.format;

const line = printf(({ level, message, timestamp: ts, label, stack }) => {
  return `${ts} [${level}] [${label ?? 'framework'}] ${stack ?? message}`;
});

const baseFormat = combine(errors({ stack: true }), timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }));

const rootLogger = winston.createLogger({
  level: 'debug', // transports below decide what is actually written
  format: baseFormat,
  transports: [
    new winston.transports.Console({ level: env.consoleLogLevel, format: combine(colorize(), line) }),
    new DailyRotateFile({
      level: env.logLevel,
      dirname: env.paths.logs,
      filename: 'automation-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxFiles: '14d',
      format: line
    }),
    new DailyRotateFile({
      level: 'error',
      dirname: env.paths.logs,
      filename: 'error-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxFiles: '14d',
      format: line
    })
  ]
});

export const getLogger = (label: string): winston.Logger => rootLogger.child({ label });
