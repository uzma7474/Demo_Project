import ExcelJS from 'exceljs';
import path from 'path';
import { env } from '../config/env';

export class ExcelUtil {
  /**
   * Reads a worksheet into an array of objects. The first row is used as the header.
   * Use it for data-driven tests: ExcelUtil.readSheet('bookings.xlsx', 'Sheet1')
   */
  static async readSheet(fileName: string, sheetName?: string): Promise<Record<string, string>[]> {
    const file = path.isAbsolute(fileName) ? fileName : path.join(env.paths.testData, fileName);
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(file);
    const sheet = sheetName ? workbook.getWorksheet(sheetName) : workbook.worksheets[0];
    if (!sheet) {
      throw new Error(`Worksheet "${sheetName ?? '(first)'}" not found in ${file}`);
    }
    const headers = (sheet.getRow(1).values as ExcelJS.CellValue[]).slice(1).map((h) => String(h));
    const rows: Record<string, string>[] = [];
    sheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      if (rowNumber === 1) return;
      const record: Record<string, string> = {};
      headers.forEach((header, index) => {
        record[header] = row.getCell(index + 1).text;
      });
      rows.push(record);
    });
    return rows;
  }
}
