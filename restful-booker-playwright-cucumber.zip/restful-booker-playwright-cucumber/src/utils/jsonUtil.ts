import fs from 'fs';
import path from 'path';
import { env } from '../config/env';

export class JsonUtil {
  private static resolve(file: string): string {
    return path.isAbsolute(file) ? file : path.resolve(process.cwd(), file);
  }

  static read<T>(file: string): T {
    return JSON.parse(fs.readFileSync(JsonUtil.resolve(file), 'utf-8')) as T;
  }

  /** Reads a JSON file from the /test-data folder. */
  static readTestData<T>(fileName: string): T {
    return JsonUtil.read<T>(path.join(env.paths.testData, fileName));
  }

  static write(file: string, data: unknown): void {
    const target = JsonUtil.resolve(file);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, JSON.stringify(data, null, 2), 'utf-8');
  }
}
