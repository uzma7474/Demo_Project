import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

// Select environment with TEST_ENV (default: qa) -> env/.env.<name>; plain .env is a fallback.
const envName = process.env.TEST_ENV ?? 'qa';
const envFile = path.resolve(process.cwd(), 'env', `.env.${envName}`);
if (fs.existsSync(envFile)) {
  dotenv.config({ path: envFile });
}
dotenv.config();

const toNumber = (value: string | undefined, fallback: number): number => {
  const parsed = Number(value);
  return value !== undefined && value !== '' && !Number.isNaN(parsed) ? parsed : fallback;
};

const root = process.cwd();

export const env = {
  name: envName,
  baseUrl: (process.env.BASE_URL ?? 'https://restful-booker.herokuapp.com').replace(/\/+$/, ''),
  // NOTE: API_USERNAME (not USERNAME) because USERNAME is an OS variable on Windows.
  username: process.env.API_USERNAME ?? 'admin',
  password: process.env.API_PASSWORD ?? 'password123',
  timeoutMs: toNumber(process.env.TIMEOUT_MS, 30000),
  maxResponseTimeMs: toNumber(process.env.MAX_RESPONSE_TIME_MS, 5000),
  networkRetries: toNumber(process.env.NETWORK_RETRIES, 2),
  logLevel: process.env.LOG_LEVEL ?? 'debug',
  consoleLogLevel: process.env.CONSOLE_LOG_LEVEL ?? 'warn',
  paths: {
    root,
    logs: path.join(root, 'logs'),
    reports: path.join(root, 'reports'),
    cucumberJson: path.join(root, 'reports', 'cucumber-json'),
    scenarioRecords: path.join(root, 'reports', 'scenario-records'),
    html: path.join(root, 'reports', 'html'),
    testData: path.join(root, 'test-data')
  }
};
