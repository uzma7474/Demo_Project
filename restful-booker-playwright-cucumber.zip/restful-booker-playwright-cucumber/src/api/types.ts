export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export interface RequestOptions {
  data?: unknown;
  headers?: Record<string, string>;
  params?: Record<string, string | number | boolean>;
}

export interface ApiCallRecord {
  timestamp: string;
  method: HttpMethod;
  url: string;
  requestHeaders: Record<string, string>;
  requestBody?: unknown;
  status: number;
  statusText: string;
  responseHeaders: Record<string, string>;
  responseBody: unknown;
  durationMs: number;
}

export interface ApiResult<T = any> {
  status: number;
  statusText: string;
  ok: boolean;
  headers: Record<string, string>;
  /** Parsed JSON when possible, otherwise the raw text. */
  body: T;
  text: string;
  durationMs: number;
  url: string;
}
