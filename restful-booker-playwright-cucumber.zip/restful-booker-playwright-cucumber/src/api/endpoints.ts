export const Endpoints = {
  auth: '/auth',
  booking: '/booking',
  bookingById: (id: number | string): string => `/booking/${id}`,
  ping: '/ping'
} as const;
