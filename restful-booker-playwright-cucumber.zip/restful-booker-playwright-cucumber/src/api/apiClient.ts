import { APIRequestContext, APIResponse, request } from '@playwright/test';
import { env } from '../config/env';
import { getLogger } from '../utils/logger';
import { ApiCallRecord, ApiResult, HttpMethod, RequestOptions } from './types';

const log = getLogger('ApiClient');

const SENSITIVE_HEADERS = ['cookie', 'authorization', 'set-cookie'];
const SENSITIVE_FIELDS = ['token', 'password'];

const maskHeaders = (headers: Record<string, string>): Record<string, string> =>
  Object.fromEntries(
    Object.entries(headers).map(([k, v]) => [k, SENSITIVE_HEADERS.includes(k.toLowerCase()) ? '***' : v])
  );

const maskBody = (body: unknown): unknown => {
  if (body && typeof body === 'object' && !Array.isArray(body)) {
    return Object.fromEntries(
      Object.entries(body as Record<string, unknown>).map(([k, v]) => [
        k,
        SENSITIVE_FIELDS.includes(k.toLowerCase()) ? '***' : v
      ])
    );
  }
  return body;
};

const sleep = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Thin wrapper around Playwright's APIRequestContext.
 * Adds logging (with secrets masked), timing, retry on network errors and a per-scenario call history.
 */
export class ApiClient {
  private context?: APIRequestContext;
  readonly history: ApiCallRecord[] = [];
  private readonly defaultHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'application/json'
  };

  async init(): Promise<void> {
    this.context = await request.newContext({
      baseURL: env.baseUrl,
      timeout: env.timeoutMs,
      extraHTTPHeaders: this.defaultHeaders,
      ignoreHTTPSErrors: true
    });
  }

  async dispose(): Promise<void> {
    await this.context?.dispose();
    this.context = undefined;
  }

  get<T = any>(endpoint: string, options?: RequestOptions): Promise<ApiResult<T>> {
    return this.send<T>('GET', endpoint, options);
  }
  post<T = any>(endpoint: string, options?: RequestOptions): Promise<ApiResult<T>> {
    return this.send<T>('POST', endpoint, options);
  }
  put<T = any>(endpoint: string, options?: RequestOptions): Promise<ApiResult<T>> {
    return this.send<T>('PUT', endpoint, options);
  }
  patch<T = any>(endpoint: string, options?: RequestOptions): Promise<ApiResult<T>> {
    return this.send<T>('PATCH', endpoint, options);
  }
  delete<T = any>(endpoint: string, options?: RequestOptions): Promise<ApiResult<T>> {
    return this.send<T>('DELETE', endpoint, options);
  }

  async send<T = any>(method: HttpMethod, endpoint: string, options: RequestOptions = {}): Promise<ApiResult<T>> {
    if (!this.context) {
      throw new Error('ApiClient is not initialised. Call init() first (done in the Before hook).');
    }
    const requestHeaders = { ...this.defaultHeaders, ...(options.headers ?? {}) };
    const timestamp = new Date().toISOString();
    log.info(`--> ${method} ${endpoint}`);
    log.debug(`request headers: ${JSON.stringify(maskHeaders(requestHeaders))}`);
    if (options.params) log.debug(`query params: ${JSON.stringify(options.params)}`);
    if (options.data !== undefined) log.debug(`request body: ${JSON.stringify(maskBody(options.data))}`);

    const startedAt = Date.now();
    let response: APIResponse | undefined;
    let lastError: unknown;
    for (let attempt = 0; attempt <= env.networkRetries; attempt++) {
      try {
        response = await this.context.fetch(endpoint, {
          method,
          data: options.data as any,
          headers: options.headers,
          params: options.params
        });
        break;
      } catch (error) {
        lastError = error;
        log.warn(`${method} ${endpoint} network error (attempt ${attempt + 1}): ${(error as Error).message}`);
        if (attempt < env.networkRetries) await sleep(1000 * (attempt + 1));
      }
    }
    if (!response) {
      log.error(`${method} ${endpoint} failed after retries: ${(lastError as Error).message}`);
      throw lastError;
    }

    const text = await response.text();
    const durationMs = Date.now() - startedAt;
    let body: unknown = text;
    try {
      body = text.length ? JSON.parse(text) : text;
    } catch {
      /* not JSON - keep the raw text */
    }

    const result: ApiResult<T> = {
      status: response.status(),
      statusText: response.statusText(),
      ok: response.ok(),
      headers: response.headers(),
      body: body as T,
      text,
      durationMs,
      url: response.url()
    };

    this.history.push({
      timestamp,
      method,
      url: result.url,
      requestHeaders: maskHeaders(requestHeaders),
      requestBody: options.data === undefined ? undefined : maskBody(options.data),
      status: result.status,
      statusText: result.statusText,
      responseHeaders: maskHeaders(result.headers),
      responseBody: maskBody(body),
      durationMs
    });

    log.info(`<-- ${result.status} ${result.statusText} ${method} ${result.url} (${durationMs} ms)`);
    log.debug(`response body: ${JSON.stringify(maskBody(body))}`);
    return result;
  }
}
