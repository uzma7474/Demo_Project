import { ApiClient } from '../api/apiClient';
import { Endpoints } from '../api/endpoints';
import { ApiResult } from '../api/types';

export class HealthService {
  constructor(private readonly client: ApiClient) {}

  /** GET /ping */
  ping(): Promise<ApiResult<string>> {
    return this.client.get<string>(Endpoints.ping);
  }
}
