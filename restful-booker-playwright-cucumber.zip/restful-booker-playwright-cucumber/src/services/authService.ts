import { ApiClient } from '../api/apiClient';
import { Endpoints } from '../api/endpoints';
import { ApiResult } from '../api/types';
import { env } from '../config/env';
import { AuthRequest, AuthResponse, AuthType } from '../models/booking';

export class AuthService {
  constructor(private readonly client: ApiClient) {}

  /** POST /auth */
  createToken(credentials: AuthRequest): Promise<ApiResult<AuthResponse>> {
    return this.client.post<AuthResponse>(Endpoints.auth, { data: credentials });
  }

  async getValidToken(): Promise<string> {
    const res = await this.createToken({ username: env.username, password: env.password });
    if (res.status !== 200 || !res.body.token) {
      throw new Error(`Unable to obtain auth token: ${res.status} ${res.text}`);
    }
    return res.body.token;
  }

  /** Builds the headers needed by PUT / PATCH / DELETE. */
  static buildAuthHeaders(type: AuthType, token?: string): Record<string, string> {
    switch (type) {
      case 'cookie':
        if (!token) throw new Error('A token is required for cookie authentication');
        return { Cookie: `token=${token}` };
      case 'basic':
        return {
          Authorization: `Basic ${Buffer.from(`${env.username}:${env.password}`).toString('base64')}`
        };
      case 'invalid':
        return { Cookie: 'token=invalid-token-value' };
      case 'none':
      default:
        return {};
    }
  }
}
