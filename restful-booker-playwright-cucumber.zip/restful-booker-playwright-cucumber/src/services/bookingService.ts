import { ApiClient } from '../api/apiClient';
import { Endpoints } from '../api/endpoints';
import { ApiResult } from '../api/types';
import { Booking, BookingIdFilter, BookingIdItem, CreateBookingResponse } from '../models/booking';

export class BookingService {
  constructor(private readonly client: ApiClient) {}

  /** GET /booking (optionally filtered by firstname, lastname, checkin, checkout) */
  getBookingIds(filter: BookingIdFilter = {}): Promise<ApiResult<BookingIdItem[]>> {
    const params = Object.fromEntries(Object.entries(filter).filter(([, v]) => v !== undefined)) as Record<
      string,
      string
    >;
    return this.client.get<BookingIdItem[]>(Endpoints.booking, { params });
  }

  /** GET /booking/:id */
  getBooking(id: number | string): Promise<ApiResult<Booking>> {
    return this.client.get<Booking>(Endpoints.bookingById(id));
  }

  /** POST /booking */
  createBooking(payload: unknown): Promise<ApiResult<CreateBookingResponse>> {
    return this.client.post<CreateBookingResponse>(Endpoints.booking, { data: payload });
  }

  /** PUT /booking/:id (requires auth) */
  updateBooking(
    id: number | string,
    payload: Booking,
    authHeaders: Record<string, string>
  ): Promise<ApiResult<Booking>> {
    return this.client.put<Booking>(Endpoints.bookingById(id), { data: payload, headers: authHeaders });
  }

  /** PATCH /booking/:id (requires auth) */
  partialUpdateBooking(
    id: number | string,
    payload: Partial<Booking>,
    authHeaders: Record<string, string>
  ): Promise<ApiResult<Booking>> {
    return this.client.patch<Booking>(Endpoints.bookingById(id), { data: payload, headers: authHeaders });
  }

  /** DELETE /booking/:id (requires auth) */
  deleteBooking(id: number | string, authHeaders: Record<string, string>): Promise<ApiResult<string>> {
    return this.client.delete<string>(Endpoints.bookingById(id), { headers: authHeaders });
  }
}
