export interface BookingDates {
  checkin: string;
  checkout: string;
}

export interface Booking {
  firstname: string;
  lastname: string;
  totalprice: number;
  depositpaid: boolean;
  bookingdates: BookingDates;
  additionalneeds?: string;
}

export interface CreateBookingResponse {
  bookingid: number;
  booking: Booking;
}

export interface BookingIdItem {
  bookingid: number;
}

export interface BookingIdFilter {
  firstname?: string;
  lastname?: string;
  checkin?: string;
  checkout?: string;
}

export interface AuthRequest {
  username: string;
  password: string;
}

export interface AuthResponse {
  token?: string;
  reason?: string;
}

export type AuthType = 'cookie' | 'basic' | 'none' | 'invalid';
export const AUTH_TYPES: AuthType[] = ['cookie', 'basic', 'none', 'invalid'];
