import { IWorldOptions, setWorldConstructor, World } from '@cucumber/cucumber';
import { ApiClient } from '../api/apiClient';
import { ApiResult } from '../api/types';
import { AuthType, AUTH_TYPES, Booking } from '../models/booking';
import { AuthService } from '../services/authService';
import { BookingService } from '../services/bookingService';
import { HealthService } from '../services/healthService';
import { getLogger } from '../utils/logger';

const log = getLogger('World');

export class CustomWorld extends World {
  client = new ApiClient();
  auth!: AuthService;
  bookings!: BookingService;
  health!: HealthService;

  token?: string;
  bookingId?: number;
  bookingPayload?: Booking;
  response?: ApiResult;
  createdBookingIds: number[] = [];

  constructor(options: IWorldOptions) {
    super(options);
  }

  async init(): Promise<void> {
    await this.client.init();
    this.auth = new AuthService(this.client);
    this.bookings = new BookingService(this.client);
    this.health = new HealthService(this.client);
  }

  /** Deletes every booking created by the scenario so test runs stay clean. Errors are ignored. */
  async cleanup(): Promise<void> {
    if (this.createdBookingIds.length === 0) return;
    try {
      const token = this.token ?? (await this.auth.getValidToken());
      const headers = AuthService.buildAuthHeaders('cookie', token);
      for (const id of this.createdBookingIds) {
        await this.bookings.deleteBooking(id, headers);
      }
    } catch (error) {
      log.warn(`Cleanup failed: ${(error as Error).message}`);
    } finally {
      this.createdBookingIds = [];
    }
  }

  async dispose(): Promise<void> {
    await this.client.dispose();
  }

  get lastResponse(): ApiResult {
    if (!this.response) throw new Error('No response captured yet - a "When" step must run first.');
    return this.response;
  }

  requireToken(): string {
    if (!this.token) throw new Error('No auth token available. Add the step "I have a valid auth token".');
    return this.token;
  }

  requireBookingId(): number {
    if (this.bookingId === undefined) throw new Error('No booking id available. Add the step "a booking exists".');
    return this.bookingId;
  }

  requirePayload(): Booking {
    if (!this.bookingPayload) throw new Error('No booking payload available.');
    return this.bookingPayload;
  }

  authHeaders(type: string): Record<string, string> {
    if (!AUTH_TYPES.includes(type as AuthType)) {
      throw new Error(`Unknown authentication type "${type}". Use one of: ${AUTH_TYPES.join(', ')}`);
    }
    return AuthService.buildAuthHeaders(type as AuthType, type === 'cookie' ? this.requireToken() : undefined);
  }
}

setWorldConstructor(CustomWorld);
