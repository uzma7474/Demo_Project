import { After, AfterAll, Before, BeforeAll } from '@cucumber/cucumber';
import fs from 'fs';
import { env } from '../config/env';
import { saveScenarioRecord } from '../reporting/scenarioRecords';
import { getLogger } from '../utils/logger';
import { CustomWorld } from './world';

const log = getLogger('Hooks');

BeforeAll(function () {
  [env.paths.logs, env.paths.reports, env.paths.scenarioRecords].forEach((dir) =>
    fs.mkdirSync(dir, { recursive: true })
  );
  log.info(`===== Test run started | env=${env.name} | baseUrl=${env.baseUrl} =====`);
});

Before(async function (this: CustomWorld, { pickle }) {
  log.info(`>>> SCENARIO START: ${pickle.name}`);
  await this.init();
});

After(async function (this: CustomWorld, { pickle, result }) {
  const status = String(result?.status ?? 'UNKNOWN');
  await this.cleanup();

  if (this.client.history.length > 0) {
    // Shows up under each scenario in the Cucumber HTML / JSON reports.
    await this.attach(JSON.stringify(this.client.history, null, 2), 'application/json');
  }

  const duration = result?.duration ? result.duration.seconds + result.duration.nanos / 1e9 : 0;
  saveScenarioRecord({
    id: pickle.id,
    feature: pickle.uri,
    name: pickle.name,
    tags: pickle.tags.map((t) => t.name),
    status,
    durationSec: duration,
    error: result?.message,
    startedAt: new Date().toISOString(),
    apiCalls: [...this.client.history]
  });

  if (status === 'FAILED') log.error(`<<< SCENARIO FAILED: ${pickle.name}\n${result?.message ?? ''}`);
  else log.info(`<<< SCENARIO ${status}: ${pickle.name} (${duration.toFixed(2)}s)`);
  await this.dispose();
});

AfterAll(function () {
  log.info('===== Test run finished =====');
});
