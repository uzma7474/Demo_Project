import fs from 'fs';
import os from 'os';
import path from 'path';
import { env } from '../config/env';
import { RunSummary } from './summary';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const reporter = require('multiple-cucumber-html-reporter');

export function writeHtmlReport(summary: RunSummary): string | undefined {
  const jsonFile = path.join(env.paths.cucumberJson, 'cucumber-report.json');
  if (!fs.existsSync(jsonFile)) {
    return undefined;
  }
  reporter.generate({
    jsonDir: env.paths.cucumberJson,
    reportPath: env.paths.html,
    reportName: 'Restful-Booker API Test Report',
    pageTitle: 'Restful-Booker API Tests',
    displayDuration: true,
    displayReportTime: true,
    metadata: {
      device: `${os.hostname()}`,
      platform: { name: os.platform(), version: os.release() }
    },
    customData: {
      title: 'Run information',
      data: [
        { label: 'Environment', value: summary.environment },
        { label: 'Base URL', value: summary.baseUrl },
        { label: 'Pass rate', value: `${summary.passRatePct}%` },
        { label: 'API calls', value: String(summary.totalApiCalls) },
        { label: 'Avg response (ms)', value: String(summary.avgResponseMs) }
      ]
    }
  });
  return path.join(env.paths.html, 'index.html');
}
