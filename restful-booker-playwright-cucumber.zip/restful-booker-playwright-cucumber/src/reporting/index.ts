import { writeExcelReport } from './excelReport';
import { writeHtmlReport } from './htmlReport';
import { loadScenarioRecords } from './scenarioRecords';
import { buildSummary, writeJsonSummary } from './summary';

export async function generateAllReports(): Promise<void> {
  const records = loadScenarioRecords();
  if (records.length === 0) {
    console.warn('No scenario records found - did the tests run? Skipping report generation.');
    return;
  }
  const summary = buildSummary(records);
  const jsonFile = writeJsonSummary(summary);
  const excelFile = await writeExcelReport(records, summary);
  let htmlFile: string | undefined;
  try {
    htmlFile = writeHtmlReport(summary);
  } catch (error) {
    console.warn(`HTML report generation failed: ${(error as Error).message}`);
  }
  console.log('\nReports generated:');
  console.log(`  JSON summary : ${jsonFile}`);
  console.log(`  Excel report : ${excelFile}`);
  if (htmlFile) console.log(`  HTML report  : ${htmlFile}`);
  console.log(
    `  Result       : ${summary.passed}/${summary.total} passed, ${summary.failed} failed (${summary.passRatePct}%)`
  );
}
