import os from 'os';
import { env } from '../config/env';
import { JsonUtil } from '../utils/jsonUtil';
import path from 'path';
import { ScenarioRecord } from './scenarioRecords';

export interface RunSummary {
  generatedAt: string;
  environment: string;
  baseUrl: string;
  node: string;
  platform: string;
  total: number;
  passed: number;
  failed: number;
  skipped: number;
  other: number;
  passRatePct: number;
  totalDurationSec: number;
  totalApiCalls: number;
  avgResponseMs: number;
  byFeature: Record<string, { total: number; passed: number; failed: number }>;
  failedScenarios: { feature: string; name: string; error?: string }[];
}

export function buildSummary(records: ScenarioRecord[]): RunSummary {
  const count = (s: string): number => records.filter((r) => r.status === s).length;
  const passed = count('PASSED');
  const failed = count('FAILED');
  const skipped = count('SKIPPED');
  const calls = records.flatMap((r) => r.apiCalls);
  const byFeature: RunSummary['byFeature'] = {};
  for (const r of records) {
    const bucket = (byFeature[r.feature] ??= { total: 0, passed: 0, failed: 0 });
    bucket.total++;
    if (r.status === 'PASSED') bucket.passed++;
    if (r.status === 'FAILED') bucket.failed++;
  }
  return {
    generatedAt: new Date().toISOString(),
    environment: env.name,
    baseUrl: env.baseUrl,
    node: process.version,
    platform: `${os.platform()} ${os.release()}`,
    total: records.length,
    passed,
    failed,
    skipped,
    other: records.length - passed - failed - skipped,
    passRatePct: records.length ? Math.round((passed / records.length) * 1000) / 10 : 0,
    totalDurationSec: Math.round(records.reduce((s, r) => s + r.durationSec, 0) * 100) / 100,
    totalApiCalls: calls.length,
    avgResponseMs: calls.length ? Math.round(calls.reduce((s, c) => s + c.durationMs, 0) / calls.length) : 0,
    byFeature,
    failedScenarios: records
      .filter((r) => r.status === 'FAILED')
      .map((r) => ({ feature: r.feature, name: r.name, error: r.error }))
  };
}

export function writeJsonSummary(summary: RunSummary): string {
  const file = path.join(env.paths.reports, 'summary.json');
  JsonUtil.write(file, summary);
  return file;
}
