import ExcelJS from 'exceljs';
import fs from 'fs';
import path from 'path';
import { env } from '../config/env';
import { ScenarioRecord } from './scenarioRecords';
import { RunSummary } from './summary';

const HEADER_FILL: ExcelJS.Fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F3864' } };
const fillFor = (status: string): ExcelJS.Fill => ({
  type: 'pattern',
  pattern: 'solid',
  fgColor: { argb: status === 'PASSED' ? 'FFC6EFCE' : status === 'FAILED' ? 'FFFFC7CE' : 'FFFFEB9C' }
});

function styleHeader(row: ExcelJS.Row): void {
  row.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = HEADER_FILL;
    cell.alignment = { vertical: 'middle', horizontal: 'center' };
  });
}

const clip = (value: unknown, max = 2000): string => {
  if (value === undefined) return '';
  const text = typeof value === 'string' ? value : JSON.stringify(value);
  return text.length > max ? `${text.slice(0, max)}...` : text;
};

export async function writeExcelReport(records: ScenarioRecord[], summary: RunSummary): Promise<string> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'restful-booker-playwright-cucumber';
  workbook.created = new Date();

  // ---- Summary ----
  const sum = workbook.addWorksheet('Summary');
  sum.columns = [
    { header: 'Metric', key: 'metric', width: 28 },
    { header: 'Value', key: 'value', width: 48 }
  ];
  styleHeader(sum.getRow(1));
  const rows: [string, string | number][] = [
    ['Generated at', summary.generatedAt],
    ['Environment', summary.environment],
    ['Base URL', summary.baseUrl],
    ['Node', summary.node],
    ['Platform', summary.platform],
    ['Total scenarios', summary.total],
    ['Passed', summary.passed],
    ['Failed', summary.failed],
    ['Skipped', summary.skipped],
    ['Other (undefined/pending)', summary.other],
    ['Pass rate (%)', summary.passRatePct],
    ['Total duration (s)', summary.totalDurationSec],
    ['Total API calls', summary.totalApiCalls],
    ['Avg response time (ms)', summary.avgResponseMs]
  ];
  rows.forEach(([metric, value]) => sum.addRow({ metric, value }));
  sum.addRow({});
  const featHeader = sum.addRow({ metric: 'Feature', value: 'Total / Passed / Failed' });
  styleHeader(featHeader);
  Object.entries(summary.byFeature).forEach(([feature, b]) =>
    sum.addRow({ metric: feature, value: `${b.total} / ${b.passed} / ${b.failed}` })
  );

  // ---- Scenarios ----
  const sc = workbook.addWorksheet('Scenarios');
  sc.columns = [
    { header: 'Feature file', key: 'feature', width: 38 },
    { header: 'Scenario', key: 'name', width: 60 },
    { header: 'Tags', key: 'tags', width: 30 },
    { header: 'Status', key: 'status', width: 12 },
    { header: 'Duration (s)', key: 'duration', width: 14 },
    { header: 'API calls', key: 'calls', width: 10 },
    { header: 'Error', key: 'error', width: 80 }
  ];
  styleHeader(sc.getRow(1));
  sc.views = [{ state: 'frozen', ySplit: 1 }];
  records.forEach((r) => {
    const row = sc.addRow({
      feature: r.feature,
      name: r.name,
      tags: r.tags.join(' '),
      status: r.status,
      duration: Math.round(r.durationSec * 1000) / 1000,
      calls: r.apiCalls.length,
      error: clip(r.error, 1500)
    });
    row.getCell('status').fill = fillFor(r.status);
  });
  sc.autoFilter = { from: 'A1', to: 'G1' };

  // ---- API Calls ----
  const api = workbook.addWorksheet('API Calls');
  api.columns = [
    { header: 'Scenario', key: 'scenario', width: 50 },
    { header: 'Timestamp', key: 'ts', width: 26 },
    { header: 'Method', key: 'method', width: 9 },
    { header: 'URL', key: 'url', width: 55 },
    { header: 'Status', key: 'status', width: 9 },
    { header: 'Duration (ms)', key: 'dur', width: 14 },
    { header: 'Request body', key: 'req', width: 60 },
    { header: 'Response body', key: 'res', width: 60 }
  ];
  styleHeader(api.getRow(1));
  api.views = [{ state: 'frozen', ySplit: 1 }];
  records.forEach((r) =>
    r.apiCalls.forEach((c) =>
      api.addRow({
        scenario: r.name,
        ts: c.timestamp,
        method: c.method,
        url: c.url,
        status: c.status,
        dur: c.durationMs,
        req: clip(c.requestBody),
        res: clip(c.responseBody)
      })
    )
  );
  api.autoFilter = { from: 'A1', to: 'H1' };

  fs.mkdirSync(env.paths.reports, { recursive: true });
  const file = path.join(env.paths.reports, 'execution-report.xlsx');
  await workbook.xlsx.writeFile(file);
  return file;
}
