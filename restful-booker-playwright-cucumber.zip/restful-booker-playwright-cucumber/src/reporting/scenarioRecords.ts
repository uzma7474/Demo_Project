import fs from 'fs';
import path from 'path';
import { ApiCallRecord } from '../api/types';
import { env } from '../config/env';
import { JsonUtil } from '../utils/jsonUtil';

/** One JSON file per scenario - safe to write from parallel cucumber workers. */
export interface ScenarioRecord {
  id: string;
  feature: string;
  name: string;
  tags: string[];
  status: string;
  durationSec: number;
  error?: string;
  startedAt: string;
  apiCalls: ApiCallRecord[];
}

export function saveScenarioRecord(record: ScenarioRecord): void {
  JsonUtil.write(path.join(env.paths.scenarioRecords, `${record.id}.json`), record);
}

export function loadScenarioRecords(): ScenarioRecord[] {
  if (!fs.existsSync(env.paths.scenarioRecords)) return [];
  return fs
    .readdirSync(env.paths.scenarioRecords)
    .filter((f) => f.endsWith('.json'))
    .map((f) => JsonUtil.read<ScenarioRecord>(path.join(env.paths.scenarioRecords, f)))
    .sort((a, b) => a.feature.localeCompare(b.feature) || a.name.localeCompare(b.name));
}

export function cleanReports(): void {
  fs.rmSync(env.paths.reports, { recursive: true, force: true });
  fs.mkdirSync(env.paths.reports, { recursive: true });
}
