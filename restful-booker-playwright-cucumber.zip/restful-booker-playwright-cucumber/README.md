# Restful-Booker API Automation Framework

Playwright (`APIRequestContext`) + Cucumber (classic **cucumber-js**) + TypeScript framework covering every REST API
in the [Restful-Booker API docs](https://restful-booker.herokuapp.com/apidoc/index.html).

No browser is used, so `npx playwright install` is **not** required.

## API coverage

| API (apidoc)                 | Method & path            | Feature file                       |
|------------------------------|--------------------------|------------------------------------|
| Auth - CreateToken           | POST /auth               | `features/create-token.feature`    |
| Booking - GetBookingIds      | GET /booking (+filters)  | `features/get-booking-ids.feature` |
| Booking - GetBooking         | GET /booking/:id         | `features/get-booking.feature`     |
| Booking - CreateBooking      | POST /booking            | `features/create-booking.feature`  |
| Booking - UpdateBooking      | PUT /booking/:id         | `features/update-booking.feature`  |
| Booking - PartialUpdateBooking | PATCH /booking/:id     | `features/partial-update-booking.feature` |
| Booking - DeleteBooking      | DELETE /booking/:id      | `features/delete-booking.feature`  |
| Ping - HealthCheck           | GET /ping                | `features/health-check.feature`    |

## Setup

```bash
npm install
npm run test:report        # run all tests, then build JSON + Excel + HTML reports
```

Requires Node 18+.

## Commands

| Command | What it does |
|---|---|
| `npm test` | Run all scenarios (cleans `reports/` first) |
| `npm run test:smoke` / `test:regression` | Run by profile (`@smoke`, `@regression`) |
| `npm run test:parallel` | Run with 4 parallel workers |
| `npm run test:report -- --tags "@booking and @negative"` | Run with any cucumber-js args, then **always** generate reports |
| `npm run report` | Regenerate reports from the last run |
| `npm run typecheck` | `tsc --noEmit` |

Env vars: `TEST_ENV` (loads `env/.env.<name>`, default `qa`), `RETRY`, `PARALLEL`, `LOG_LEVEL`, `CONSOLE_LOG_LEVEL`.

## Architecture

```
features/                 Gherkin scenarios (one file per API)
src/steps/                Step definitions (thin - delegate to services)
src/support/              World (per-scenario state) and Before/After hooks
src/services/             One class per API resource (Auth, Booking, Health)
src/api/                  ApiClient (Playwright wrapper), endpoints, types
src/models/               TypeScript interfaces for payloads
src/schemas/              JSON schemas for response validation (ajv)
src/utils/                logger (winston), JsonUtil, ExcelUtil, data factory, schema validator
src/reporting/            Scenario records, JSON summary, Excel report, HTML report
scripts/                  run / clean / generateReports
test-data/                Static test data (bookings.json)
env/                      Environment files
```

Key design points:
- **ApiClient** logs every request/response, masks `Cookie`, `Authorization`, `token` and `password`, measures
  response time, retries on network errors, and keeps a per-scenario call history.
- **Hooks** create a fresh client per scenario, attach the call history (JSON) to the scenario, delete bookings the
  scenario created, and write one JSON record per scenario (safe for parallel workers).
- **Auth strategies** for protected endpoints: `cookie` (token), `basic`, `invalid`, `none`.
- **Schema validation** with ajv on responses (`the response body should match the "booking" schema`).

## Logging

Winston writes to `logs/automation-YYYY-MM-DD.log` (all levels from `LOG_LEVEL`, 14-day rotation) and
`logs/error-YYYY-MM-DD.log`. The console shows only warnings by default; set `CONSOLE_LOG_LEVEL=info` to see more.

## Reports (all in `reports/`)

| File | Content |
|---|---|
| `html/index.html` | Rich HTML report (multiple-cucumber-html-reporter) with API call attachments per scenario |
| `cucumber-report.html` | Cucumber's built-in HTML report |
| `cucumber-json/cucumber-report.json` | Standard Cucumber JSON (CI tools, Xray, etc.) |
| `summary.json` | Totals, pass rate, per-feature counts, failed scenarios |
| `execution-report.xlsx` | Sheets: **Summary**, **Scenarios**, **API Calls** |

## Data-driven testing

- `Scenario Outline` + `Examples` tables (see `create-booking.feature`)
- JSON files: `JsonUtil.readTestData('bookings.json')`
- Excel files: `await ExcelUtil.readSheet('bookings.xlsx', 'Sheet1')` (first row = headers)

## Adding a new test

1. Add a method to the matching service in `src/services/`.
2. Add steps in `src/steps/*.steps.ts` (reuse the common ones where possible).
3. Write the scenario in `features/` and tag it (`@smoke`, `@regression`, `@negative`).

## Notes on the sandbox API

Restful-Booker is a deliberately quirky practice API: it resets every ~10 minutes, bad credentials return
`200` with `{"reason":"Bad credentials"}`, ping returns `201`, successful delete returns `201`, and deleting a missing
booking returns `405`. These behaviours are asserted as-is; the 405 case is tagged `@known-behavior` and excluded from
the `regression` profile. If the sandbox changes behaviour, adjust the expected values in the feature files.
