@auth
Feature: Create auth token
  As an API consumer
  I want to exchange credentials for a token
  So that I can call protected endpoints

  @smoke @regression
  Scenario: Generate a token with valid credentials
    When I request an auth token with valid credentials
    Then the response status code should be 200
    And the response body should match the "token" schema
    And the response should contain a token

  @regression @negative
  Scenario Outline: Reject invalid credentials
    When I request an auth token with username "<username>" and password "<password>"
    Then the response status code should be 200
    And the response should contain the reason "Bad credentials"

    Examples:
      | username | password    |
      | admin    | wrong       |
      | unknown  | password123 |
      | unknown  | wrong       |
