@booking @update-booking
Feature: Update booking (PUT)
  As an authorised API consumer
  I want to replace a booking
  So that its details are corrected

  @smoke @regression
  Scenario: Update a booking using a token cookie
    Given I have a valid auth token
    And a booking exists
    When I update the booking with new details using "cookie" authentication
    Then the response status code should be 200
    And the response body should match the "booking" schema
    And the booking details should match the payload

  @regression
  Scenario: Update a booking using basic authentication
    Given a booking exists
    When I update the booking with new details using "basic" authentication
    Then the response status code should be 200
    And the booking details should match the payload

  @regression @negative
  Scenario Outline: Updating without valid authentication is forbidden
    Given a booking exists
    When I update the booking with new details using "<authType>" authentication
    Then the response status code should be 403
    And the response body should be "Forbidden"

    Examples:
      | authType |
      | none     |
      | invalid  |
