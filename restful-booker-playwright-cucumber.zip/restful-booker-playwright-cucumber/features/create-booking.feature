@booking @create-booking
Feature: Create booking
  As an API consumer
  I want to create a booking
  So that a guest has a reservation

  @smoke @regression
  Scenario: Create a booking with valid data
    Given I have a new booking payload
    When I create the booking
    Then the response status code should be 200
    And the response body should match the "createBookingResponse" schema
    And the response should contain a booking id
    And the created booking should match the payload

  @regression
  Scenario: The created booking can be retrieved
    Given I have a new booking payload
    When I create the booking
    And I request the booking details
    Then the response status code should be 200
    And the booking details should match the payload

  @regression @data-driven
  Scenario Outline: Create bookings with different names
    Given I have a booking payload with firstname "<firstname>" and lastname "<lastname>"
    When I create the booking
    Then the response status code should be 200
    And the created booking should match the payload

    Examples:
      | firstname | lastname |
      | John      | Smith    |
      | Mary      | O'Neil   |
      | Zoë       | Müller   |

  @regression @data-driven
  Scenario: Create bookings from a JSON test data file
    When I create bookings from the test data file "bookings.json"
    Then the response status code should be 200
