@booking @delete-booking
Feature: Delete booking
  As an authorised API consumer
  I want to delete a booking
  So that cancelled reservations are removed

  @smoke @regression
  Scenario: Delete a booking using a token cookie
    Given I have a valid auth token
    And a booking exists
    When I delete the booking using "cookie" authentication
    Then the response status code should be 201
    And the response body should be "Created"
    And the booking should no longer exist

  @regression
  Scenario: Delete a booking using basic authentication
    Given a booking exists
    When I delete the booking using "basic" authentication
    Then the response status code should be 201
    And the booking should no longer exist

  @regression @negative
  Scenario: Deleting without authentication is forbidden
    Given a booking exists
    When I delete the booking using "none" authentication
    Then the response status code should be 403
    And the response body should be "Forbidden"
    And the booking should still exist

  # Documented quirk of the sandbox API: deleting a missing booking returns 405 instead of 404.
  @regression @negative @known-behavior
  Scenario: Deleting a booking that does not exist
    Given I have a valid auth token
    And a booking exists
    When I delete the booking with id 99999999 using "cookie" authentication
    Then the response status code should be 405
