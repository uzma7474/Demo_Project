@booking @get-booking-ids
Feature: Get booking ids
  As an API consumer
  I want to list booking ids with optional filters
  So that I can find the bookings I care about

  @smoke @regression
  Scenario: Retrieve all booking ids
    When I request all booking ids
    Then the response status code should be 200
    And the response body should match the "bookingIds" schema
    And the response should contain at least 1 booking id

  @regression
  Scenario: Filter booking ids by firstname and lastname
    Given a booking exists
    When I filter booking ids by the booking's firstname and lastname
    Then the response status code should be 200
    And the response body should match the "bookingIds" schema
    And the booking id list should contain the booking id

  @regression @negative
  Scenario: Filtering by an unknown name returns an empty list
    When I request booking ids filtered by firstname "Nonexistentfirst" and lastname "Nonexistentlast"
    Then the response status code should be 200
    And the booking id list should be empty

  @regression
  Scenario: Filter booking ids by checkin and checkout dates
    Given a booking exists
    When I filter booking ids by the booking's checkin and checkout dates
    Then the response status code should be 200
    And the response body should match the "bookingIds" schema

  @regression
  Scenario: Filter booking ids by an explicit date range
    When I request booking ids filtered by checkin "2022-01-01" and checkout "2030-12-31"
    Then the response status code should be 200
    And the response body should match the "bookingIds" schema
