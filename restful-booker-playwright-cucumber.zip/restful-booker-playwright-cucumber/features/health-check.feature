@health
Feature: Health check
  As an API consumer
  I want to know whether the Restful-Booker API is up
  So that I can stop early if the service is down

  @smoke @regression
  Scenario: API responds to a ping
    When I send a health check request
    Then the response status code should be 201
    And the response body should be "Created"
    And the response time should be within the configured limit
