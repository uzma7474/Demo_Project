@booking @get-booking
Feature: Get booking
  As an API consumer
  I want to retrieve a single booking by id
  So that I can see its details

  @smoke @regression
  Scenario: Retrieve an existing booking
    Given a booking exists
    When I request the booking details
    Then the response status code should be 200
    And the response body should match the "booking" schema
    And the booking details should match the payload

  @regression @negative
  Scenario: Retrieve a booking that does not exist
    When I request the booking with id 99999999
    Then the response status code should be 404
    And the response body should be "Not Found"
