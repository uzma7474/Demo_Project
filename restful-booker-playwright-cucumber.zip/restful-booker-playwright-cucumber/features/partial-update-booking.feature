@booking @partial-update-booking
Feature: Partially update booking (PATCH)
  As an authorised API consumer
  I want to change only some fields of a booking
  So that I do not have to resend the whole booking

  @smoke @regression
  Scenario: Partially update the names of a booking
    Given I have a valid auth token
    And a booking exists
    When I partially update the booking firstname to "Updated" and lastname to "Guest" using "cookie" authentication
    Then the response status code should be 200
    And the booking details should match the payload

  @regression @negative
  Scenario: Partial update without authentication is forbidden
    Given a booking exists
    When I partially update the booking firstname to "Updated" and lastname to "Guest" using "none" authentication
    Then the response status code should be 403
    And the response body should be "Forbidden"
