import { generateAllReports } from '../src/reporting';

generateAllReports().catch((error) => {
  console.error(error);
  process.exit(1);
});
