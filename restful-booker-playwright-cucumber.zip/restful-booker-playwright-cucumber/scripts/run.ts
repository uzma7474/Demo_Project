/**
 * Runs cucumber-js, then ALWAYS generates the reports (even when scenarios fail).
 * Usage: npm run test:report -- --tags @smoke   (any cucumber-js CLI args are passed through)
 */
import { spawnSync } from 'child_process';
import path from 'path';
import { generateAllReports } from '../src/reporting';
import { cleanReports } from '../src/reporting/scenarioRecords';

async function main(): Promise<void> {
  cleanReports();
  const cucumberBin = path.join(process.cwd(), 'node_modules', '@cucumber', 'cucumber', 'bin', 'cucumber.js');
  const result = spawnSync(process.execPath, [cucumberBin, ...process.argv.slice(2)], {
    stdio: 'inherit',
    env: process.env
  });
  await generateAllReports();
  process.exit(result.status ?? 1);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
