import { cleanReports } from '../src/reporting/scenarioRecords';

cleanReports();
