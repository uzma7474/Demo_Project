# Petstore API Framework - Modern approach (playwright-bdd)

Playwright Test + **playwright-bdd** + TypeScript, covering all 20 operations of the
[Swagger Petstore v2](https://petstore.swagger.io/) API (`pet`, `store`, `user`).

`playwright-bdd` compiles each Gherkin scenario into a native Playwright test, so you get Playwright's runner
features (fixtures, parallel workers, retries, `--grep`, HTML report, trace/attachments) without cucumber-js.
No browser is launched - requests go through Playwright's `APIRequestContext`.
The sibling project `petstore-api-cucumberjs-classic` shares exactly the same core, features and test data
and only swaps the runner.

## Quick start

```bash
npm install
cp .env.example .env        # optional
npm test                    # bddgen (generate tests) + playwright test
npm run test:smoke          # @smoke
npm run report              # open the Playwright HTML report
npx bddgen && npx playwright test --grep "@pet" --grep-invert "@negative" --workers=2
```

Reports: `reports/playwright-report` (Playwright HTML), `reports/cucumber-report/report.html|json` (Cucumber style).
Request/response pairs are attached to every test (the full conversation when it fails). Logs: `logs/api-tests.log`.
`bddgen` writes the generated specs to `.features-gen/` - do not edit or commit them.

Requires Node 18+.

## API coverage

| Tag | Operation | Endpoint | Feature |
| --- | --- | --- | --- |
| pet | Add pet | `POST /pet` | pet, data-driven, e2e |
| pet | Update pet | `PUT /pet` | pet, e2e |
| pet | Find by status | `GET /pet/findByStatus` | pet |
| pet | Find by tags | `GET /pet/findByTags` | pet |
| pet | Get pet | `GET /pet/{petId}` | pet |
| pet | Update with form | `POST /pet/{petId}` | pet |
| pet | Delete pet | `DELETE /pet/{petId}` | pet, e2e |
| pet | Upload image | `POST /pet/{petId}/uploadImage` | pet |
| store | Inventory | `GET /store/inventory` | store |
| store | Place order | `POST /store/order` | store, data-driven, e2e |
| store | Get order | `GET /store/order/{orderId}` | store, data-driven |
| store | Delete order | `DELETE /store/order/{orderId}` | store, e2e |
| user | Create user | `POST /user` | user, data-driven |
| user | Create with array | `POST /user/createWithArray` | user |
| user | Create with list | `POST /user/createWithList` | user |
| user | Login | `GET /user/login` | user, e2e |
| user | Logout | `GET /user/logout` | user, e2e |
| user | Get user | `GET /user/{username}` | user, data-driven |
| user | Update user | `PUT /user/{username}` | user |
| user | Delete user | `DELETE /user/{username}` | user |

## Design patterns (the "hybrid" design)

| Pattern | Where | Why |
| --- | --- | --- |
| **Service Object Model** (API twin of Page Object) | `src/services` | One class per Swagger tag; tests never build URLs or headers. |
| **Builder** | `src/builders` | Valid-by-default payloads with fluent overrides. |
| **Factory** | `ServiceFactory`, `DataProviderFactory`, `RequestContextFactory` | Central object creation. |
| **Strategy** | `src/data` (`TestDataProvider`: JSON / Excel) | Same scenario, interchangeable data source. |
| **Singleton** | `Config`, `Logger` | One configuration and one log file per process. |
| **Flow / Task layer (Facade)** | `src/flows` | Business actions + assertions; step definitions stay one-liners. |
| **Fixture-based dependency injection** | `src/bdd/fixtures.ts` (`ctx`) | Playwright creates and tears down a `TestContext` per scenario. |
| **Response wrapper** | `ApiResult` | Body read once; JSON, headers, timing available to every assertion. |
| **BDD + data-driven** | `features`, `test-data` | Gherkin for behaviour, JSON/Excel for data. |

Control flow: `feature -> step definition -> flow -> service -> ApiClient -> Petstore`

```
petstore-api-playwright-bdd/
├── playwright.config.ts         # defineBddConfig + reporters + workers
├── features/                    # pet, store, user, data-driven, e2e
├── src/
│   ├── config/Config.ts         # Singleton, env + .env
│   ├── core/                    # ApiClient, ApiResult, Endpoints, TestContext, Logger, RequestContextFactory
│   ├── models/  services/  builders/  factories/  flows/  schemas/
│   ├── data/                    # TestDataProvider, JsonDataProvider, ExcelDataProvider, ExcelMapper, DataProviderFactory
│   ├── utils/                   # JsonReader, ExcelReader, ExcelWriter, DataResolver, SchemaValidator, RandomUtil, RetryUtil
│   └── bdd/                     # playwright-bdd only: fixtures.ts (ctx) + steps
├── test-data/                   # json/*.json, excel/petstore-data.xlsx, files/sample-pet.png
└── scripts/                     # generate-excel.ts, generate_steps.py, clean.js
```

## JSON and Excel utilities

* `JsonReader` - `read`, `readRecord(file, key)`, `write`, `getByPath(body, "tags[0].name")`.
* `ExcelReader` - `readSheet(file, sheet)` returns row objects keyed by header; `findRow(file, sheet, key)` (key column `TestCaseId`).
* `ExcelWriter` - `writeSheet(file, sheet, rows)`, e.g. to export an execution summary.
* `DataResolver` - placeholders usable in both JSON and Excel cells:
  `{{randomId}}` (stays numeric), `{{randomString:Rex}}`, `{{randomEmail:john}}`, `{{randomInt:1:10}}`, `{{timestamp}}`, `{{now}}`, `{{env:NAME}}`.

Excel layout (`test-data/excel/petstore-data.xlsx`): sheets `Pets`, `Users`, `Orders`; first column `TestCaseId`;
list columns (`PhotoUrls`, `Tags`) are `;`-separated. JSON files use the **same keys** as the `TestCaseId` column, so a scenario
can switch source with one word:

```gherkin
When I add the pet "PET_DOG_AVAILABLE" from the "excel" data source
```

## Adding a new endpoint or scenario

1. Add the path to `src/core/Endpoints.ts` and a method to the right service.
2. Add a business action (and assertions) to the matching flow in `src/flows`.
3. Add the step to `scripts/generate_steps.py` and run `python3 scripts/generate_steps.py . bdd`
   (or write the one-liner in `src/bdd/steps` by hand, importing `Given/When/Then` from `../fixtures`).
4. Write the scenario in `features/`, then `npm test`.

## Notes about the public Petstore

* It is a shared sandbox: data can be modified or wiped by anybody. Every test creates its own unique ids/usernames and
  cleans up after itself; read-after-write checks poll briefly because the service is eventually consistent.
* List responses (`findByStatus`) contain junk data from other users, so the `pets` schema is deliberately loose.
* To run against your own instance: `docker run -p 8080:8080 swaggerapi/petstore` then `ENV=local npm test`.
* Petstore v3 (`https://petstore3.swagger.io/api/v3`) has a different contract; set `BASE_URL` and adapt the models/endpoints.
* `playwright-bdd` evolves quickly; if a future major version renames config options, check `playwright.config.ts`
  against its migration notes (`steps` and `features` are the two options used).
