#!/usr/bin/env python3
"""
Generates the thin step-definition files for BOTH frameworks from one table, so
the two projects always expose exactly the same Gherkin vocabulary.

  classic: src/classic/steps/*.steps.ts   (cucumber-js, `this.ctx`)
  modern : src/bdd/steps/*.steps.ts       (playwright-bdd, `{ ctx }` fixture)

Usage: python3 generate_steps.py <project-root> <classic|bdd>
"""
import os
import sys

# (keyword, pattern, [(param, ts_type)], flow call with {ctx} placeholder)
COMMON = [
    ("Given", "the Petstore API is available", [], "CommonFlow.assertApiIsAvailable({ctx})"),
    ("Then", "the response status code should be {int}", [("expected", "number")], "CommonFlow.assertStatus({ctx}, expected)"),
    ("Then", "the response status code should be one of {string}", [("allowed", "string")], "CommonFlow.assertStatusOneOf({ctx}, allowed)"),
    ("Then", "the response body field {string} should equal {string}", [("path", "string"), ("expected", "string")], "CommonFlow.assertBodyField({ctx}, path, expected)"),
    ("Then", "the response body field {string} should exist", [("path", "string")], "CommonFlow.assertBodyFieldExists({ctx}, path)"),
    ("Then", "the response message should contain {string}", [("text", "string")], "CommonFlow.assertMessageContains({ctx}, text)"),
    ("Then", "the response should be a JSON array", [], "CommonFlow.assertJsonArray({ctx})"),
    ("Then", "the response header {string} should exist", [("name", "string")], "CommonFlow.assertHeaderExists({ctx}, name)"),
    ("Then", "the response time should be under {int} ms", [("maxMs", "number")], "CommonFlow.assertResponseTime({ctx}, maxMs)"),
    ("Then", "the response should match the {string} schema", [("schema", "string")], "CommonFlow.assertSchema({ctx}, schema)"),
]

PET = [
    ("When", "I add a pet named {string} with status {string}", [("name", "string"), ("status", "string")], "PetFlow.createPet({ctx}, name, status)"),
    ("When", "I add the pet {string} from the {string} data source", [("key", "string"), ("source", "string")], "PetFlow.createPetFromDataSource({ctx}, key, source)"),
    ("Given", "a pet named {string} with status {string} exists", [("name", "string"), ("status", "string")], "PetFlow.ensurePetExists({ctx}, name, status)"),
    ("When", "I get the pet by its id", [], "PetFlow.getCurrentPet({ctx})"),
    ("When", "I get the pet with id {int}", [("id", "number")], "PetFlow.getPetById({ctx}, id)"),
    ("When", "I update the pet name to {string} and status to {string}", [("name", "string"), ("status", "string")], "PetFlow.updatePet({ctx}, name, status)"),
    ("When", "I update the pet with form data name {string} and status {string}", [("name", "string"), ("status", "string")], "PetFlow.updatePetViaForm({ctx}, name, status)"),
    ("When", "I find pets by status {string}", [("statuses", "string")], "PetFlow.findByStatus({ctx}, statuses)"),
    ("When", "I find pets by tags {string}", [("tags", "string")], "PetFlow.findByTags({ctx}, tags)"),
    ("When", "I delete the pet", [], "PetFlow.deleteCurrentPet({ctx})"),
    ("When", "I delete the pet with id {int}", [("id", "number")], "PetFlow.deletePetById({ctx}, id)"),
    ("When", "I upload the image {string} for the pet with metadata {string}", [("fileName", "string"), ("metadata", "string")], "PetFlow.uploadImage({ctx}, fileName, metadata)"),
    ("When", "I add a pet with a malformed JSON body", [], "PetFlow.createPetWithMalformedBody({ctx})"),
    ("Then", "the pet should no longer exist", [], "PetFlow.assertPetIsGone({ctx})"),
    ("Then", "the response should match the submitted pet", [], "PetFlow.assertResponseMatchesSubmittedPet({ctx})"),
    ("Then", "every pet in the response should have one of the statuses {string}", [("statuses", "string")], "PetFlow.assertEveryPetHasStatus({ctx}, statuses)"),
    ("Then", "the response message should be the pet id", [], "PetFlow.assertMessageIsPetId({ctx})"),
]

STORE = [
    ("When", "I request the store inventory", [], "StoreFlow.getInventory({ctx})"),
    ("When", "I place an order for the pet with quantity {int}", [("quantity", "number")], "StoreFlow.placeOrder({ctx}, quantity)"),
    ("Given", "an order is placed for quantity {int}", [("quantity", "number")], "StoreFlow.ensureOrderExists({ctx}, quantity)"),
    ("When", "I place the order {string} from the {string} data source", [("key", "string"), ("source", "string")], "StoreFlow.placeOrderFromDataSource({ctx}, key, source)"),
    ("When", "I get the order by its id", [], "StoreFlow.getCurrentOrder({ctx})"),
    ("When", "I get the order with id {int}", [("id", "number")], "StoreFlow.getOrderById({ctx}, id)"),
    ("When", "I delete the order", [], "StoreFlow.deleteCurrentOrder({ctx})"),
    ("When", "I delete the order with id {int}", [("id", "number")], "StoreFlow.deleteOrderById({ctx}, id)"),
    ("Then", "the order should no longer exist", [], "StoreFlow.assertOrderIsGone({ctx})"),
    ("Then", "the response should match the submitted order", [], "StoreFlow.assertResponseMatchesSubmittedOrder({ctx})"),
    ("Then", "the response message should be the order id", [], "StoreFlow.assertMessageIsOrderId({ctx})"),
]

USER = [
    ("When", "I create a user {string}", [("username", "string")], "UserFlow.createUser({ctx}, username)"),
    ("Given", "a user {string} exists", [("username", "string")], "UserFlow.ensureUserExists({ctx}, username)"),
    ("When", "I create the user {string} from the {string} data source", [("key", "string"), ("source", "string")], "UserFlow.createUserFromDataSource({ctx}, key, source)"),
    ("When", "I create users with the usernames {string} using the array endpoint", [("usernames", "string")], "UserFlow.createUsersWithArray({ctx}, usernames)"),
    ("When", "I create users with the usernames {string} using the list endpoint", [("usernames", "string")], "UserFlow.createUsersWithList({ctx}, usernames)"),
    ("Then", "each created user should be retrievable", [], "UserFlow.assertEachCreatedUserIsRetrievable({ctx})"),
    ("When", "I get the user by username", [], "UserFlow.getCurrentUser({ctx})"),
    ("When", "I get the user {string}", [("username", "string")], "UserFlow.getUserByUsername({ctx}, username)"),
    ("When", "I update the user email to {string}", [("email", "string")], "UserFlow.updateEmail({ctx}, email)"),
    ("When", "I delete the user", [], "UserFlow.deleteCurrentUser({ctx})"),
    ("When", "I delete the user {string}", [("username", "string")], "UserFlow.deleteUserByUsername({ctx}, username)"),
    ("When", "I login with the created user credentials", [], "UserFlow.loginWithCurrentUser({ctx})"),
    ("When", "I login with username {string} and password {string}", [("username", "string"), ("password", "string")], "UserFlow.login({ctx}, username, password)"),
    ("When", "I logout", [], "UserFlow.logout({ctx})"),
    ("Then", "the user should no longer exist", [], "UserFlow.assertUserIsGone({ctx})"),
    ("Then", "the response should match the submitted user", [], "UserFlow.assertResponseMatchesSubmittedUser({ctx})"),
    ("Then", "the response message should be the user id", [], "UserFlow.assertMessageIsUserId({ctx})"),
    ("Then", "the response message should be the username", [], "UserFlow.assertMessageIsUsername({ctx})"),
    ("Then", "the response should contain a login session message", [], "UserFlow.assertLoginSession({ctx})"),
]

FILES = {
    "common": ("CommonFlow", COMMON),
    "pet": ("PetFlow", PET),
    "store": ("StoreFlow", STORE),
    "user": ("UserFlow", USER),
}


def ts_string(value: str) -> str:
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


def render(flow: str, steps: list, mode: str) -> str:
    keywords = sorted({s[0] for s in steps})
    lines = ["// GENERATED by scripts/generate_steps.py - keep step bodies thin, put logic in src/flows."]
    if mode == "classic":
        lines.append(f"import {{ {', '.join(keywords)} }} from '@cucumber/cucumber';")
        lines.append("import { CustomWorld } from '../support/CustomWorld';")
    else:
        lines.append(f"import {{ {', '.join(keywords)} }} from '../fixtures';")
    lines.append(f"import {{ {flow} }} from '../../flows/{flow}';")
    lines.append("")
    for keyword, pattern, params, call in steps:
        if mode == "classic":
            args = ", ".join(["this: CustomWorld"] + [f"{n}: {t}" for n, t in params])
            lines.append(f"{keyword}({ts_string(pattern)}, async function ({args}) {{")
            lines.append(f"  await {call.replace('{ctx}', 'this.ctx')};")
        else:
            args = ", ".join(["{ ctx }"] + [f"{n}: {t}" for n, t in params])
            lines.append(f"{keyword}({ts_string(pattern)}, async ({args}) => {{")
            lines.append(f"  await {call.replace('{ctx}', 'ctx')};")
        lines.append("});")
        lines.append("")
    return "\n".join(lines)


def main() -> None:
    root, mode = sys.argv[1], sys.argv[2]
    target = os.path.join(root, "src", "classic" if mode == "classic" else "bdd", "steps")
    os.makedirs(target, exist_ok=True)
    for name, (flow, steps) in FILES.items():
        path = os.path.join(target, f"{name}.steps.ts")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(render(flow, steps, mode))
        print(f"wrote {path} ({len(steps)} steps)")


if __name__ == "__main__":
    main()
