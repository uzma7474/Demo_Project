import { test as base, createBdd } from 'playwright-bdd';
import { TestContext } from '../core/TestContext';

/**
 * playwright-bdd fixtures. `ctx` is the per-scenario TestContext (services,
 * scenario state, cleanup registry) - the same object cucumber-js gets from its World.
 */
export const test = base.extend<{ ctx: TestContext }>({
  ctx: async ({ playwright }, use, testInfo) => {
    const ctx = await TestContext.create(playwright.request);

    await use(ctx);

    // Attach the last exchange (whole conversation on failure) to the Playwright / Cucumber report.
    const failed = testInfo.status !== testInfo.expectedStatus;
    const history = failed ? ctx.client.history : ctx.client.history.slice(-1);
    for (const [index, exchange] of history.entries()) {
      await testInfo.attach(`api-${index + 1}-${exchange.method}-${exchange.status}`, {
        body: exchange.toAttachment(),
        contentType: 'application/json',
      });
    }
    await ctx.dispose();
  },
});

export const { Given, When, Then } = createBdd(test);
