import * as path from 'path';
import { expect } from '@playwright/test';
import { PetBuilder } from '../builders/PetBuilder';
import { Config } from '../config/Config';
import { TestContext } from '../core/TestContext';
import { DataProviderFactory } from '../data/DataProviderFactory';
import { Pet } from '../models/Pet';
import { RetryUtil } from '../utils/RetryUtil';

function requirePet(ctx: TestContext): Pet & { id: number } {
  const pet = ctx.state.pet;
  if (!pet?.id) throw new Error('No pet in scenario state - add or create one first.');
  return pet as Pet & { id: number };
}

function splitCsv(csv: string): string[] {
  return csv
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

/** Business-level actions for the `pet` tag. Step definitions call these; they call the services. */
export class PetFlow {
  static async createPet(ctx: TestContext, name: string, status: string): Promise<void> {
    await PetFlow.submit(ctx, PetBuilder.aPet().withName(name).withStatus(status).build());
  }

  static async createPetFromDataSource(ctx: TestContext, key: string, source: string): Promise<void> {
    await PetFlow.submit(ctx, await DataProviderFactory.create(source).getPet(key));
  }

  /** Precondition helper: creates the pet and fails fast if the API did not accept it. */
  static async ensurePetExists(ctx: TestContext, name: string, status: string): Promise<void> {
    await PetFlow.createPet(ctx, name, status);
    expect(ctx.result.status, `Precondition failed: ${ctx.result.rawBody}`).toBe(200);
  }

  static async getCurrentPet(ctx: TestContext): Promise<void> {
    const { id } = requirePet(ctx);
    ctx.record(await RetryUtil.pollUntil(() => ctx.services.pet.getPetById(id), (r) => r.status === 200));
  }

  static async getPetById(ctx: TestContext, id: number): Promise<void> {
    ctx.record(await ctx.services.pet.getPetById(id));
  }

  static async updatePet(ctx: TestContext, name: string, status: string): Promise<void> {
    const updated: Pet = { ...requirePet(ctx), name, status };
    const result = ctx.record(await ctx.services.pet.updatePet(updated));
    if (result.status === 200) ctx.state.pet = updated;
  }

  static async updatePetViaForm(ctx: TestContext, name: string, status: string): Promise<void> {
    const pet = requirePet(ctx);
    const result = ctx.record(await ctx.services.pet.updatePetWithForm(pet.id, { name, status }));
    if (result.status === 200) ctx.state.pet = { ...pet, name, status };
  }

  static async findByStatus(ctx: TestContext, statusesCsv: string): Promise<void> {
    ctx.record(await ctx.services.pet.findByStatus(splitCsv(statusesCsv)));
  }

  static async findByTags(ctx: TestContext, tagsCsv: string): Promise<void> {
    ctx.record(await ctx.services.pet.findByTags(splitCsv(tagsCsv)));
  }

  static async deleteCurrentPet(ctx: TestContext): Promise<void> {
    ctx.record(await ctx.services.pet.deletePet(requirePet(ctx).id));
  }

  static async deletePetById(ctx: TestContext, id: number): Promise<void> {
    ctx.record(await ctx.services.pet.deletePet(id));
  }

  static async uploadImage(ctx: TestContext, fileName: string, metadata: string): Promise<void> {
    const file = path.join(Config.get().paths.testData, 'files', fileName);
    ctx.record(await ctx.services.pet.uploadImage(requirePet(ctx).id, file, metadata));
  }

  static async createPetWithMalformedBody(ctx: TestContext): Promise<void> {
    ctx.record(await ctx.services.pet.addPetRaw('{ "id": 1, "name": '));
  }

  static async assertPetIsGone(ctx: TestContext): Promise<void> {
    const { id } = requirePet(ctx);
    ctx.record(await RetryUtil.pollUntil(() => ctx.services.pet.getPetById(id), (r) => r.status === 404));
    expect(ctx.result.status, `Pet ${id} should have been deleted`).toBe(404);
  }

  static assertResponseMatchesSubmittedPet(ctx: TestContext): void {
    const submitted = requirePet(ctx);
    const actual = ctx.body<Pet>();
    expect(actual.id, 'id').toBe(submitted.id);
    expect(actual.name, 'name').toBe(submitted.name);
    expect(actual.status, 'status').toBe(submitted.status);
    expect(actual.photoUrls, 'photoUrls').toEqual(submitted.photoUrls);
  }

  static assertEveryPetHasStatus(ctx: TestContext, statusesCsv: string): void {
    const allowed = splitCsv(statusesCsv);
    const pets = ctx.body<Pet[]>();
    expect(Array.isArray(pets), 'response should be an array').toBe(true);
    const unexpected = pets.filter((pet) => !allowed.includes(String(pet.status)));
    expect(unexpected.map((pet) => `${pet.id}:${pet.status}`), `pets outside [${allowed}]`).toEqual([]);
  }

  static assertMessageIsPetId(ctx: TestContext): void {
    expect(String(ctx.body().message)).toBe(String(requirePet(ctx).id));
  }

  private static async submit(ctx: TestContext, pet: Pet): Promise<void> {
    ctx.state.pet = pet;
    const result = ctx.record(await ctx.services.pet.addPet(pet));
    if (result.status === 200 && pet.id !== undefined) {
      const id = pet.id;
      ctx.registerCleanup(() => ctx.services.pet.deletePet(id));
    }
  }
}
