import { expect } from '@playwright/test';
import { OrderBuilder } from '../builders/OrderBuilder';
import { TestContext } from '../core/TestContext';
import { DataProviderFactory } from '../data/DataProviderFactory';
import { Order } from '../models/Order';
import { RandomUtil } from '../utils/RandomUtil';
import { RetryUtil } from '../utils/RetryUtil';

function requireOrder(ctx: TestContext): Order & { id: number } {
  const order = ctx.state.order;
  if (!order?.id) throw new Error('No order in scenario state - place one first.');
  return order as Order & { id: number };
}

/** Business-level actions for the `store` tag. */
export class StoreFlow {
  static async getInventory(ctx: TestContext): Promise<void> {
    ctx.record(await ctx.services.store.getInventory());
  }

  /** Orders the pet created earlier in the scenario (or a random pet id when there is none). */
  static async placeOrder(ctx: TestContext, quantity: number): Promise<void> {
    const order = OrderBuilder.anOrder()
      .forPet(ctx.state.pet?.id ?? RandomUtil.id())
      .withQuantity(quantity)
      .build();
    await StoreFlow.submit(ctx, order);
  }

  static async placeOrderFromDataSource(ctx: TestContext, key: string, source: string): Promise<void> {
    await StoreFlow.submit(ctx, await DataProviderFactory.create(source).getOrder(key));
  }

  static async ensureOrderExists(ctx: TestContext, quantity: number): Promise<void> {
    await StoreFlow.placeOrder(ctx, quantity);
    expect(ctx.result.status, `Precondition failed: ${ctx.result.rawBody}`).toBe(200);
  }

  static async getCurrentOrder(ctx: TestContext): Promise<void> {
    const { id } = requireOrder(ctx);
    ctx.record(await RetryUtil.pollUntil(() => ctx.services.store.getOrderById(id), (r) => r.status === 200));
  }

  static async getOrderById(ctx: TestContext, id: number): Promise<void> {
    ctx.record(await ctx.services.store.getOrderById(id));
  }

  static async deleteCurrentOrder(ctx: TestContext): Promise<void> {
    ctx.record(await ctx.services.store.deleteOrder(requireOrder(ctx).id));
  }

  static async deleteOrderById(ctx: TestContext, id: number): Promise<void> {
    ctx.record(await ctx.services.store.deleteOrder(id));
  }

  static async assertOrderIsGone(ctx: TestContext): Promise<void> {
    const { id } = requireOrder(ctx);
    ctx.record(await RetryUtil.pollUntil(() => ctx.services.store.getOrderById(id), (r) => r.status === 404));
    expect(ctx.result.status, `Order ${id} should have been deleted`).toBe(404);
  }

  static assertResponseMatchesSubmittedOrder(ctx: TestContext): void {
    const submitted = requireOrder(ctx);
    const actual = ctx.body<Order>();
    expect(actual.id, 'id').toBe(submitted.id);
    expect(actual.petId, 'petId').toBe(submitted.petId);
    expect(actual.quantity, 'quantity').toBe(submitted.quantity);
    expect(actual.status, 'status').toBe(submitted.status);
  }

  static assertMessageIsOrderId(ctx: TestContext): void {
    expect(String(ctx.body().message)).toBe(String(requireOrder(ctx).id));
  }

  private static async submit(ctx: TestContext, order: Order): Promise<void> {
    ctx.state.order = order;
    const result = ctx.record(await ctx.services.store.placeOrder(order));
    if (result.status === 200 && order.id !== undefined) {
      const id = order.id;
      ctx.registerCleanup(() => ctx.services.store.deleteOrder(id));
    }
  }
}
