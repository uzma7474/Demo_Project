import { expect } from '@playwright/test';
import { UserBuilder } from '../builders/UserBuilder';
import { TestContext } from '../core/TestContext';
import { DataProviderFactory } from '../data/DataProviderFactory';
import { User } from '../models/User';
import { RandomUtil } from '../utils/RandomUtil';
import { RetryUtil } from '../utils/RetryUtil';

function requireUser(ctx: TestContext): User & { username: string } {
  const user = ctx.state.user;
  if (!user?.username) throw new Error('No user in scenario state - create one first.');
  return user as User & { username: string };
}

function splitCsv(csv: string): string[] {
  return csv
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

/** Business-level actions for the `user` tag. */
export class UserFlow {
  /** Usernames get a random suffix so repeated and parallel runs never collide on the shared server. */
  static async createUser(ctx: TestContext, username: string): Promise<void> {
    await UserFlow.submit(ctx, UserBuilder.aUser().withUsername(RandomUtil.string(username)).build());
  }

  static async ensureUserExists(ctx: TestContext, username: string): Promise<void> {
    await UserFlow.createUser(ctx, username);
    expect(ctx.result.status, `Precondition failed: ${ctx.result.rawBody}`).toBe(200);
  }

  static async createUserFromDataSource(ctx: TestContext, key: string, source: string): Promise<void> {
    await UserFlow.submit(ctx, await DataProviderFactory.create(source).getUser(key));
  }

  static async createUsersWithArray(ctx: TestContext, usernamesCsv: string): Promise<void> {
    const users = UserFlow.buildUsers(usernamesCsv);
    ctx.state.users = users;
    ctx.record(await ctx.services.user.createWithArray(users));
    UserFlow.registerCleanups(ctx, users);
  }

  static async createUsersWithList(ctx: TestContext, usernamesCsv: string): Promise<void> {
    const users = UserFlow.buildUsers(usernamesCsv);
    ctx.state.users = users;
    ctx.record(await ctx.services.user.createWithList(users));
    UserFlow.registerCleanups(ctx, users);
  }

  static async assertEachCreatedUserIsRetrievable(ctx: TestContext): Promise<void> {
    const users = ctx.state.users ?? [];
    expect(users.length, 'no bulk-created users in scenario state').toBeGreaterThan(0);
    for (const user of users) {
      const username = user.username as string;
      const result = await RetryUtil.pollUntil(() => ctx.services.user.getUser(username), (r) => r.status === 200);
      ctx.record(result);
      expect(result.status, `User ${username} should exist`).toBe(200);
    }
  }

  static async getCurrentUser(ctx: TestContext): Promise<void> {
    const { username } = requireUser(ctx);
    ctx.record(await RetryUtil.pollUntil(() => ctx.services.user.getUser(username), (r) => r.status === 200));
  }

  static async getUserByUsername(ctx: TestContext, username: string): Promise<void> {
    ctx.record(await ctx.services.user.getUser(username));
  }

  static async updateEmail(ctx: TestContext, email: string): Promise<void> {
    const user = requireUser(ctx);
    const updated: User = { ...user, email };
    const result = ctx.record(await ctx.services.user.updateUser(user.username, updated));
    if (result.status === 200) ctx.state.user = updated;
  }

  static async deleteCurrentUser(ctx: TestContext): Promise<void> {
    ctx.record(await ctx.services.user.deleteUser(requireUser(ctx).username));
  }

  static async deleteUserByUsername(ctx: TestContext, username: string): Promise<void> {
    ctx.record(await ctx.services.user.deleteUser(username));
  }

  static async loginWithCurrentUser(ctx: TestContext): Promise<void> {
    const user = requireUser(ctx);
    ctx.record(await ctx.services.user.login(user.username, user.password ?? ''));
  }

  static async login(ctx: TestContext, username: string, password: string): Promise<void> {
    ctx.record(await ctx.services.user.login(username, password));
  }

  static async logout(ctx: TestContext): Promise<void> {
    ctx.record(await ctx.services.user.logout());
  }

  static async assertUserIsGone(ctx: TestContext): Promise<void> {
    const { username } = requireUser(ctx);
    ctx.record(await RetryUtil.pollUntil(() => ctx.services.user.getUser(username), (r) => r.status === 404));
    expect(ctx.result.status, `User ${username} should have been deleted`).toBe(404);
  }

  static assertResponseMatchesSubmittedUser(ctx: TestContext): void {
    const submitted = requireUser(ctx);
    const actual = ctx.body<User>();
    expect(actual.username, 'username').toBe(submitted.username);
    expect(actual.firstName, 'firstName').toBe(submitted.firstName);
    expect(actual.lastName, 'lastName').toBe(submitted.lastName);
    expect(actual.email, 'email').toBe(submitted.email);
  }

  static assertMessageIsUserId(ctx: TestContext): void {
    expect(String(ctx.body().message)).toBe(String(ctx.state.user?.id));
  }

  static assertMessageIsUsername(ctx: TestContext): void {
    expect(String(ctx.body().message)).toBe(requireUser(ctx).username);
  }

  static assertLoginSession(ctx: TestContext): void {
    expect(String(ctx.body().message)).toContain('logged in user session');
  }

  private static buildUsers(usernamesCsv: string): User[] {
    return splitCsv(usernamesCsv).map((name) => UserBuilder.aUser().withUsername(RandomUtil.string(name)).build());
  }

  private static registerCleanups(ctx: TestContext, users: User[]): void {
    if (ctx.result.status !== 200) return;
    users.forEach((user) => ctx.registerCleanup(() => ctx.services.user.deleteUser(user.username as string)));
  }

  private static async submit(ctx: TestContext, user: User): Promise<void> {
    ctx.state.user = user;
    const result = ctx.record(await ctx.services.user.createUser(user));
    if (result.status === 200 && user.username) {
      const username = user.username;
      ctx.registerCleanup(() => ctx.services.user.deleteUser(username));
    }
  }
}
