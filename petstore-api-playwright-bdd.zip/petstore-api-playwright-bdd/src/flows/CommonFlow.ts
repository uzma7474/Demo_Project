import { expect } from '@playwright/test';
import { SchemaValidator } from '../utils/SchemaValidator';
import { JsonReader } from '../utils/JsonReader';
import { TestContext } from '../core/TestContext';

/** Generic response assertions shared by every feature. */
export class CommonFlow {
  static async assertApiIsAvailable(ctx: TestContext): Promise<void> {
    const result = ctx.record(await ctx.services.store.getInventory());
    expect(result.status, `Petstore should be reachable (${result.summary()})`).toBe(200);
  }

  static assertStatus(ctx: TestContext, expected: number): void {
    expect(ctx.result.status, `${ctx.result.summary()}\n${ctx.result.rawBody}`).toBe(expected);
  }

  static assertStatusOneOf(ctx: TestContext, allowedCsv: string): void {
    const allowed = allowedCsv.split(',').map((value) => Number(value.trim()));
    expect(allowed, `${ctx.result.summary()}\n${ctx.result.rawBody}`).toContain(ctx.result.status);
  }

  static assertBodyField(ctx: TestContext, path: string, expected: string): void {
    const actual = JsonReader.getByPath(ctx.body(), path);
    expect(String(actual), `Body field "${path}" in ${ctx.result.rawBody}`).toBe(expected);
  }

  static assertBodyFieldExists(ctx: TestContext, path: string): void {
    const actual = JsonReader.getByPath(ctx.body(), path);
    expect(actual, `Body field "${path}" should exist in ${ctx.result.rawBody}`).not.toBeUndefined();
  }

  static assertMessageContains(ctx: TestContext, text: string): void {
    const message = JsonReader.getByPath(ctx.body(), 'message');
    expect(String(message)).toContain(text);
  }

  static assertJsonArray(ctx: TestContext): void {
    expect(Array.isArray(ctx.body()), `Expected a JSON array but got: ${ctx.result.rawBody.slice(0, 200)}`).toBe(true);
  }

  static assertHeaderExists(ctx: TestContext, name: string): void {
    expect(ctx.result.header(name), `Header "${name}" should be present`).toBeDefined();
  }

  static assertResponseTime(ctx: TestContext, maxMs: number): void {
    expect(ctx.result.durationMs, ctx.result.summary()).toBeLessThan(maxMs);
  }

  static assertSchema(ctx: TestContext, schemaName: string): void {
    const errors = SchemaValidator.validate(ctx.body(), SchemaValidator.load(schemaName));
    expect(errors, `Schema "${schemaName}" violations`).toEqual([]);
  }
}
