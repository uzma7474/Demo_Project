import { APIRequest, APIRequestContext } from '@playwright/test';
import { ServiceFactory, Services } from '../factories/ServiceFactory';
import { Order } from '../models/Order';
import { Pet } from '../models/Pet';
import { User } from '../models/User';
import { ApiClient } from './ApiClient';
import { ApiResult } from './ApiResult';
import { Logger } from './Logger';
import { RequestContextFactory } from './RequestContextFactory';

/** Data shared between the steps of ONE scenario. */
export interface ScenarioState {
  lastResult?: ApiResult;
  pet?: Pet;
  order?: Order;
  user?: User;
  users?: User[];
}

/**
 * Per-scenario container: services + scenario state + cleanup registry.
 * cucumber-js exposes it through the World, playwright-bdd through a fixture,
 * so flows and services are identical in both frameworks.
 */
export class TestContext {
  readonly state: ScenarioState = {};
  readonly services: Services;

  private readonly cleanups: Array<() => Promise<unknown>> = [];

  constructor(
    readonly client: ApiClient,
    private readonly requestContext: APIRequestContext,
  ) {
    this.services = ServiceFactory.create(client);
  }

  static async create(api: APIRequest): Promise<TestContext> {
    const requestContext = await RequestContextFactory.create(api);
    return new TestContext(new ApiClient(requestContext), requestContext);
  }

  /** The response of the most recent API call. */
  get result(): ApiResult {
    if (!this.state.lastResult) {
      throw new Error('No API call has been made yet in this scenario.');
    }
    return this.state.lastResult;
  }

  /** Parsed JSON body of the most recent response (fails with a clear message if it is not JSON). */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  body<T = any>(): T {
    const body = this.result.json<T>();
    if (body === undefined) {
      throw new Error(`Response body is not JSON: ${this.result.summary()}\n${this.result.rawBody}`);
    }
    return body;
  }

  /** Stores a result as "the last response" and returns it. */
  record(result: ApiResult): ApiResult {
    this.state.lastResult = result;
    return result;
  }

  /** Registers a best-effort cleanup (runs in reverse order after the scenario). */
  registerCleanup(action: () => Promise<unknown>): void {
    this.cleanups.push(action);
  }

  async dispose(): Promise<void> {
    const logger = Logger.get();
    for (const cleanup of this.cleanups.reverse()) {
      try {
        await cleanup();
      } catch (error) {
        logger.warn(`Cleanup failed: ${String(error)}`);
      }
    }
    await this.requestContext.dispose();
  }
}
