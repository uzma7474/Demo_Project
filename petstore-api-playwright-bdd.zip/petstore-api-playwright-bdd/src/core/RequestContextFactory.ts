import { APIRequest, APIRequestContext } from '@playwright/test';
import { Config } from '../config/Config';

/**
 * Creates the Playwright request context used by every ApiClient.
 * Accepts the `APIRequest` entry point so it works with both
 * `import { request } from '@playwright/test'` (cucumber-js) and the
 * `playwright.request` fixture (playwright-bdd).
 */
export class RequestContextFactory {
  static create(api: APIRequest): Promise<APIRequestContext> {
    const config = Config.get();
    return api.newContext({
      baseURL: config.baseUrl,
      // Content-Type is deliberately NOT set globally: Playwright derives it
      // per request (json / form / multipart).
      extraHTTPHeaders: { Accept: 'application/json' },
      timeout: config.timeoutMs,
    });
  }
}
