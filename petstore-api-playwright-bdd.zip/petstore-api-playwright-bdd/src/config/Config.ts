import * as path from 'path';
import * as dotenv from 'dotenv';

dotenv.config();

/** Known environments. Add your own (e.g. a self-hosted Petstore) or override with BASE_URL. */
const ENVIRONMENTS: Record<string, string> = {
  prod: 'https://petstore.swagger.io/v2/',
  local: 'http://localhost:8080/v2/',
};

function toNumber(value: string | undefined, fallback: number): number {
  const parsed = Number(value);
  return value !== undefined && value.trim() !== '' && Number.isFinite(parsed) ? parsed : fallback;
}

/**
 * Singleton configuration. Every value can be overridden through environment
 * variables or a `.env` file (see `.env.example`).
 */
export class Config {
  private static instance: Config | undefined;

  readonly envName: string;
  /** Always ends with a slash - relative request paths must NOT start with one. */
  readonly baseUrl: string;
  readonly apiKey: string;
  readonly timeoutMs: number;
  readonly retryCount: number;
  readonly retryDelayMs: number;
  readonly maxResponseTimeMs: number;
  readonly logLevel: string;
  readonly paths: { root: string; testData: string; logs: string; reports: string };

  private constructor() {
    this.envName = (process.env.ENV ?? 'prod').toLowerCase();
    const configured = process.env.BASE_URL ?? ENVIRONMENTS[this.envName];
    if (!configured) {
      throw new Error(
        `Unknown ENV "${this.envName}". Use one of [${Object.keys(ENVIRONMENTS).join(', ')}] or set BASE_URL.`,
      );
    }
    this.baseUrl = configured.endsWith('/') ? configured : `${configured}/`;
    this.apiKey = process.env.API_KEY ?? 'special-key';
    this.timeoutMs = toNumber(process.env.REQUEST_TIMEOUT_MS, 30_000);
    this.retryCount = toNumber(process.env.RETRY_COUNT, 2);
    this.retryDelayMs = toNumber(process.env.RETRY_DELAY_MS, 500);
    this.maxResponseTimeMs = toNumber(process.env.MAX_RESPONSE_TIME_MS, 10_000);
    this.logLevel = (process.env.LOG_LEVEL ?? 'info').toLowerCase();

    const root = path.resolve(__dirname, '..', '..');
    this.paths = {
      root,
      testData: path.join(root, 'test-data'),
      logs: path.join(root, 'logs'),
      reports: path.join(root, 'reports'),
    };
  }

  static get(): Config {
    Config.instance ??= new Config();
    return Config.instance;
  }
}
