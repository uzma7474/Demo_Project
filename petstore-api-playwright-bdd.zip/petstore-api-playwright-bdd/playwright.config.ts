import { defineConfig } from '@playwright/test';
import { cucumberReporter, defineBddConfig } from 'playwright-bdd';
import { Config } from './src/config/Config';

// bddgen turns every .feature scenario into a Playwright test under .features-gen/
const testDir = defineBddConfig({
  features: 'features/**/*.feature',
  steps: ['src/bdd/fixtures.ts', 'src/bdd/steps/**/*.ts'],
});

// Touching Config here loads .env before the workers start.
Config.get();

export default defineConfig({
  testDir,
  timeout: 60_000,
  expect: { timeout: 10_000 },
  // Scenarios use unique ids and clean up after themselves, so they can run fully in parallel.
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  workers: process.env.CI ? 2 : 4,
  reporter: [
    ['list'],
    ['html', { open: 'never', outputFolder: 'reports/playwright-report' }],
    cucumberReporter('html', { outputFile: 'reports/cucumber-report/report.html' }),
    cucumberReporter('json', { outputFile: 'reports/cucumber-report/report.json' }),
  ],
  // No browser projects: every scenario talks to the API through the `ctx` fixture (src/bdd/fixtures.ts),
  // which builds its request context from the base URL in src/config/Config.ts.
});
