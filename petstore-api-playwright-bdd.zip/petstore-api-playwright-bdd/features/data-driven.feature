@data-driven
Feature: Data-driven API tests (JSON and Excel)
  Test records live in test-data/json/*.json and test-data/excel/petstore-data.xlsx.
  The scenario only names the record; the data source is a strategy chosen per example row.

  Background:
    Given the Petstore API is available

  @regression
  Scenario Outline: Add pets from test data
    When I add the pet "<key>" from the "<source>" data source
    Then the response status code should be 200
    And the response should match the submitted pet

    @json
    Examples: JSON data
      | source | key               |
      | json   | PET_DOG_AVAILABLE |
      | json   | PET_CAT_PENDING   |
      | json   | PET_BIRD_SOLD     |

    @excel
    Examples: Excel data
      | source | key               |
      | excel  | PET_DOG_AVAILABLE |
      | excel  | PET_CAT_PENDING   |
      | excel  | PET_BIRD_SOLD     |

  @regression
  Scenario Outline: Create and read back users from test data
    When I create the user "<key>" from the "<source>" data source
    Then the response status code should be 200
    When I get the user by username
    Then the response status code should be 200
    And the response should match the submitted user

    @json
    Examples: JSON data
      | source | key       |
      | json   | USER_JOHN |
      | json   | USER_JANE |

    @excel
    Examples: Excel data
      | source | key       |
      | excel  | USER_JOHN |
      | excel  | USER_JANE |

  @regression
  Scenario Outline: Place and read back orders from test data
    When I place the order "<key>" from the "<source>" data source
    Then the response status code should be 200
    And the response should match the submitted order
    When I get the order by its id
    Then the response status code should be 200

    @json
    Examples: JSON data
      | source | key             |
      | json   | ORDER_PLACED    |
      | json   | ORDER_DELIVERED |

    @excel
    Examples: Excel data
      | source | key             |
      | excel  | ORDER_PLACED    |
      | excel  | ORDER_DELIVERED |
