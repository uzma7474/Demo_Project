@store
Feature: Store and orders
  As an API consumer
  I want to place and manage orders
  So that customers can buy pets

  Background:
    Given the Petstore API is available

  @smoke @regression
  Scenario: Read the store inventory
    When I request the store inventory
    Then the response status code should be 200
    And the response should match the "inventory" schema

  @smoke @regression
  Scenario: Place an order for a pet
    Given a pet named "Rocky" with status "available" exists
    When I place an order for the pet with quantity 2
    Then the response status code should be 200
    And the response should match the "order" schema
    And the response should match the submitted order

  @regression
  Scenario: Retrieve an order by its id
    Given an order is placed for quantity 1
    When I get the order by its id
    Then the response status code should be 200
    And the response body field "quantity" should equal "1"
    And the response body field "status" should equal "placed"

  @regression
  Scenario: Delete an order
    Given an order is placed for quantity 3
    When I delete the order
    Then the response status code should be 200
    And the response message should be the order id
    And the order should no longer exist

  @negative @regression
  Scenario: Get an order that does not exist
    When I get the order with id 987654321014
    Then the response status code should be 404
    And the response body field "message" should equal "Order not found"

  @negative @regression
  Scenario: Delete an order that does not exist
    When I delete the order with id 987654321015
    Then the response status code should be 404
