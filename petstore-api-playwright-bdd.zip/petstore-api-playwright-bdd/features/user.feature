@user
Feature: User management
  As an API consumer
  I want to manage user accounts
  So that customers can sign up, sign in and maintain their profile

  Background:
    Given the Petstore API is available

  @smoke @regression
  Scenario: Create a user
    When I create a user "john"
    Then the response status code should be 200
    And the response should match the "apiResponse" schema
    And the response message should be the user id

  @smoke @regression
  Scenario: Retrieve a user by username
    Given a user "jane" exists
    When I get the user by username
    Then the response status code should be 200
    And the response should match the "user" schema
    And the response should match the submitted user

  @regression
  Scenario: Update a user
    Given a user "alice" exists
    When I update the user email to "alice.updated@example.com"
    Then the response status code should be 200
    And the response message should be the user id
    When I get the user by username
    Then the response status code should be 200
    And the response body field "email" should equal "alice.updated@example.com"

  @regression
  Scenario: Delete a user
    Given a user "bob" exists
    When I delete the user
    Then the response status code should be 200
    And the response message should be the username
    And the user should no longer exist

  @smoke @regression
  Scenario: Log a user in
    Given a user "carol" exists
    When I login with the created user credentials
    Then the response status code should be 200
    And the response should contain a login session message
    And the response header "x-expires-after" should exist
    And the response header "x-rate-limit" should exist

  @regression
  Scenario: Log a user out
    When I logout
    Then the response status code should be 200
    And the response body field "message" should equal "ok"

  @regression
  Scenario: Create several users with an array
    When I create users with the usernames "dave,erin" using the array endpoint
    Then the response status code should be 200
    And the response body field "message" should equal "ok"
    And each created user should be retrievable

  @regression
  Scenario: Create several users with a list
    When I create users with the usernames "frank,grace" using the list endpoint
    Then the response status code should be 200
    And the response body field "message" should equal "ok"
    And each created user should be retrievable

  @negative @regression
  Scenario: Get a user that does not exist
    When I get the user "no_such_user_987654321"
    Then the response status code should be 404
    And the response body field "message" should equal "User not found"

  @negative @regression
  Scenario: Delete a user that does not exist
    When I delete the user "no_such_user_987654322"
    Then the response status code should be 404
