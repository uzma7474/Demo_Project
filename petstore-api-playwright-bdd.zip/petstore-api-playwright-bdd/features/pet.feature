@pet
Feature: Pet management
  As an API consumer
  I want to manage pets in the Petstore
  So that the store catalogue stays accurate

  Background:
    Given the Petstore API is available

  @smoke @regression
  Scenario: Add a new pet to the store
    When I add a pet named "Rex" with status "available"
    Then the response status code should be 200
    And the response should match the "pet" schema
    And the response should match the submitted pet
    And the response time should be under 10000 ms

  @smoke @regression
  Scenario: Retrieve a pet by its id
    Given a pet named "Bella" with status "available" exists
    When I get the pet by its id
    Then the response status code should be 200
    And the response body field "name" should equal "Bella"
    And the response body field "status" should equal "available"

  @regression
  Scenario: Update an existing pet with PUT
    Given a pet named "Max" with status "available" exists
    When I update the pet name to "Max Updated" and status to "sold"
    Then the response status code should be 200
    And the response body field "name" should equal "Max Updated"
    And the response body field "status" should equal "sold"

  @regression
  Scenario: Update a pet using form data
    Given a pet named "Charlie" with status "available" exists
    When I update the pet with form data name "Charlie Form" and status "pending"
    Then the response status code should be 200
    And the response should match the "apiResponse" schema
    And the response message should be the pet id

  @regression
  Scenario Outline: Find pets by status
    When I find pets by status "<status>"
    Then the response status code should be 200
    And the response should match the "pets" schema
    And every pet in the response should have one of the statuses "<status>"

    Examples:
      | status            |
      | available         |
      | pending           |
      | sold              |
      | available,pending |

  @regression
  Scenario: Find pets by tags
    When I find pets by tags "automation"
    Then the response status code should be 200
    And the response should be a JSON array

  @smoke @regression
  Scenario: Delete a pet
    Given a pet named "Luna" with status "available" exists
    When I delete the pet
    Then the response status code should be 200
    And the response message should be the pet id
    And the pet should no longer exist

  @regression
  Scenario: Upload an image for a pet
    Given a pet named "Daisy" with status "available" exists
    When I upload the image "sample-pet.png" for the pet with metadata "profile photo"
    Then the response status code should be 200
    And the response should match the "apiResponse" schema
    And the response message should contain "profile photo"

  @negative @regression
  Scenario: Get a pet that does not exist
    When I get the pet with id 987654321012
    Then the response status code should be 404
    And the response body field "message" should equal "Pet not found"

  @negative @regression
  Scenario: Delete a pet that does not exist
    When I delete the pet with id 987654321013
    Then the response status code should be 404

  @negative @regression
  Scenario: Add a pet with a malformed JSON body
    When I add a pet with a malformed JSON body
    Then the response status code should be one of "400,405,500"
