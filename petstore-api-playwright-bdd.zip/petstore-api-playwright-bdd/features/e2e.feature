@e2e
Feature: Pet purchase journey (end to end)
  A customer signs in, buys an available pet and the shop closes the sale.

  Background:
    Given the Petstore API is available

  @smoke @regression
  Scenario: Customer buys a pet
    Given a user "customer" exists
    When I login with the created user credentials
    Then the response status code should be 200
    Given a pet named "Goldie" with status "available" exists
    When I place an order for the pet with quantity 1
    Then the response status code should be 200
    And the response should match the submitted order
    When I get the order by its id
    Then the response status code should be 200
    When I update the pet name to "Goldie" and status to "sold"
    Then the response status code should be 200
    And the response body field "status" should equal "sold"
    When I delete the order
    Then the response status code should be 200
    When I delete the pet
    Then the response status code should be 200
    When I logout
    Then the response status code should be 200
