# Restful Booker API Automation Framework

REST Assured + Cucumber (BDD) + TestNG, Java 17, Maven. Covers every endpoint of
https://restful-booker.herokuapp.com/apidoc/index.html

| Group   | Endpoint                | Covered by feature            |
|---------|-------------------------|-------------------------------|
| Auth    | POST /auth              | auth.feature                  |
| Booking | GET /booking (+filters) | get_bookings.feature          |
| Booking | GET /booking/{id}       | get_bookings.feature          |
| Booking | POST /booking           | create_booking.feature        |
| Booking | PUT /booking/{id}       | update_booking.feature        |
| Booking | PATCH /booking/{id}     | partial_update_booking.feature|
| Booking | DELETE /booking/{id}    | delete_booking.feature        |
| Ping    | GET /ping               | ping.feature                  |

## Architecture
```
config/ConfigManager      layered config: -D flag > config/<env>.properties > config.properties
specs/RequestSpecFactory  base URI, JSON headers, timeouts, logging filter; token-cookie / basic-auth specs
api/*Api                  one thin class per resource (AuthApi, BookingApi, PingApi) - return Response
api/TokenManager          thread-safe cached admin token
pojo/                     Java records (Booking, BookingDates, BookingResponse, AuthRequest)
builders/                 payloads: random (DataFaker), from Excel row, partial (PATCH)
utils/ExcelUtils          read sheet -> List<Map>, lookup by testCaseId, write sheet (Apache POI)
utils/JsonUtils           classpath JSON <-> POJO (Jackson)
utils/ApiLoggingFilter    logs every call to Log4j2 + attaches transcript to the report (token/password masked)
context/ScenarioContext   per-scenario state, injected by PicoContainer (parallel-safe)
stepdefinitions/, hooks/  glue code; Hooks sets log context, cleans up created bookings, attaches HTTP logs
```

## Run
```
mvn clean test                                   # everything
mvn clean test -Dcucumber.filter.tags="@smoke"   # by tag: @smoke @regression @negative @excel-data @json-data
mvn clean test -Dthreads=4                       # parallel scenarios
mvn clean test -Denv=qa -Dbase.uri=https://...   # other environment
```

## Outputs
* Extent Spark report: `target/reports/extent/ExtentSpark.html` (HTTP transcripts attached per scenario)
* Cucumber HTML / JSON: `target/reports/cucumber/`
* Logs: `logs/automation.log` (rolling, scenario name in every line)

## Test data
* Excel: `src/test/resources/testdata/bookings.xlsx`, sheet `CreateBooking` (row key = `testCaseId`)
* JSON:  `src/test/resources/testdata/bookings.json`
* Schemas: `src/test/resources/schemas/`

## Known API quirks encoded in the tests
* Bad credentials return **200** with `{"reason":"Bad credentials"}` (not 401).
* DELETE success returns **201** `Created`; DELETE/PUT on a missing id returns **405**.
* PUT/PATCH/DELETE without a valid token or basic auth return **403**.
* Missing mandatory fields on POST return **500**; the malformed-JSON case expects **400**.
  If the live service behaves differently, adjust the expected codes in `create_booking.feature`.
* The service is a shared public sandbox: tests create their own data and delete it in the `@After` hook.
