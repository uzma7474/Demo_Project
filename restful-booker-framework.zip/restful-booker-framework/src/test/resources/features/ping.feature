@ping @smoke
Feature: Health check (GET /ping)

  Scenario: API is up and responding
    When I call the health check endpoint
    Then the response status code should be 201
    And the response body should be "Created"
