@booking @read
Feature: Retrieve bookings (GET /booking, GET /booking/{id})

  @smoke
  Scenario: Get all booking ids
    When I get all booking ids
    Then the response status code should be 200
    And the booking ids list should be a non-empty list
    And the response should match JSON schema "booking-ids-schema.json"

  @regression
  Scenario Outline: Filter booking ids by <field>
    Given a booking exists
    When I get booking ids filtered by the <field> of the created booking
    Then the response status code should be 200
    And the booking ids list should contain the created booking id

    Examples:
      | field     |
      | firstname |
      | lastname  |
      | checkin   |
      | checkout  |

  @regression
  Scenario: Filter booking ids by firstname and lastname
    Given a booking exists
    When I get booking ids filtered by the created booking's firstname and lastname
    Then the response status code should be 200
    And the booking ids list should contain the created booking id

  @regression
  Scenario: Filter with a name that matches nothing returns an empty list
    When I get booking ids filtered by firstname "Zzzqxyw" and lastname "Nonexistentqq"
    Then the response status code should be 200
    And the booking ids list should be empty

  @smoke
  Scenario: Get a booking by id
    Given a booking exists
    When I get the booking by its id
    Then the response status code should be 200
    And the response booking should match the request data
    And the response should match JSON schema "booking-schema.json"

  @negative
  Scenario: Get a booking that does not exist
    When I get the booking with id 999999999
    Then the response status code should be 404
