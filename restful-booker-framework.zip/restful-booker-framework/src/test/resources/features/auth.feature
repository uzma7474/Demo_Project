@auth
Feature: Authentication (POST /auth)

  @smoke
  Scenario: Generate a token with valid credentials
    When I request an auth token with valid admin credentials
    Then the response status code should be 200
    And the response should contain a non-empty token
    And the response should match JSON schema "auth-token-schema.json"

  @negative
  Scenario Outline: Token is not issued for invalid credentials - <description>
    When I request an auth token with username "<username>" and password "<password>"
    Then the response status code should be 200
    And the response should contain the reason "Bad credentials"
    And the response should not contain a token

    Examples:
      | description       | username | password    |
      | wrong password    | admin    | wrongpass   |
      | wrong username    | notadmin | password123 |
      | both wrong        | foo      | bar         |
      | empty credentials |          |             |
