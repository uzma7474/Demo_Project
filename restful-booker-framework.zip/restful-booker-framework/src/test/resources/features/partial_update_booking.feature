@booking @partial-update
Feature: Partial update booking (PATCH /booking/{id})

  @smoke
  Scenario: Partially update firstname and lastname with a token
    Given a booking exists
    When I partially update the booking firstname to "James" and lastname to "Brown" using a valid token
    Then the response status code should be 200
    And the booking firstname should be "James" and lastname should be "Brown"
    And the other booking fields should be unchanged

  @negative
  Scenario: Partial update is rejected without authentication
    Given a booking exists
    When I partially update the booking firstname to "Hacker" without authentication
    Then the response status code should be 403
