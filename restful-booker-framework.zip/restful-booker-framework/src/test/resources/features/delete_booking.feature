@booking @delete
Feature: Delete booking (DELETE /booking/{id})

  @smoke
  Scenario: Delete a booking with a token
    Given a booking exists
    When I delete the booking using a valid token
    Then the response status code should be 201
    And the response body should be "Created"
    And the booking should no longer exist

  @regression
  Scenario: Delete a booking with basic auth
    Given a booking exists
    When I delete the booking using basic auth
    Then the response status code should be 201
    And the booking should no longer exist

  @negative
  Scenario: Delete is rejected without authentication
    Given a booking exists
    When I delete the booking without authentication
    Then the response status code should be 403

  @negative
  Scenario: Delete of a non-existent booking
    When I delete the non-existent booking 999999999 using a valid token
    Then the response status code should be 405
