@booking @create
Feature: Create booking (POST /booking)

  @smoke
  Scenario: Create a booking with random data
    When I create a booking with random data
    Then the response status code should be 200
    And the created booking id should be returned
    And the response booking should match the request data
    And the response should match JSON schema "create-booking-response-schema.json"

  @regression @json-data
  Scenario Outline: Create a booking from JSON test data - <key>
    When I create a booking from JSON test data "<key>"
    Then the response status code should be 200
    And the response booking should match the request data

    Examples:
      | key             |
      | standardBooking |
      | noDeposit       |

  @regression @excel-data
  Scenario Outline: Create a booking from Excel test data - <testCaseId>
    When I create a booking from Excel row "<testCaseId>" of sheet "CreateBooking"
    Then the response status code should be 200
    And the response booking should match the request data

    Examples:
      | testCaseId |
      | TC01       |
      | TC02       |
      | TC03       |

  @negative
  Scenario: Create a booking with a malformed JSON body
    When I create a booking with the raw payload:
      """
      { "firstname": "Broken", "lastname": 
      """
    Then the response status code should be 400

  @negative
  Scenario: Create a booking with missing mandatory fields
    When I create a booking with the raw payload:
      """
      { "firstname": "OnlyFirst" }
      """
    Then the response status code should be 500
