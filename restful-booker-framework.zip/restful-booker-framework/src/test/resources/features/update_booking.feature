@booking @update
Feature: Update booking (PUT /booking/{id})

  @smoke
  Scenario: Fully update a booking with a token
    Given a booking exists
    When I update the booking with new data using a valid token
    Then the response status code should be 200
    And the response booking should match the request data
    And the response should match JSON schema "booking-schema.json"

  @regression
  Scenario: Fully update a booking with basic auth
    Given a booking exists
    When I update the booking with new data using basic auth
    Then the response status code should be 200
    And the response booking should match the request data

  @negative
  Scenario: Update is rejected without authentication
    Given a booking exists
    When I update the booking with new data without authentication
    Then the response status code should be 403

  @negative
  Scenario: Update is rejected with an invalid token
    Given a booking exists
    When I update the booking with new data using an invalid token
    Then the response status code should be 403

  @negative
  Scenario: Update of a non-existent booking
    When I update the non-existent booking 999999999 with new data using a valid token
    Then the response status code should be 405
