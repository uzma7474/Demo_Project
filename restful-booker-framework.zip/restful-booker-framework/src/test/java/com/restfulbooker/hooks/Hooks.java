package com.restfulbooker.hooks;

import com.restfulbooker.api.BookingApi;
import com.restfulbooker.api.TokenManager;
import com.restfulbooker.context.ScenarioContext;
import com.restfulbooker.utils.ApiCallRecorder;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

public class Hooks {

    private static final Logger LOG = LogManager.getLogger(Hooks.class);
    private final ScenarioContext context;

    public Hooks(ScenarioContext context) {
        this.context = context;
    }

    @Before(order = 0)
    public void start(Scenario scenario) {
        ThreadContext.put("scenario", scenario.getName());
        ApiCallRecorder.drain();
        LOG.info("=== START: {} {} ===", scenario.getName(), scenario.getSourceTagNames());
    }

    /** Deletes any booking the scenario created (keeps the shared environment tidy). */
    @After(order = 10)
    public void cleanup() {
        if (context.getBookingId() != null) {
            int status = new BookingApi().deleteBooking(context.getBookingId(), TokenManager.getToken()).statusCode();
            LOG.info("Cleanup of booking {} returned {}", context.getBookingId(), status);
        }
    }

    @After(order = 0)
    public void finish(Scenario scenario) {
        // Attach the HTTP transcript to the report (visible in Extent + Cucumber HTML)
        ApiCallRecorder.drain().forEach(scenario::log);
        LOG.info("=== END: {} -> {} ===", scenario.getName(), scenario.getStatus());
        ThreadContext.clearAll();
    }
}
