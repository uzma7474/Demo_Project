package com.restfulbooker.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"com.restfulbooker.stepdefinitions", "com.restfulbooker.hooks"},
        plugin = {
                "pretty",
                "html:target/reports/cucumber/cucumber.html",
                "json:target/reports/cucumber/cucumber.json",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        monochrome = true
)
public class TestRunner extends AbstractTestNGCucumberTests {

    /** Scenarios run in parallel when -Dthreads=N (N > 1). Scenario state is isolated via PicoContainer. */
    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
