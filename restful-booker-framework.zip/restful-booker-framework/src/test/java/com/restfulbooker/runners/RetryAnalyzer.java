package com.restfulbooker.runners;

import com.restfulbooker.config.ConfigManager;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

/** Re-runs a failed scenario up to retry.count times (useful for Heroku cold starts). */
public class RetryAnalyzer implements IRetryAnalyzer {
    private int attempt = 0;

    @Override
    public boolean retry(ITestResult result) {
        return attempt++ < ConfigManager.getInt("retry.count");
    }
}
