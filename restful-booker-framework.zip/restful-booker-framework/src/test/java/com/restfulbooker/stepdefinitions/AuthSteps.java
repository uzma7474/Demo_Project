package com.restfulbooker.stepdefinitions;

import com.restfulbooker.api.AuthApi;
import com.restfulbooker.config.ConfigManager;
import com.restfulbooker.context.ScenarioContext;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.assertj.core.api.Assertions.assertThat;

public class AuthSteps {

    private final ScenarioContext ctx;
    private final AuthApi authApi = new AuthApi();

    public AuthSteps(ScenarioContext ctx) {
        this.ctx = ctx;
    }

    @When("I request an auth token with valid admin credentials")
    public void validCredentials() {
        ctx.setResponse(authApi.createToken(ConfigManager.username(), ConfigManager.password()));
    }

    @When("I request an auth token with username {string} and password {string}")
    public void credentials(String user, String pass) {
        ctx.setResponse(authApi.createToken(user, pass));
    }

    @Then("the response should contain a non-empty token")
    public void tokenPresent() {
        assertThat(ctx.getResponse().jsonPath().getString("token")).isNotBlank();
    }

    @Then("the response should contain the reason {string}")
    public void reason(String expected) {
        assertThat(ctx.getResponse().jsonPath().getString("reason")).isEqualTo(expected);
    }

    @Then("the response should not contain a token")
    public void noToken() {
        assertThat(ctx.getResponse().jsonPath().getString("token")).isNull();
    }
}
