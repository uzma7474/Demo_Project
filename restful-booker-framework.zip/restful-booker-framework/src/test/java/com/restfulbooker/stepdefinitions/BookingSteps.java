package com.restfulbooker.stepdefinitions;

import com.fasterxml.jackson.core.type.TypeReference;
import com.restfulbooker.api.BookingApi;
import com.restfulbooker.api.TokenManager;
import com.restfulbooker.builders.BookingPayloadBuilder;
import com.restfulbooker.config.ConfigManager;
import com.restfulbooker.context.ScenarioContext;
import com.restfulbooker.pojo.Booking;
import com.restfulbooker.pojo.BookingResponse;
import com.restfulbooker.utils.ExcelUtils;
import com.restfulbooker.utils.JsonUtils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class BookingSteps {

    private final ScenarioContext ctx;
    private final BookingApi api = new BookingApi();

    public BookingSteps(ScenarioContext ctx) {
        this.ctx = ctx;
    }

    // ---------------------------------------------------------------- Given
    @Given("a booking exists")
    public void bookingExists() {
        Booking payload = BookingPayloadBuilder.randomBooking();
        var response = api.createBooking(payload);
        assertThat(response.statusCode()).as("precondition: create booking").isEqualTo(200);
        ctx.setRequestBooking(payload);
        ctx.setBookingId(response.as(BookingResponse.class).bookingid());
    }

    // ---------------------------------------------------------------- Create
    @When("I create a booking with random data")
    public void createRandom() {
        create(BookingPayloadBuilder.randomBooking());
    }

    @When("I create a booking from Excel row {string} of sheet {string}")
    public void createFromExcel(String testCaseId, String sheet) {
        Map<String, String> row = ExcelUtils.getRow(ConfigManager.get("testdata.excel"), sheet, testCaseId);
        create(BookingPayloadBuilder.fromMap(row));
    }

    @When("I create a booking from JSON test data {string}")
    public void createFromJson(String key) {
        Map<String, Booking> data = JsonUtils.readClasspath(ConfigManager.get("testdata.json"),
                new TypeReference<Map<String, Booking>>() {});
        assertThat(data).as("JSON test data key").containsKey(key);
        create(data.get(key));
    }

    @When("I create a booking with the raw payload:")
    public void createRaw(String payload) {
        ctx.setResponse(api.createBookingRaw(payload));
    }

    private void create(Booking booking) {
        ctx.setRequestBooking(booking);
        var response = api.createBooking(booking);
        ctx.setResponse(response);
        if (response.statusCode() == 200) {
            ctx.setBookingId(response.as(BookingResponse.class).bookingid());
        }
    }

    // ---------------------------------------------------------------- Read
    @When("I get all booking ids")
    public void getAllIds() {
        ctx.setResponse(api.getBookingIds(null));
    }

    @When("I get booking ids filtered by the {word} of the created booking")
    public void getIdsFiltered(String field) {
        Booking b = ctx.getRequestBooking();
        String value = switch (field) {
            case "firstname" -> b.firstname();
            case "lastname" -> b.lastname();
            case "checkin" -> b.bookingdates().checkin();
            case "checkout" -> b.bookingdates().checkout();
            default -> throw new IllegalArgumentException("Unsupported filter: " + field);
        };
        ctx.setResponse(api.getBookingIds(Map.of(field, value)));
    }

    @When("I get booking ids filtered by firstname {string} and lastname {string}")
    public void getIdsByName(String first, String last) {
        ctx.setResponse(api.getBookingIds(Map.of("firstname", first, "lastname", last)));
    }

    @When("I get booking ids filtered by the created booking's firstname and lastname")
    public void getIdsByCreatedNames() {
        Booking b = ctx.getRequestBooking();
        ctx.setResponse(api.getBookingIds(Map.of("firstname", b.firstname(), "lastname", b.lastname())));
    }

    @When("I get the booking by its id")
    public void getById() {
        ctx.setResponse(api.getBooking(ctx.getBookingId()));
    }

    @When("I get the booking with id {int}")
    public void getByExplicitId(int id) {
        ctx.setResponse(api.getBooking(id));
    }

    // ---------------------------------------------------------------- Update (PUT)
    @When("I update the booking with new data using a valid token")
    public void updateWithToken() {
        Booking updated = BookingPayloadBuilder.randomBooking();
        ctx.setRequestBooking(updated);
        ctx.setResponse(api.updateBooking(ctx.getBookingId(), updated, TokenManager.getToken()));
    }

    @When("I update the booking with new data using basic auth")
    public void updateWithBasic() {
        Booking updated = BookingPayloadBuilder.randomBooking();
        ctx.setRequestBooking(updated);
        ctx.setResponse(api.updateBookingBasicAuth(ctx.getBookingId(), updated,
                ConfigManager.username(), ConfigManager.password()));
    }

    @When("I update the booking with new data without authentication")
    public void updateNoAuth() {
        ctx.setResponse(api.updateBooking(ctx.getBookingId(), BookingPayloadBuilder.randomBooking(), null));
    }

    @When("I update the booking with new data using an invalid token")
    public void updateBadToken() {
        ctx.setResponse(api.updateBooking(ctx.getBookingId(), BookingPayloadBuilder.randomBooking(), "invalid-token"));
    }

    @When("I update the non-existent booking {int} with new data using a valid token")
    public void updateMissing(int id) {
        ctx.setResponse(api.updateBooking(id, BookingPayloadBuilder.randomBooking(), TokenManager.getToken()));
    }

    // ---------------------------------------------------------------- Partial update (PATCH)
    @When("I partially update the booking firstname to {string} and lastname to {string} using a valid token")
    public void patchWithToken(String first, String last) {
        Booking partial = BookingPayloadBuilder.partial(first, last);
        ctx.setResponse(api.partialUpdateBooking(ctx.getBookingId(), partial, TokenManager.getToken()));
    }

    @When("I partially update the booking firstname to {string} without authentication")
    public void patchNoAuth(String first) {
        ctx.setResponse(api.partialUpdateBooking(ctx.getBookingId(), BookingPayloadBuilder.partial(first, null), null));
    }

    // ---------------------------------------------------------------- Delete
    @When("I delete the booking using a valid token")
    public void deleteWithToken() {
        ctx.setResponse(api.deleteBooking(ctx.getBookingId(), TokenManager.getToken()));
    }

    @When("I delete the booking using basic auth")
    public void deleteWithBasic() {
        ctx.setResponse(api.deleteBookingBasicAuth(ctx.getBookingId(),
                ConfigManager.username(), ConfigManager.password()));
    }

    @When("I delete the booking without authentication")
    public void deleteNoAuth() {
        ctx.setResponse(api.deleteBooking(ctx.getBookingId(), null));
    }

    @When("I delete the non-existent booking {int} using a valid token")
    public void deleteMissing(int id) {
        ctx.setResponse(api.deleteBooking(id, TokenManager.getToken()));
    }

    // ---------------------------------------------------------------- Assertions
    @Then("the created booking id should be returned")
    public void idReturned() {
        assertThat(ctx.getResponse().as(BookingResponse.class).bookingid()).isNotNull().isPositive();
    }

    @Then("the response booking should match the request data")
    public void responseMatchesRequest() {
        assertResponseMatchesRequest();
    }

    private void assertResponseMatchesRequest() {
        var response = ctx.getResponse();
        Booking actual = response.jsonPath().get("booking") != null
                ? response.jsonPath().getObject("booking", Booking.class)
                : response.as(Booking.class);
        assertThat(actual).usingRecursiveComparison().isEqualTo(ctx.getRequestBooking());
    }

    @Then("the booking ids list should contain the created booking id")
    public void listContainsId() {
        List<Integer> ids = ctx.getResponse().jsonPath().getList("bookingid", Integer.class);
        assertThat(ids).contains(ctx.getBookingId());
    }

    @Then("the booking ids list should be empty")
    public void listEmpty() {
        assertThat(ctx.getResponse().jsonPath().getList("bookingid")).isEmpty();
    }

    @Then("the booking ids list should be a non-empty list")
    public void listNotEmpty() {
        assertThat(ctx.getResponse().jsonPath().getList("bookingid")).isNotEmpty();
    }

    @Then("the booking firstname should be {string} and lastname should be {string}")
    public void names(String first, String last) {
        Booking b = ctx.getResponse().as(Booking.class);
        assertThat(b.firstname()).isEqualTo(first);
        assertThat(b.lastname()).isEqualTo(last);
    }

    @Then("the other booking fields should be unchanged")
    public void othersUnchanged() {
        Booking original = ctx.getRequestBooking();
        Booking actual = ctx.getResponse().as(Booking.class);
        assertThat(actual).usingRecursiveComparison()
                .ignoringFields("firstname", "lastname").isEqualTo(original);
    }

    @Then("the booking should no longer exist")
    public void gone() {
        assertThat(api.getBooking(ctx.getBookingId()).statusCode()).isEqualTo(404);
        ctx.setBookingId(null); // already removed - skip cleanup
    }
}
