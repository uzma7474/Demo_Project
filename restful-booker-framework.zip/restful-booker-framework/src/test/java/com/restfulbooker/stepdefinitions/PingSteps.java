package com.restfulbooker.stepdefinitions;

import com.restfulbooker.api.PingApi;
import com.restfulbooker.context.ScenarioContext;
import io.cucumber.java.en.When;

public class PingSteps {

    private final ScenarioContext ctx;

    public PingSteps(ScenarioContext ctx) {
        this.ctx = ctx;
    }

    @When("I call the health check endpoint")
    public void healthCheck() {
        ctx.setResponse(new PingApi().healthCheck());
    }
}
