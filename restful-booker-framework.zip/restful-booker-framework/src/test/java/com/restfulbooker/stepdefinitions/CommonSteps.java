package com.restfulbooker.stepdefinitions;

import com.restfulbooker.context.ScenarioContext;
import io.cucumber.java.en.Then;

import static org.assertj.core.api.Assertions.assertThat;

public class CommonSteps {

    private final ScenarioContext ctx;

    public CommonSteps(ScenarioContext ctx) {
        this.ctx = ctx;
    }

    @Then("the response status code should be {int}")
    public void statusCode(int expected) {
        assertThat(ctx.getResponse().statusCode()).as("HTTP status code").isEqualTo(expected);
    }

    @Then("the response time should be under {int} ms")
    public void responseTime(int maxMs) {
        assertThat(ctx.getResponse().time()).as("Response time (ms)").isLessThan((long) maxMs);
    }

    @Then("the response body should be {string}")
    public void bodyEquals(String expected) {
        assertThat(ctx.getResponse().asString().trim()).isEqualTo(expected);
    }

    @Then("the response should match JSON schema {string}")
    public void matchesSchema(String schemaFile) {
        ctx.getResponse().then().assertThat()
                .body(io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/" + schemaFile));
    }
}
