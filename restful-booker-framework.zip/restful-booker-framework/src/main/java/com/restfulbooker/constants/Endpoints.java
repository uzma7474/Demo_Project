package com.restfulbooker.constants;

public final class Endpoints {
    private Endpoints() {}

    public static final String AUTH = "/auth";
    public static final String BOOKING = "/booking";
    public static final String BOOKING_BY_ID = "/booking/{id}";
    public static final String PING = "/ping";
}
