package com.restfulbooker.context;

import com.restfulbooker.pojo.Booking;
import io.restassured.response.Response;

/**
 * Scenario-scoped state shared between step-definition classes (injected by PicoContainer,
 * one fresh instance per scenario - safe for parallel execution).
 */
public class ScenarioContext {
    private Response response;
    private Booking requestBooking;
    private Integer bookingId;

    public Response getResponse() { return response; }
    public void setResponse(Response response) { this.response = response; }

    public Booking getRequestBooking() { return requestBooking; }
    public void setRequestBooking(Booking requestBooking) { this.requestBooking = requestBooking; }

    public Integer getBookingId() { return bookingId; }
    public void setBookingId(Integer bookingId) { this.bookingId = bookingId; }
}
