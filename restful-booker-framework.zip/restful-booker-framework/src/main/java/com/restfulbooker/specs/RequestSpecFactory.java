package com.restfulbooker.specs;

import com.restfulbooker.config.ConfigManager;
import com.restfulbooker.utils.ApiLoggingFilter;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.specification.RequestSpecification;

public final class RequestSpecFactory {

    private RequestSpecFactory() {}

    /** Fresh spec per call - specs are cheap and this keeps parallel runs isolated. */
    public static RequestSpecification base() {
        RestAssuredConfig cfg = RestAssured.config().httpClient(HttpClientConfig.httpClientConfig()
                .setParam("http.connection.timeout", ConfigManager.getInt("http.connection.timeout.ms"))
                .setParam("http.socket.timeout", ConfigManager.getInt("http.socket.timeout.ms")));

        RequestSpecBuilder b = new RequestSpecBuilder()
                .setBaseUri(ConfigManager.baseUri())
                .setContentType(ContentType.JSON)
                .setAccept(ContentType.JSON)
                .setConfig(cfg);
        if (ConfigManager.getBoolean("log.request.response")) {
            b.addFilter(new ApiLoggingFilter());
        }
        return RestAssured.given().spec(b.build());
    }

    /** Spec carrying the token cookie required by PUT / PATCH / DELETE. */
    public static RequestSpecification withToken(String token) {
        RequestSpecification spec = base();
        return token == null ? spec : spec.header("Cookie", "token=" + token);
    }

    /** Alternative auth supported by the API: Basic auth header. */
    public static RequestSpecification withBasicAuth(String user, String pass) {
        return base().auth().preemptive().basic(user, pass);
    }
}
