package com.restfulbooker.pojo;

public record AuthRequest(String username, String password) {}
