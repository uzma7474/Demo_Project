package com.restfulbooker.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** Response of POST /booking. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record BookingResponse(Integer bookingid, Booking booking) {}
