package com.restfulbooker.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Central configuration access. Resolution order (highest wins):
 * 1) JVM system property (-Dbase.uri=...)  2) config/&lt;env&gt;.properties  3) config/config.properties
 */
public final class ConfigManager {

    private static final Properties PROPS = new Properties();

    static {
        load("config/config.properties", true);
        String env = System.getProperty("env");
        if (isUsable(env)) {
            load("config/" + env + ".properties", false);
        }
    }

    private ConfigManager() {}

    private static void load(String path, boolean mandatory) {
        try (InputStream in = ConfigManager.class.getClassLoader().getResourceAsStream(path)) {
            if (in == null) {
                if (mandatory) throw new IllegalStateException("Missing mandatory config file: " + path);
                return;
            }
            PROPS.load(in);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to read config: " + path, e);
        }
    }

    private static boolean isUsable(String v) {
        return v != null && !v.isBlank() && !v.startsWith("${");
    }

    public static String get(String key) {
        String sys = System.getProperty(key);
        if (isUsable(sys)) return sys;
        String val = PROPS.getProperty(key);
        if (val == null) throw new IllegalArgumentException("Config key not found: " + key);
        return val.trim();
    }

    public static int getInt(String key) {
        return Integer.parseInt(get(key));
    }

    public static boolean getBoolean(String key) {
        return Boolean.parseBoolean(get(key));
    }

    public static String baseUri()     { return get("base.uri"); }
    public static String username()    { return get("auth.username"); }
    public static String password()    { return get("auth.password"); }
}
