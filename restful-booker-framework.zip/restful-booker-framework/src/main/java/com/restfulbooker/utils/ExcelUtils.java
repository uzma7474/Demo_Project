package com.restfulbooker.utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Excel helpers. Row 1 of each sheet is the header; every following row becomes a Map(header -> value).
 * Numeric cells are returned without a trailing ".0" so they can be parsed as ints directly.
 */
public final class ExcelUtils {

    private static final DataFormatter FORMATTER = new DataFormatter();

    private ExcelUtils() {}

    public static List<Map<String, String>> readSheet(String classpathFile, String sheetName) {
        try (InputStream in = ExcelUtils.class.getClassLoader().getResourceAsStream(classpathFile)) {
            if (in == null) throw new IllegalArgumentException("Excel file not found on classpath: " + classpathFile);
            try (Workbook wb = new XSSFWorkbook(in)) {
                Sheet sheet = wb.getSheet(sheetName);
                if (sheet == null) throw new IllegalArgumentException("Sheet not found: " + sheetName);
                Row header = sheet.getRow(0);
                List<Map<String, String>> rows = new ArrayList<>();
                for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                    Row row = sheet.getRow(r);
                    if (row == null) continue;
                    Map<String, String> data = new LinkedHashMap<>();
                    for (int c = 0; c < header.getLastCellNum(); c++) {
                        data.put(FORMATTER.formatCellValue(header.getCell(c)).trim(),
                                FORMATTER.formatCellValue(row.getCell(c)).trim());
                    }
                    rows.add(data);
                }
                return rows;
            }
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read Excel " + classpathFile, e);
        }
    }

    /** Returns the row whose "testCaseId" column equals the given id. */
    public static Map<String, String> getRow(String classpathFile, String sheetName, String testCaseId) {
        return readSheet(classpathFile, sheetName).stream()
                .filter(r -> testCaseId.equals(r.get("testCaseId")))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "No row with testCaseId=" + testCaseId + " in sheet " + sheetName));
    }

    /** Writes rows to a new workbook (e.g. an execution summary export). Keys of the first row form the header. */
    public static void writeSheet(Path target, String sheetName, List<Map<String, String>> rows) {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet sheet = wb.createSheet(sheetName);
            if (!rows.isEmpty()) {
                List<String> headers = new ArrayList<>(rows.get(0).keySet());
                Row h = sheet.createRow(0);
                CellStyle bold = wb.createCellStyle();
                Font f = wb.createFont();
                f.setBold(true);
                bold.setFont(f);
                for (int i = 0; i < headers.size(); i++) {
                    Cell c = h.createCell(i);
                    c.setCellValue(headers.get(i));
                    c.setCellStyle(bold);
                }
                for (int r = 0; r < rows.size(); r++) {
                    Row row = sheet.createRow(r + 1);
                    for (int i = 0; i < headers.size(); i++) {
                        row.createCell(i).setCellValue(rows.get(r).getOrDefault(headers.get(i), ""));
                    }
                }
                for (int i = 0; i < headers.size(); i++) sheet.autoSizeColumn(i);
            }
            Files.createDirectories(target.toAbsolutePath().getParent());
            try (OutputStream out = Files.newOutputStream(target)) {
                wb.write(out);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Cannot write Excel " + target, e);
        }
    }
}
