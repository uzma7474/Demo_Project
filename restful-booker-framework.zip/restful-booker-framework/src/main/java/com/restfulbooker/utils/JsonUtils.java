package com.restfulbooker.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.IOException;
import java.io.InputStream;

/** JSON helpers: classpath loading, (de)serialisation to POJOs, pretty printing. */
public final class JsonUtils {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .enable(SerializationFeature.INDENT_OUTPUT);

    private JsonUtils() {}

    public static <T> T readClasspath(String path, Class<T> type) {
        try (InputStream in = open(path)) {
            return MAPPER.readValue(in, type);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read JSON " + path, e);
        }
    }

    public static <T> T readClasspath(String path, TypeReference<T> type) {
        try (InputStream in = open(path)) {
            return MAPPER.readValue(in, type);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read JSON " + path, e);
        }
    }

    public static <T> T fromJson(String json, Class<T> type) {
        try {
            return MAPPER.readValue(json, type);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot parse JSON", e);
        }
    }

    public static String toJson(Object o) {
        try {
            return MAPPER.writeValueAsString(o);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot serialise object", e);
        }
    }

    public static String readClasspathAsString(String path) {
        try (InputStream in = open(path)) {
            return new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read " + path, e);
        }
    }

    private static InputStream open(String path) {
        InputStream in = JsonUtils.class.getClassLoader().getResourceAsStream(path);
        if (in == null) throw new IllegalArgumentException("Resource not found on classpath: " + path);
        return in;
    }
}
