package com.restfulbooker.utils;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.regex.Pattern;

/** Logs every request/response to Log4j2 and records it for the HTML report. Secrets are masked. */
public class ApiLoggingFilter implements Filter {

    private static final Logger LOG = LogManager.getLogger(ApiLoggingFilter.class);
    private static final Pattern TOKEN = Pattern.compile("(?i)(token=)[^;\\s]+|(\"token\"\\s*:\\s*\")[^\"]+|(\"password\"\\s*:\\s*\")[^\"]+");

    @Override
    public Response filter(FilterableRequestSpecification req, FilterableResponseSpecification res, FilterContext ctx) {
        long start = System.currentTimeMillis();
        Response response = ctx.next(req, res);
        long took = System.currentTimeMillis() - start;

        StringBuilder sb = new StringBuilder();
        sb.append(req.getMethod()).append(' ').append(req.getURI()).append('\n');
        req.getHeaders().forEach(h -> sb.append("  > ").append(h.getName()).append(": ")
                .append(mask(h.getName().equalsIgnoreCase("Authorization") ? "Authorization masked" : h.getValue())).append('\n'));
        if (req.getBody() != null) {
            Object body = req.getBody();
            String text = body instanceof String str ? str : JsonUtils.toJson(body);
            sb.append("  Request body: ").append(mask(text)).append('\n');
        }
        sb.append("  <- ").append(response.getStatusLine()).append(" (").append(took).append(" ms)\n");
        String body = response.asString();
        if (body != null && !body.isBlank()) sb.append("  Response body: ").append(mask(body));

        String transcript = sb.toString();
        LOG.info("API call\n{}", transcript);
        ApiCallRecorder.record(transcript);
        return response;
    }

    private static String mask(String s) {
        return TOKEN.matcher(s).replaceAll(m -> {
            String g = m.group();
            int cut = m.group(1) != null ? m.end(1) - m.start() : m.group(2) != null ? m.end(2) - m.start() : m.end(3) - m.start();
            return java.util.regex.Matcher.quoteReplacement(g.substring(0, cut) + "****");
        });
    }
}
