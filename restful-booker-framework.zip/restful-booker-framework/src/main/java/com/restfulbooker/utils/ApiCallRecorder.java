package com.restfulbooker.utils;

import java.util.ArrayList;
import java.util.List;

/** Thread-local buffer of request/response transcripts, flushed into the report by the After hook. */
public final class ApiCallRecorder {
    private static final ThreadLocal<List<String>> CALLS = ThreadLocal.withInitial(ArrayList::new);

    private ApiCallRecorder() {}

    public static void record(String transcript) { CALLS.get().add(transcript); }

    public static List<String> drain() {
        List<String> copy = new ArrayList<>(CALLS.get());
        CALLS.get().clear();
        return copy;
    }
}
