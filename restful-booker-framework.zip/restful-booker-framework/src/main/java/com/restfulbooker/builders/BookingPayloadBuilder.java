package com.restfulbooker.builders;

import com.restfulbooker.pojo.Booking;
import com.restfulbooker.pojo.BookingDates;
import net.datafaker.Faker;

import java.time.LocalDate;
import java.util.Map;

/** Builds booking payloads: random (DataFaker), from a data map (Excel row), or partial. */
public final class BookingPayloadBuilder {

    private static final Faker FAKER = new Faker();
    private static final String[] NEEDS = {"Breakfast", "Lunch", "Dinner", "Late checkout", "Parking"};

    private BookingPayloadBuilder() {}

    public static Booking randomBooking() {
        LocalDate checkin = LocalDate.now().plusDays(FAKER.number().numberBetween(1, 30));
        LocalDate checkout = checkin.plusDays(FAKER.number().numberBetween(1, 14));
        return new Booking(
                FAKER.name().firstName(),
                FAKER.name().lastName(),
                FAKER.number().numberBetween(100, 2000),
                FAKER.bool().bool(),
                new BookingDates(checkin.toString(), checkout.toString()),
                NEEDS[FAKER.number().numberBetween(0, NEEDS.length)]);
    }

    /** Keys: firstname,lastname,totalprice,depositpaid,checkin,checkout,additionalneeds */
    public static Booking fromMap(Map<String, String> d) {
        return new Booking(
                d.get("firstname"),
                d.get("lastname"),
                Integer.valueOf(d.get("totalprice")),
                Boolean.valueOf(d.get("depositpaid")),
                new BookingDates(d.get("checkin"), d.get("checkout")),
                d.get("additionalneeds"));
    }

    /** Partial payload for PATCH. */
    public static Booking partial(String firstname, String lastname) {
        return new Booking(firstname, lastname, null, null, null, null);
    }
}
