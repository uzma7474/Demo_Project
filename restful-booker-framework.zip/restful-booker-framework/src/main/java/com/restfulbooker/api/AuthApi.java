package com.restfulbooker.api;

import com.restfulbooker.constants.Endpoints;
import com.restfulbooker.pojo.AuthRequest;
import com.restfulbooker.specs.RequestSpecFactory;
import io.restassured.response.Response;

/** POST /auth - CreateToken */
public class AuthApi {

    public Response createToken(String username, String password) {
        return RequestSpecFactory.base()
                .body(new AuthRequest(username, password))
                .post(Endpoints.AUTH);
    }
}
