package com.restfulbooker.api;

import com.restfulbooker.constants.Endpoints;
import com.restfulbooker.pojo.Booking;
import com.restfulbooker.specs.RequestSpecFactory;
import io.restassured.response.Response;

import java.util.Map;

/** All /booking endpoints: GetBookingIds, GetBooking, CreateBooking, UpdateBooking, PartialUpdateBooking, DeleteBooking. */
public class BookingApi {

    public Response getBookingIds(Map<String, String> filters) {
        var spec = RequestSpecFactory.base();
        if (filters != null) spec.queryParams(filters);
        return spec.get(Endpoints.BOOKING);
    }

    public Response getBooking(Object id) {
        return RequestSpecFactory.base().pathParam("id", id).get(Endpoints.BOOKING_BY_ID);
    }

    public Response createBooking(Booking booking) {
        return RequestSpecFactory.base().body(booking).post(Endpoints.BOOKING);
    }

    /** Raw body variant for negative tests (malformed / incomplete JSON). */
    public Response createBookingRaw(String rawBody) {
        return RequestSpecFactory.base().body(rawBody).post(Endpoints.BOOKING);
    }

    /** token == null sends the request unauthenticated. */
    public Response updateBooking(Object id, Booking booking, String token) {
        return RequestSpecFactory.withToken(token).pathParam("id", id).body(booking).put(Endpoints.BOOKING_BY_ID);
    }

    public Response updateBookingBasicAuth(Object id, Booking booking, String user, String pass) {
        return RequestSpecFactory.withBasicAuth(user, pass).pathParam("id", id).body(booking).put(Endpoints.BOOKING_BY_ID);
    }

    public Response partialUpdateBooking(Object id, Booking partial, String token) {
        return RequestSpecFactory.withToken(token).pathParam("id", id).body(partial).patch(Endpoints.BOOKING_BY_ID);
    }

    public Response deleteBooking(Object id, String token) {
        return RequestSpecFactory.withToken(token).pathParam("id", id).delete(Endpoints.BOOKING_BY_ID);
    }

    public Response deleteBookingBasicAuth(Object id, String user, String pass) {
        return RequestSpecFactory.withBasicAuth(user, pass).pathParam("id", id).delete(Endpoints.BOOKING_BY_ID);
    }
}
