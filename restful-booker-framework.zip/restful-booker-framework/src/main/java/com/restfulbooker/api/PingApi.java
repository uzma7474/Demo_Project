package com.restfulbooker.api;

import com.restfulbooker.constants.Endpoints;
import com.restfulbooker.specs.RequestSpecFactory;
import io.restassured.response.Response;

/** GET /ping - HealthCheck */
public class PingApi {

    public Response healthCheck() {
        return RequestSpecFactory.base().get(Endpoints.PING);
    }
}
