package com.restfulbooker.api;

import com.restfulbooker.config.ConfigManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** Lazily fetches and caches the admin token once per JVM (thread-safe) to avoid a /auth call per scenario. */
public final class TokenManager {

    private static final Logger LOG = LogManager.getLogger(TokenManager.class);
    private static volatile String token;

    private TokenManager() {}

    public static String getToken() {
        if (token == null) {
            synchronized (TokenManager.class) {
                if (token == null) {
                    LOG.info("Generating admin token");
                    token = new AuthApi().createToken(ConfigManager.username(), ConfigManager.password())
                            .then().statusCode(200).extract().path("token");
                    if (token == null) throw new IllegalStateException("Auth succeeded but no token was returned");
                }
            }
        }
        return token;
    }
}
