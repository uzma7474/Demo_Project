import { Then, When } from '@cucumber/cucumber';
import { CartAssertions } from '../../assertions/CartAssertions';
import { CustomWorld } from '../../support/CustomWorld';

// =======================================================================================================
// Navigation
// =======================================================================================================

When('the user opens the cart', async function (this: CustomWorld): Promise<void> {
    await this.cartHelper.openCart();
});

When('the user clicks continue shopping', async function (this: CustomWorld): Promise<void> {
    await this.cartHelper.continueShopping();
});

When('the user clicks checkout', async function (this: CustomWorld): Promise<void> {
    await this.cartHelper.proceedToCheckout();
});

// =======================================================================================================
// Actions
// =======================================================================================================

When('the user removes {product} from the cart page', async function (this: CustomWorld, product: string): Promise<void> {
    await this.cartHelper.removeItem(product);
    this.cartProducts = this.cartProducts.filter(name => name !== product);
});

// =======================================================================================================
// Assertions
// =======================================================================================================

Then('the cart page should be displayed', async function (this: CustomWorld): Promise<void> {
    await CartAssertions.verifyCartPageDisplayed(this.pages.cart);
});

Then('the cart should contain {int} item(s)', async function (this: CustomWorld, count: number): Promise<void> {
    await CartAssertions.verifyItemCount(this.pages.cart, count);
});

Then('the cart should be empty', async function (this: CustomWorld): Promise<void> {
    await CartAssertions.verifyItemCount(this.pages.cart, 0);
});

Then('the cart should contain {product}', async function (this: CustomWorld, product: string): Promise<void> {
    await CartAssertions.verifyCartContains(this.pages.cart, product);
});

Then('the cart should not contain {product}', async function (this: CustomWorld, product: string): Promise<void> {
    await CartAssertions.verifyCartDoesNotContain(this.pages.cart, product);
});

Then('the cart item {product} should have quantity {int}', async function (this: CustomWorld, product: string, quantity: number): Promise<void> {
    await CartAssertions.verifyItemQuantity(this.pages.cart, product, quantity);
});
