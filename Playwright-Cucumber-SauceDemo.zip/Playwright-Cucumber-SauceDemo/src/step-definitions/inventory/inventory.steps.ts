import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { InventoryAssertions } from '../../assertions/InventoryAssertions';
import { CustomWorld } from '../../support/CustomWorld';
import { SortKey } from '../../utils/Constants';
import { TestDataUtil } from '../../utils/TestDataUtil';

const DESCRIPTION_KEY = 'selectedProductDescription';

// =======================================================================================================
// Page state
// =======================================================================================================

Then('the inventory page should be displayed', async function (this: CustomWorld): Promise<void> {
    await InventoryAssertions.verifyInventoryPageDisplayed(this.pages.inventory);
});

Then('{int} products should be displayed', async function (this: CustomWorld, count: number): Promise<void> {
    await InventoryAssertions.verifyProductCount(this.pages.inventory, count);
});

Then('every product should show its name, description, price and image', async function (this: CustomWorld): Promise<void> {
    await InventoryAssertions.verifyAllProductsHaveDetails(this.pages.inventory, TestDataUtil.getProducts());
});

Then('the header and footer should be displayed', async function (this: CustomWorld): Promise<void> {
    await InventoryAssertions.verifyHeaderDisplayed(this.pages.inventory);
    await InventoryAssertions.verifyFooterDisplayed(this.pages.inventory);
});

// =======================================================================================================
// Sorting
// =======================================================================================================

When('the user selects sort option {string}', async function (this: CustomWorld, optionLabel: string): Promise<void> {
    await this.inventoryHelper.sortBy(optionLabel);
});

Then('the products should be sorted by {string}', async function (this: CustomWorld, sortKey: string): Promise<void> {
    await InventoryAssertions.verifySortOrder(this.pages.inventory, sortKey as SortKey);
});

// =======================================================================================================
// Cart actions from the products page
// =======================================================================================================

When('the user adds {product} to the cart', async function (this: CustomWorld, product: string): Promise<void> {
    await this.inventoryHelper.addProductToCart(product);
    this.cartProducts.push(product);
});

When('the user removes {product} from the products page', async function (this: CustomWorld, product: string): Promise<void> {
    await this.inventoryHelper.removeProductFromCart(product);
    this.cartProducts = this.cartProducts.filter(name => name !== product);
});

Then('the cart badge should show {int}', async function (this: CustomWorld, count: number): Promise<void> {
    await InventoryAssertions.verifyCartBadgeCount(this.pages.inventory, count);
});

Then('the cart badge should not be displayed', async function (this: CustomWorld): Promise<void> {
    await InventoryAssertions.verifyCartBadgeNotDisplayed(this.pages.inventory);
});

Then('the {product} button should read {string}', async function (this: CustomWorld, product: string, text: string): Promise<void> {
    await InventoryAssertions.verifyProductButtonText(this.pages.inventory, product, text);
});

// =======================================================================================================
// Side menu
// =======================================================================================================

When('the user opens the side menu', async function (this: CustomWorld): Promise<void> {
    await this.inventoryHelper.openSideMenu();
});

When('the user logs out', async function (this: CustomWorld): Promise<void> {
    await this.inventoryHelper.logout();
});

When('the user resets the app state', async function (this: CustomWorld): Promise<void> {
    await this.inventoryHelper.resetAppState();
    this.cartProducts = [];
});

Then('the side menu should display all menu options', async function (this: CustomWorld): Promise<void> {
    await InventoryAssertions.verifySideMenuOptions(this.pages.inventory);
});

// =======================================================================================================
// Product details
// =======================================================================================================

When('the user opens the details of {product}', async function (this: CustomWorld, product: string): Promise<void> {
    // Remember the description shown in the list so the details page can be compared with it.
    const description = await this.pages.inventory.getProductCard(product).getDescription();
    this.scenarioData.set(DESCRIPTION_KEY, description);

    await this.inventoryHelper.openProductDetails(product);
});

Then('the product details should match the catalogue for {product}', async function (this: CustomWorld, product: string): Promise<void> {
    await InventoryAssertions.verifyProductDetails(this.pages.productDetails, {
        name: product,
        price: TestDataUtil.getProduct(product).price,
        description: this.scenarioData.get(DESCRIPTION_KEY) ?? ''
    });

    expect(this.scenarioData.get(DESCRIPTION_KEY), 'Description captured from the list').toBeTruthy();
});

When('the user adds the product to the cart from the details page', async function (this: CustomWorld): Promise<void> {
    const name = await this.pages.productDetails.getName();

    await this.inventoryHelper.addToCartFromDetails();
    this.cartProducts.push(name);
});

When('the user goes back to the products page', async function (this: CustomWorld): Promise<void> {
    await this.inventoryHelper.backToProducts();
});

Then('the product details page should show the Remove button', async function (this: CustomWorld): Promise<void> {
    expect(await this.pages.productDetails.isRemoveButtonDisplayed()).toBe(true);
});
