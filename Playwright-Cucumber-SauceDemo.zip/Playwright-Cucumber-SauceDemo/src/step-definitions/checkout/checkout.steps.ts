import { Then, When } from '@cucumber/cucumber';
import { CheckoutAssertions } from '../../assertions/CheckoutAssertions';
import { CustomWorld } from '../../support/CustomWorld';
import { OrderHelper } from '../../helpers/OrderHelper';
import { OrderConfirmation } from '../../utils/Constants';
import { TestDataUtil } from '../../utils/TestDataUtil';

// =======================================================================================================
// Step one - customer information
// =======================================================================================================

When(
    'the user fills checkout information with first name {string}, last name {string} and postal code {string}',
    async function (this: CustomWorld, firstName: string, lastName: string, postalCode: string): Promise<void> {
        await this.checkoutHelper.fillInformation(firstName, lastName, postalCode);
    }
);

When('the user fills checkout information with the default customer details', async function (this: CustomWorld): Promise<void> {
    await this.checkoutHelper.fillInformationWith(TestDataUtil.getDefaultCheckout());
});

When('the user clicks continue', async function (this: CustomWorld): Promise<void> {
    await this.checkoutHelper.continueToOverview();
});

When('the user cancels the checkout from the information page', async function (this: CustomWorld): Promise<void> {
    await this.checkoutHelper.cancelFromInformation();
});

Then('the checkout information page should be displayed', async function (this: CustomWorld): Promise<void> {
    await CheckoutAssertions.verifyInformationPageDisplayed(this.pages.checkoutInfo);
});

Then('the checkout error message should be {string}', async function (this: CustomWorld, message: string): Promise<void> {
    await CheckoutAssertions.verifyInformationError(this.pages.checkoutInfo, message);
});

// =======================================================================================================
// Step two - overview
// =======================================================================================================

Then('the checkout overview page should be displayed', async function (this: CustomWorld): Promise<void> {
    await CheckoutAssertions.verifyOverviewPageDisplayed(this.pages.checkoutOverview);
});

Then('the overview should list {product}', async function (this: CustomWorld, product: string): Promise<void> {
    await CheckoutAssertions.verifyOverviewContains(this.pages.checkoutOverview, product);
});

Then('the order summary should be calculated correctly', async function (this: CustomWorld): Promise<void> {
    const expected = OrderHelper.calculateExpectedSummary(this.cartProducts);

    await CheckoutAssertions.verifyOrderSummary(this.pages.checkoutOverview, expected);
});

When('the user cancels the checkout from the overview page', async function (this: CustomWorld): Promise<void> {
    await this.checkoutHelper.cancelFromOverview();
});

When('the user finishes the order', async function (this: CustomWorld): Promise<void> {
    await this.checkoutHelper.finishOrder();
});

// =======================================================================================================
// Complete
// =======================================================================================================

Then('the order confirmation page should be displayed', async function (this: CustomWorld): Promise<void> {
    await CheckoutAssertions.verifyCompletePageDisplayed(this.pages.checkoutComplete);
});

Then('the confirmation message should be {string}', async function (this: CustomWorld, message: string): Promise<void> {
    await CheckoutAssertions.verifyConfirmationHeader(this.pages.checkoutComplete, message);
});

Then('the order should be confirmed', async function (this: CustomWorld): Promise<void> {
    await CheckoutAssertions.verifyCompletePageDisplayed(this.pages.checkoutComplete);
    await CheckoutAssertions.verifyConfirmationHeader(this.pages.checkoutComplete, OrderConfirmation.header);
});

When('the user returns to products from the confirmation page', async function (this: CustomWorld): Promise<void> {
    await this.checkoutHelper.backToProducts();
    this.cartProducts = [];
});

// =======================================================================================================
// High-level workflow
// =======================================================================================================

When(
    'the user places an order for {product} using the default customer details',
    async function (this: CustomWorld, product: string): Promise<void> {
        await this.orderHelper.placeOrder([product]);
        this.cartProducts = [product];
    }
);
