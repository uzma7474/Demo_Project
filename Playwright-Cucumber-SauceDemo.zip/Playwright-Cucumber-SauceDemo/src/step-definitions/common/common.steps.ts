import { Given, Then, When } from '@cucumber/cucumber';
import { CommonAssertions } from '../../assertions/CommonAssertions';
import { LoginAssertions } from '../../assertions/LoginAssertions';
import { CustomWorld } from '../../support/CustomWorld';

// =======================================================================================================
// Given
// =======================================================================================================

Given('user opens SauceDemo application', async function (this: CustomWorld): Promise<void> {
    await this.loginHelper.openLoginPage();
});

Given('the user is on the SauceDemo login page', async function (this: CustomWorld): Promise<void> {
    await this.loginHelper.openLoginPage();
    await LoginAssertions.verifyLoginPageDisplayed(this.pages.login);
});

/** Logs in through the UI with a user from users.json and waits for the products page. */
Given('the user is logged in as {string}', async function (this: CustomWorld, username: string): Promise<void> {
    await this.loginHelper.loginAs(username);
});

/** Each scenario gets a fresh browser context, so "not logged in" only needs a clean session. */
Given('the user has not logged into SauceDemo', async function (this: CustomWorld): Promise<void> {
    await this.context.clearCookies();
});

// =======================================================================================================
// When
// =======================================================================================================

When('the user navigates directly to {string}', async function (this: CustomWorld, relativePath: string): Promise<void> {
    await this.pages.login.navigateToPath(relativePath);
});

// =======================================================================================================
// Then
// =======================================================================================================

Then('the user should be redirected to {string}', async function (this: CustomWorld, relativePath: string): Promise<void> {
    await CommonAssertions.verifyUrlContains(this.page, relativePath);
});

Then('the user should be redirected to the login page', async function (this: CustomWorld): Promise<void> {
    await CommonAssertions.verifyOnLoginPageUrl(this.page);
    await LoginAssertions.verifyLoginPageDisplayed(this.pages.login);
});

Then('the page heading should be {string}', async function (this: CustomWorld, heading: string): Promise<void> {
    await CommonAssertions.verifyPageHeading(this.page, heading);
});
