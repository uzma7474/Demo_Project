import { Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { InventoryAssertions } from '../../assertions/InventoryAssertions';
import { LoginAssertions } from '../../assertions/LoginAssertions';
import { CustomWorld } from '../../support/CustomWorld';

/**
 * Gherkin trims table cells and cannot express control characters, so feature files use
 * the escape sequences \s (space), \t (tab) and \n (newline); they are converted here.
 */
const decode = (value: string): string =>
    value.replace(/\\s/g, ' ').replace(/\\t/g, '\t').replace(/\\n/g, '\n');

// =======================================================================================================
// When
// =======================================================================================================

When('user enters username {string}', async function (this: CustomWorld, username: string): Promise<void> {
    await this.loginHelper.enterUsername(decode(username));
});

When('user enters password {string}', async function (this: CustomWorld, password: string): Promise<void> {
    await this.loginHelper.enterPassword(decode(password));
});

When('user leaves the username field empty', async function (this: CustomWorld): Promise<void> {
    await this.loginHelper.enterUsername('');
});

When('user leaves the password field empty', async function (this: CustomWorld): Promise<void> {
    await this.loginHelper.enterPassword('');
});

When('user clicks login button', async function (this: CustomWorld): Promise<void> {
    await this.loginHelper.clickLogin();
});

When('the user closes the login error message', async function (this: CustomWorld): Promise<void> {
    await this.loginHelper.closeErrorMessage();
});

// =======================================================================================================
// Then - successful login
// =======================================================================================================

Then('user should be redirected to inventory page', async function (this: CustomWorld): Promise<void> {
    await this.loginHelper.waitForInventoryPage();
    await expect(this.page).toHaveURL(/inventory\.html/);
    await InventoryAssertions.verifyInventoryPageDisplayed(this.pages.inventory);
});

// =======================================================================================================
// Then - login errors
// =======================================================================================================

Then('the login error message should be {string}', async function (this: CustomWorld, expectedMessage: string): Promise<void> {
    await LoginAssertions.verifyLoginErrorMessage(this.pages.login, expectedMessage);
});

Then('the login error message should be displayed', async function (this: CustomWorld): Promise<void> {
    await LoginAssertions.verifyErrorMessageDisplayed(this.pages.login);
});

Then('the login error message should not be displayed', async function (this: CustomWorld): Promise<void> {
    await LoginAssertions.verifyErrorMessageNotDisplayed(this.pages.login);
});

// =======================================================================================================
// Then - UI validation
// =======================================================================================================

Then('the username field should be displayed', async function (this: CustomWorld): Promise<void> {
    await LoginAssertions.verifyUsernameFieldDisplayed(this.pages.login);
});

Then('the password field should be displayed', async function (this: CustomWorld): Promise<void> {
    await LoginAssertions.verifyPasswordFieldDisplayed(this.pages.login);
});

Then('the Login button should be displayed', async function (this: CustomWorld): Promise<void> {
    await LoginAssertions.verifyLoginButtonDisplayed(this.pages.login);
});

Then('the Login button should be enabled', async function (this: CustomWorld): Promise<void> {
    await LoginAssertions.verifyLoginButtonEnabled(this.pages.login);
});

Then('the password should be masked', async function (this: CustomWorld): Promise<void> {
    await LoginAssertions.verifyPasswordIsMasked(this.pages.login);
});

// =======================================================================================================
// Then - access control
// =======================================================================================================

Then('the user should not have access to the inventory page', async function (this: CustomWorld): Promise<void> {
    await LoginAssertions.verifyNoAccessToInventory(this.pages.inventory);
});
