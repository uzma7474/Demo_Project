import { expect } from '@playwright/test';
import { CheckoutCompletePage } from '../pages/checkout/CheckoutCompletePage';
import { CheckoutInformationPage } from '../pages/checkout/CheckoutInformationPage';
import { CheckoutOverviewPage } from '../pages/checkout/CheckoutOverviewPage';
import { PageHeadings } from '../utils/Constants';
import { CommonAssertions } from './CommonAssertions';

export class CheckoutAssertions {

    // ============================================================
    // Step one
    // ============================================================

    static async verifyInformationPageDisplayed(page: CheckoutInformationPage): Promise<void> {
        await CommonAssertions.eventually(() => page.isDisplayed(), 'Checkout information page should be displayed');
        expect(await page.getHeadingText()).toBe(PageHeadings.checkoutInformation);
    }

    static async verifyInformationError(page: CheckoutInformationPage, expectedMessage: string): Promise<void> {
        expect(await page.getErrorMessage()).toBe(expectedMessage);
    }

    // ============================================================
    // Step two
    // ============================================================

    static async verifyOverviewPageDisplayed(page: CheckoutOverviewPage): Promise<void> {
        await CommonAssertions.eventually(() => page.isDisplayed(), 'Checkout overview page should be displayed');
        expect(await page.getHeadingText()).toBe(PageHeadings.checkoutOverview);
    }

    static async verifyOverviewContains(page: CheckoutOverviewPage, productName: string): Promise<void> {
        expect(await page.getItemNames()).toContain(productName);
    }

    static async verifyOrderSummary(
        page: CheckoutOverviewPage,
        expected: { itemTotal: number; tax: number; total: number }
    ): Promise<void> {

        const actual = await page.getOrderSummary();

        expect(actual.itemTotal, 'Item total').toBeCloseTo(expected.itemTotal, 2);
        expect(actual.tax, 'Tax').toBeCloseTo(expected.tax, 2);
        expect(actual.total, 'Total').toBeCloseTo(expected.total, 2);
    }

    // ============================================================
    // Complete
    // ============================================================

    static async verifyCompletePageDisplayed(page: CheckoutCompletePage): Promise<void> {
        await CommonAssertions.eventually(() => page.isDisplayed(), 'Checkout complete page should be displayed');
        expect(await page.getHeadingText()).toBe(PageHeadings.checkoutComplete);
    }

    static async verifyConfirmationHeader(page: CheckoutCompletePage, expectedHeader: string): Promise<void> {
        expect(await page.getConfirmationHeader()).toBe(expectedHeader);
    }
}
