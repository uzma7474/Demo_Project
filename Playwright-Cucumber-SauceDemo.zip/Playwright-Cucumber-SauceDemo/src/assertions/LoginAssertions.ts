import { expect } from '@playwright/test';
import { LoginPage } from '../pages/login/LoginPage';
import { InventoryPage } from '../pages/inventory/InventoryPage';
import { ErrorMessages } from '../utils/Constants';
import { CommonAssertions } from './CommonAssertions';

export class LoginAssertions {

    /** Verifies the exact login error text. */
    static async verifyLoginErrorMessage(loginPage: LoginPage, expectedMessage: string): Promise<void> {

        const actualMessage = await loginPage.getErrorMessage();

        expect(actualMessage).toBe(expectedMessage);
    }

    static async verifyLoginPageDisplayed(loginPage: LoginPage): Promise<void> {
        await CommonAssertions.eventually(() => loginPage.isLoginPageDisplayed(), 'Login page should be displayed');
    }

    // ============================================================
    // Fields and buttons
    // ============================================================

    static async verifyUsernameFieldDisplayed(loginPage: LoginPage): Promise<void> {
        await CommonAssertions.eventually(() => loginPage.isUsernameFieldDisplayed(), 'Username field should be displayed');
    }

    static async verifyPasswordFieldDisplayed(loginPage: LoginPage): Promise<void> {
        await CommonAssertions.eventually(() => loginPage.isPasswordFieldDisplayed(), 'Password field should be displayed');
    }

    static async verifyLoginButtonDisplayed(loginPage: LoginPage): Promise<void> {
        await CommonAssertions.eventually(() => loginPage.isLoginButtonDisplayed(), 'Login button should be displayed');
    }

    static async verifyLoginButtonEnabled(loginPage: LoginPage): Promise<void> {
        await CommonAssertions.eventually(() => loginPage.isLoginButtonEnabled(), 'Login button should be enabled');
    }

    static async verifyPasswordIsMasked(loginPage: LoginPage): Promise<void> {
        expect(await loginPage.getPasswordInputType()).toBe('password');
    }

    // ============================================================
    // Error message visibility
    // ============================================================

    static async verifyErrorMessageDisplayed(loginPage: LoginPage): Promise<void> {
        await CommonAssertions.eventually(() => loginPage.isErrorMessageVisible(), 'Login error message should be displayed');
    }

    static async verifyErrorMessageNotDisplayed(loginPage: LoginPage): Promise<void> {
        await CommonAssertions.eventuallyNot(() => loginPage.isErrorMessageVisible(), 'Login error message should not be displayed');
    }

    // ============================================================
    // Well-known errors
    // ============================================================

    static async verifyLockedOutUserError(loginPage: LoginPage): Promise<void> {
        await LoginAssertions.verifyLoginErrorMessage(loginPage, ErrorMessages.lockedOutUser);
    }

    static async verifyUsernameRequiredError(loginPage: LoginPage): Promise<void> {
        await LoginAssertions.verifyLoginErrorMessage(loginPage, ErrorMessages.usernameRequired);
    }

    static async verifyPasswordRequiredError(loginPage: LoginPage): Promise<void> {
        await LoginAssertions.verifyLoginErrorMessage(loginPage, ErrorMessages.passwordRequired);
    }

    static async verifyInvalidCredentialsError(loginPage: LoginPage): Promise<void> {
        await LoginAssertions.verifyLoginErrorMessage(loginPage, ErrorMessages.invalidCredentials);
    }

    // ============================================================
    // Access control
    // ============================================================

    /** An unauthenticated visitor must not see the product list. */
    static async verifyNoAccessToInventory(inventoryPage: InventoryPage): Promise<void> {
        await CommonAssertions.eventuallyNot(() => inventoryPage.isDisplayed(), 'Inventory page must not be accessible');
    }
}
