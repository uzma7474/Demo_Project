import { Page, expect } from '@playwright/test';
import { Environment } from '../utils/Environment';
import { RegexUtil } from '../utils/RegexUtil';

/** Cross-page assertions. All of them retry until EXPECT_TIMEOUT. */
export class CommonAssertions {

    /** Retries an async boolean check until it is true (replaces one-shot isVisible() asserts). */
    static async eventually(check: () => Promise<boolean> | boolean, message: string): Promise<void> {
        await expect.poll(check, { message, timeout: Environment.getExpectTimeout() }).toBe(true);
    }

    static async eventuallyNot(check: () => Promise<boolean> | boolean, message: string): Promise<void> {
        await expect.poll(check, { message, timeout: Environment.getExpectTimeout() }).toBe(false);
    }

    static async verifyUrlContains(page: Page, relativePath: string): Promise<void> {
        await expect(page).toHaveURL(new RegExp(RegexUtil.escape(relativePath)));
    }

    /** The login page lives at the site root. */
    static async verifyOnLoginPageUrl(page: Page): Promise<void> {
        await expect(page).toHaveURL(new RegExp(`^${RegexUtil.escape(Environment.getBaseUrl())}/?$`));
    }

    static async verifyPageHeading(page: Page, expectedHeading: string): Promise<void> {
        await expect(page.locator('[data-test="title"]')).toHaveText(expectedHeading);
    }

    static verifyEqual(actual: unknown, expected: unknown, message?: string): void {
        expect(actual, message).toEqual(expected);
    }
}
