import { expect } from '@playwright/test';
import { InventoryPage } from '../pages/inventory/InventoryPage';
import { ProductDetailsPage } from '../pages/inventory/ProductDetailsPage';
import { PageHeadings, SideMenuOptions, SortKey } from '../utils/Constants';
import { ProductData } from '../utils/TestDataUtil';
import { CommonAssertions } from './CommonAssertions';

export class InventoryAssertions {

    static async verifyInventoryPageDisplayed(inventoryPage: InventoryPage): Promise<void> {
        await CommonAssertions.eventually(() => inventoryPage.isDisplayed(), 'Inventory page should be displayed');
    }

    static async verifyHeading(inventoryPage: InventoryPage, expected: string = PageHeadings.inventory): Promise<void> {
        expect(await inventoryPage.getHeadingText()).toBe(expected);
    }

    static async verifyProductCount(inventoryPage: InventoryPage, expectedCount: number): Promise<void> {
        await CommonAssertions.eventually(
            async () => (await inventoryPage.getProductCount()) === expectedCount,
            `Inventory should list ${expectedCount} products`
        );
    }

    /** Every listed product must have a name, description, price and image. */
    static async verifyAllProductsHaveDetails(inventoryPage: InventoryPage, products: ProductData[]): Promise<void> {

        for (const product of products) {

            const card = inventoryPage.getProductCard(product.name);

            expect(await card.isDisplayed(), `${product.name} should be listed`).toBe(true);
            expect((await card.getDescription()).length, `${product.name} description`).toBeGreaterThan(0);
            expect(await card.getPrice(), `${product.name} price`).toBe(product.price);
            expect(await card.isImageDisplayed(), `${product.name} image`).toBe(true);
        }
    }

    static async verifySortOrder(inventoryPage: InventoryPage, key: SortKey): Promise<void> {

        if (key === 'az' || key === 'za') {

            const names = await inventoryPage.getProductNames();
            const expected = [...names].sort((a, b) => a.localeCompare(b));

            expect(names).toEqual(key === 'az' ? expected : expected.reverse());
            return;
        }

        const prices = await inventoryPage.getProductPrices();
        const expected = [...prices].sort((a, b) => a - b);

        expect(prices).toEqual(key === 'lohi' ? expected : expected.reverse());
    }

    // ============================================================
    // Cart badge and product buttons
    // ============================================================

    static async verifyCartBadgeCount(inventoryPage: InventoryPage, expectedCount: number): Promise<void> {
        await CommonAssertions.eventually(
            async () => (await inventoryPage.header.shoppingCart.getItemCount()) === expectedCount,
            `Cart badge should show ${expectedCount}`
        );
    }

    static async verifyCartBadgeNotDisplayed(inventoryPage: InventoryPage): Promise<void> {
        await CommonAssertions.eventuallyNot(
            () => inventoryPage.header.shoppingCart.isBadgeVisible(),
            'Cart badge should not be displayed'
        );
    }

    static async verifyProductButtonText(inventoryPage: InventoryPage, productName: string, expectedText: string): Promise<void> {
        await CommonAssertions.eventually(
            async () => (await inventoryPage.getProductCard(productName).getActionButtonText()) === expectedText,
            `${productName} button should read "${expectedText}"`
        );
    }

    // ============================================================
    // Side menu / header / footer
    // ============================================================

    static async verifySideMenuOptions(inventoryPage: InventoryPage): Promise<void> {
        expect(await inventoryPage.header.sideMenu.getMenuOptions()).toEqual([...SideMenuOptions]);
    }

    static async verifyHeaderDisplayed(inventoryPage: InventoryPage): Promise<void> {
        await CommonAssertions.eventually(() => inventoryPage.header.isDisplayed(), 'Header should be displayed');
    }

    static async verifyFooterDisplayed(inventoryPage: InventoryPage): Promise<void> {
        await CommonAssertions.eventually(() => inventoryPage.footer.isDisplayed(), 'Footer should be displayed');
        await CommonAssertions.eventually(() => inventoryPage.footer.areSocialLinksDisplayed(), 'Social links should be displayed');
    }

    // ============================================================
    // Product details
    // ============================================================

    static async verifyProductDetails(
        detailsPage: ProductDetailsPage,
        expected: { name: string; price: number; description: string }
    ): Promise<void> {

        expect(await detailsPage.getName()).toBe(expected.name);
        expect(await detailsPage.getPrice()).toBe(expected.price);
        expect(await detailsPage.getDescription()).toBe(expected.description);
        expect(await detailsPage.isImageDisplayed()).toBe(true);
    }
}
