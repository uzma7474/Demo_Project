import { expect } from '@playwright/test';
import { CartPage } from '../pages/cart/CartPage';
import { PageHeadings } from '../utils/Constants';
import { CommonAssertions } from './CommonAssertions';

export class CartAssertions {

    static async verifyCartPageDisplayed(cartPage: CartPage): Promise<void> {
        await CommonAssertions.eventually(() => cartPage.isDisplayed(), 'Cart page should be displayed');
        expect(await cartPage.getHeadingText()).toBe(PageHeadings.cart);
    }

    static async verifyItemCount(cartPage: CartPage, expectedCount: number): Promise<void> {
        await CommonAssertions.eventually(
            async () => (await cartPage.getItemCount()) === expectedCount,
            `Cart should contain ${expectedCount} item(s)`
        );
    }

    static async verifyCartContains(cartPage: CartPage, productName: string): Promise<void> {
        expect(await cartPage.getItemNames()).toContain(productName);
    }

    static async verifyCartDoesNotContain(cartPage: CartPage, productName: string): Promise<void> {
        await CommonAssertions.eventually(
            async () => !(await cartPage.getItemNames()).includes(productName),
            `Cart should not contain ${productName}`
        );
    }

    static async verifyItemQuantity(cartPage: CartPage, productName: string, expectedQuantity: number): Promise<void> {
        expect(await cartPage.getItemQuantity(productName)).toBe(expectedQuantity);
    }
}
