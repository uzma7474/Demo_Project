import { AfterAll, BeforeAll, setDefaultTimeout } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { EnvironmentManager, config } from '../core/EnvironmentManager';
import { Logger } from '../utils/Logger';

// Cucumber step timeout must exceed Playwright's own action timeouts.
setDefaultTimeout(60 * 1000);

// Playwright `expect` outside the Playwright runner uses this global default.
expect.configure({ timeout: config.expectTimeout });

BeforeAll(function () {
    EnvironmentManager.ensureDirectories();
    Logger.info(`Run started | env=${config.env} browser=${config.browser} headless=${config.headless} baseUrl=${config.baseUrl}`);
});

AfterAll(function () {
    Logger.info('Run finished');
});
