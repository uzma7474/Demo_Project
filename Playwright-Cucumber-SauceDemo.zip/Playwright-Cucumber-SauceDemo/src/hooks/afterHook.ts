import fs from 'fs';
import path from 'path';
import { After, ITestCaseHookParameter, Status } from '@cucumber/cucumber';
import { config } from '../core/EnvironmentManager';
import { CustomWorld } from '../support/CustomWorld';
import { Environment } from '../utils/Environment';
import { Logger } from '../utils/Logger';
import { ScreenshotUtil } from '../utils/ScreenshotUtil';

/**
 * After hook:
 *   - Screenshot if failed (also attached to the Cucumber report)
 *   - Trace if failed (or always when TRACE=on)
 *   - Close browser (page -> context -> browser)
 */
After(async function (this: CustomWorld, scenario: ITestCaseHookParameter) {

    const failed = scenario.result?.status === Status.FAILED;
    const status = scenario.result?.status ?? 'UNKNOWN';

    // Browser may be missing if the Before hook itself failed.
    const video = this.page?.video();

    try {
        if (failed && this.page && Environment.isScreenshotOnFailure()) {
            const screenshot = await ScreenshotUtil.capture(this.page, this.scenarioName);
            this.attach(screenshot, 'image/png');
        }

        if (this.context && Environment.getTraceMode() !== 'off') {

            const keepTrace = failed || Environment.getTraceMode() === 'on';

            if (keepTrace) {
                fs.mkdirSync(config.paths.traces, { recursive: true });
                const tracePath = path.join(config.paths.traces, `${ScreenshotUtil.toFileName(this.scenarioName)}.zip`);

                await this.context.tracing.stop({ path: tracePath });
                Logger.info(`Trace saved: ${tracePath}`);
            } else {
                await this.context.tracing.stop();
            }
        }
    } catch (error) {
        Logger.error(`After hook artifact capture failed: ${(error as Error).message}`);
    } finally {
        await this.dispose();
    }

    // Videos are finalized when the context closes; keep them only for failures.
    if (video) {
        try {
            const videoPath = await video.path();
            if (!failed) fs.rmSync(videoPath, { force: true });
        } catch {
            // video unavailable - nothing to clean up
        }
    }

    Logger.info(`END    ${this.scenarioName} -> ${status}`);
});
