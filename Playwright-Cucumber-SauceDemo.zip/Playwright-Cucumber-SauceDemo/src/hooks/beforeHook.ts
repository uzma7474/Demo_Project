import { Before, ITestCaseHookParameter } from '@cucumber/cucumber';
import { CustomWorld } from '../support/CustomWorld';
import { Environment } from '../utils/Environment';
import { Logger } from '../utils/Logger';

/**
 * Before hook:
 *   BrowserFixture -> Browser -> BrowserContext -> Page -> CustomWorld (helpers, page objects, test data)
 */
Before(async function (this: CustomWorld, scenario: ITestCaseHookParameter) {

    this.scenarioName = scenario.pickle.name;

    Logger.info(`START  ${this.scenarioName}`);

    await this.initialize();

    if (Environment.getTraceMode() !== 'off') {
        await this.context.tracing.start({ screenshots: true, snapshots: true, sources: true });
    }
});
