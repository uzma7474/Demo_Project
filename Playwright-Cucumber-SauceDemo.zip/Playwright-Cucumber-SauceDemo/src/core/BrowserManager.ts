import { Browser, BrowserContext, Page } from '@playwright/test';
import { BrowserFixture } from '../fixtures/browserFixture';
import { ContextFixture } from '../fixtures/contextFixture';
import { PageFixture } from '../fixtures/pageFixture';

/**
 * Orchestrates the browser lifecycle:  BrowserFixture -> Browser -> BrowserContext -> Page
 * One manager instance exists per scenario (owned by CustomWorld).
 */
export class BrowserManager {

    private readonly browserFixture = new BrowserFixture();
    private readonly contextFixture = new ContextFixture();
    private readonly pageFixture = new PageFixture();

    async start(): Promise<Page> {

        const browser = await this.browserFixture.launch();

        const context = await this.contextFixture.createContext(browser);

        return this.pageFixture.createPage(context);
    }

    getBrowser(): Browser {
        return this.browserFixture.getBrowser();
    }

    getContext(): BrowserContext {
        return this.contextFixture.getContext();
    }

    getPage(): Page {
        return this.pageFixture.getPage();
    }

    async stop(): Promise<void> {

        await this.pageFixture.close();
        await this.contextFixture.close();
        await this.browserFixture.close();
    }
}
