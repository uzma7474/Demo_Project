import { Page } from '@playwright/test';
import { LoginPage } from '../pages/login/LoginPage';
import { InventoryPage } from '../pages/inventory/InventoryPage';
import { ProductDetailsPage } from '../pages/inventory/ProductDetailsPage';
import { CartPage } from '../pages/cart/CartPage';
import { CheckoutInformationPage } from '../pages/checkout/CheckoutInformationPage';
import { CheckoutOverviewPage } from '../pages/checkout/CheckoutOverviewPage';
import { CheckoutCompletePage } from '../pages/checkout/CheckoutCompletePage';

/**
 * Lazily creates and caches one instance of every page object for a scenario.
 * Steps and helpers never call `new XxxPage(page)` themselves.
 */
export class PageObjectManager {

    private _login?: LoginPage;
    private _inventory?: InventoryPage;
    private _productDetails?: ProductDetailsPage;
    private _cart?: CartPage;
    private _checkoutInfo?: CheckoutInformationPage;
    private _checkoutOverview?: CheckoutOverviewPage;
    private _checkoutComplete?: CheckoutCompletePage;

    constructor(private readonly page: Page) { }

    get login(): LoginPage {
        return (this._login ??= new LoginPage(this.page));
    }

    get inventory(): InventoryPage {
        return (this._inventory ??= new InventoryPage(this.page));
    }

    get productDetails(): ProductDetailsPage {
        return (this._productDetails ??= new ProductDetailsPage(this.page));
    }

    get cart(): CartPage {
        return (this._cart ??= new CartPage(this.page));
    }

    get checkoutInfo(): CheckoutInformationPage {
        return (this._checkoutInfo ??= new CheckoutInformationPage(this.page));
    }

    get checkoutOverview(): CheckoutOverviewPage {
        return (this._checkoutOverview ??= new CheckoutOverviewPage(this.page));
    }

    get checkoutComplete(): CheckoutCompletePage {
        return (this._checkoutComplete ??= new CheckoutCompletePage(this.page));
    }
}
