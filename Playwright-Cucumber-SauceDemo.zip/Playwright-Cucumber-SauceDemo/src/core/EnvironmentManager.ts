import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

/**
 * Loads environment variables and exposes one typed, immutable config object.
 *
 * Priority: real env vars > .env.<ENV> > .env   (dotenv never overrides existing values)
 */
const root = path.resolve(__dirname, '..', '..');

const envName = process.env.ENV || 'qa';

const envSpecific = path.join(root, `.env.${envName}`);

if (fs.existsSync(envSpecific)) {
    dotenv.config({ path: envSpecific, quiet: true });
}
dotenv.config({ path: path.join(root, '.env'), quiet: true });

const toBool = (value: string | undefined, fallback: boolean): boolean =>
    value === undefined ? fallback : ['true', '1', 'yes', 'on'].includes(value.toLowerCase());

export type BrowserName = 'chromium' | 'firefox' | 'webkit';
export type TraceMode = 'on' | 'off' | 'on-failure';

export const config = {
    env: envName,

    baseUrl: (process.env.BASE_URL || 'https://www.saucedemo.com').replace(/\/+$/, ''),

    browser: (process.env.BROWSER || 'chromium') as BrowserName,
    headless: toBool(process.env.HEADLESS, true),
    slowMo: Number(process.env.SLOW_MO || 0),

    defaultTimeout: Number(process.env.DEFAULT_TIMEOUT || 15000),
    navigationTimeout: Number(process.env.NAVIGATION_TIMEOUT || 30000),
    expectTimeout: Number(process.env.EXPECT_TIMEOUT || 10000),

    viewport: {
        width: Number(process.env.VIEWPORT_WIDTH || 1366),
        height: Number(process.env.VIEWPORT_HEIGHT || 768)
    },

    video: toBool(process.env.VIDEO, false),
    trace: (process.env.TRACE || 'on-failure') as TraceMode,
    screenshotOnFailure: toBool(process.env.SCREENSHOT_ON_FAILURE, true),
    logLevel: (process.env.LOG_LEVEL || 'info').toLowerCase(),

    paths: {
        root,
        testData: path.join(root, 'src', 'test-data'),
        reports: path.join(root, 'reports'),
        screenshots: path.join(root, 'screenshots'),
        traces: path.join(root, 'traces'),
        videos: path.join(root, 'videos'),
        downloads: path.join(root, 'downloads', 'pdf')
    }
} as const;

export class EnvironmentManager {

    static getConfig(): typeof config {
        return config;
    }

    /** Creates the artifact folders so hooks never fail on a fresh checkout. */
    static ensureDirectories(): void {
        const { screenshots, traces, videos, downloads, reports } = config.paths;

        [screenshots, traces, videos, downloads,
            path.join(reports, 'html'),
            path.join(reports, 'json'),
            path.join(reports, 'cucumber-report')
        ].forEach(dir => fs.mkdirSync(dir, { recursive: true }));
    }
}
