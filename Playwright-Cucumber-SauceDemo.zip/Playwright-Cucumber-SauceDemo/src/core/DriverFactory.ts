import { Browser, LaunchOptions, chromium, firefox, webkit } from '@playwright/test';
import { BrowserName } from './EnvironmentManager';

/**
 * Single place that knows how to launch each supported browser.
 * Adding a new browser/channel (e.g. Edge) only touches this class.
 */
export class DriverFactory {

    static async createBrowser(name: BrowserName | string, options: LaunchOptions = {}): Promise<Browser> {

        switch (name.toLowerCase()) {

            case 'firefox':
                return firefox.launch(options);

            case 'webkit':
                return webkit.launch(options);

            case 'chromium':
            default:
                return chromium.launch(options);
        }
    }
}
