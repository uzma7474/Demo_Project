import { PageObjectManager } from '../core/PageObjectManager';

/** Workflows on the products page, product details page and the shared header/menu. */
export class InventoryHelper {

    constructor(private readonly pages: PageObjectManager) { }

    // =========================================================
    // Products
    // =========================================================

    async getProductNames(): Promise<string[]> {
        return this.pages.inventory.getProductNames();
    }

    async getProductPrices(): Promise<number[]> {
        return this.pages.inventory.getProductPrices();
    }

    async addProductToCart(productName: string): Promise<void> {
        await this.pages.inventory.addProductToCart(productName);
    }

    async addProductsToCart(productNames: string[]): Promise<void> {
        for (const name of productNames) {
            await this.addProductToCart(name);
        }
    }

    async removeProductFromCart(productName: string): Promise<void> {
        await this.pages.inventory.removeProductFromCart(productName);
    }

    async sortBy(optionLabel: string): Promise<void> {
        await this.pages.inventory.sortBy(optionLabel);
    }

    // =========================================================
    // Product details
    // =========================================================

    async openProductDetails(productName: string): Promise<void> {
        await this.pages.inventory.openProductDetails(productName);
        await this.pages.productDetails.getName();
    }

    async addToCartFromDetails(): Promise<void> {
        await this.pages.productDetails.addToCart();
    }

    async backToProducts(): Promise<void> {
        await this.pages.productDetails.backToProducts();
        await this.pages.inventory.waitForPageLoad();
    }

    // =========================================================
    // Cart badge
    // =========================================================

    async getCartItemCount(): Promise<number> {
        return this.pages.inventory.header.shoppingCart.getItemCount();
    }

    async openCart(): Promise<void> {
        await this.pages.inventory.openCart();
    }

    // =========================================================
    // Side menu
    // =========================================================

    async openSideMenu(): Promise<void> {
        await this.pages.inventory.header.sideMenu.open();
    }

    async logout(): Promise<void> {
        await this.openSideMenu();
        await this.pages.inventory.header.sideMenu.logout();
    }

    async resetAppState(): Promise<void> {
        await this.openSideMenu();
        await this.pages.inventory.header.sideMenu.resetAppState();
    }
}
