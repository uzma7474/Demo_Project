import { PageObjectManager } from '../core/PageObjectManager';
import { Environment } from '../utils/Environment';
import { TestDataUtil } from '../utils/TestDataUtil';

/** Business-level login workflows built on LoginPage. */
export class LoginHelper {

    constructor(private readonly pages: PageObjectManager) { }

    // =========================================================
    // Open Login Page
    // =========================================================

    async openLoginPage(): Promise<void> {
        await this.pages.login.open();
    }

    // =========================================================
    // Login workflow
    // =========================================================

    /** Opens the login page, enters the credentials and submits. */
    async login(username: string | undefined, password: string | undefined): Promise<void> {

        if (username === undefined || password === undefined) {
            throw new Error('Login credentials are not configured.');
        }

        await this.openLoginPage();
        await this.enterUsername(username);
        await this.enterPassword(password);
        await this.clickLogin();
    }

    /** Logs in with a user from users.json (password looked up automatically) and waits for the inventory page. */
    async loginAs(username: string): Promise<void> {
        await this.login(username, TestDataUtil.getPasswordFor(username));
        await this.waitForInventoryPage();
    }

    async enterUsername(username: string): Promise<void> {
        await this.pages.login.enterUsername(username);
    }

    async enterPassword(password: string): Promise<void> {
        await this.pages.login.enterPassword(password);
    }

    async clickLogin(): Promise<void> {
        await this.pages.login.clickLogin();
    }

    // =========================================================
    // Verify login
    // =========================================================

    async isLoginSuccessful(): Promise<boolean> {
        return this.pages.login.getCurrentUrl().includes('/inventory.html');
    }

    async waitForInventoryPage(): Promise<void> {
        await this.pages.login.waitForInventoryPage();
    }

    // =========================================================
    // Errors
    // =========================================================

    async getLoginErrorMessage(): Promise<string> {
        return this.pages.login.getErrorMessage();
    }

    async isLoginErrorDisplayed(): Promise<boolean> {
        return this.pages.login.isErrorMessageVisible();
    }

    async closeErrorMessage(): Promise<void> {
        await this.pages.login.closeErrorMessage();
    }

    // =========================================================
    // Field state
    // =========================================================

    async isUsernameFieldDisplayed(): Promise<boolean> {
        return this.pages.login.isUsernameFieldDisplayed();
    }

    async isPasswordFieldDisplayed(): Promise<boolean> {
        return this.pages.login.isPasswordFieldDisplayed();
    }

    async getPasswordInputType(): Promise<string | null> {
        return this.pages.login.getPasswordInputType();
    }

    // =========================================================
    // Named SauceDemo users (credentials come from .env, with test-data fallback)
    // =========================================================

    private async loginWithEnvUser(usernameKey: string, fallbackUsername: string): Promise<void> {

        const username = Environment.get(usernameKey, fallbackUsername);
        const password = Environment.get('STANDARD_PASSWORD', TestDataUtil.getCredentials().defaultPassword);

        await this.login(username, password);
    }

    async loginAsStandardUser(): Promise<void> {
        await this.loginWithEnvUser('STANDARD_USERNAME', 'standard_user');
    }

    async loginAsLockedUser(): Promise<void> {
        await this.loginWithEnvUser('LOCKED_USERNAME', 'locked_out_user');
    }

    async loginAsProblemUser(): Promise<void> {
        await this.loginWithEnvUser('PROBLEM_USERNAME', 'problem_user');
    }

    async loginAsPerformanceUser(): Promise<void> {
        await this.loginWithEnvUser('PERFORMANCE_USERNAME', 'performance_glitch_user');
    }

    async loginWithInvalidCredentials(username: string, password: string): Promise<void> {
        await this.login(username, password);
    }
}
