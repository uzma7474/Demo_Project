import { PageObjectManager } from '../core/PageObjectManager';

/** Workflows on the cart page. */
export class CartHelper {

    constructor(private readonly pages: PageObjectManager) { }

    async openCart(): Promise<void> {
        await this.pages.inventory.openCart();
        await this.pages.cart.waitForPageLoad();
    }

    async getItemNames(): Promise<string[]> {
        return this.pages.cart.getItemNames();
    }

    async getItemCount(): Promise<number> {
        await this.pages.cart.waitForPageLoad();
        return this.pages.cart.getItemCount();
    }

    async removeItem(productName: string): Promise<void> {
        await this.pages.cart.removeItem(productName);
    }

    async continueShopping(): Promise<void> {
        await this.pages.cart.continueShopping();
    }

    async proceedToCheckout(): Promise<void> {
        await this.pages.cart.proceedToCheckout();
    }
}
