import { PageObjectManager } from '../core/PageObjectManager';
import { CartHelper } from './CartHelper';
import { CheckoutHelper } from './CheckoutHelper';
import { InventoryHelper } from './InventoryHelper';
import { CheckoutData, TestDataUtil } from '../utils/TestDataUtil';
import { TAX_RATE } from '../utils/Constants';

/**
 * End-to-end ordering workflow (inventory -> cart -> checkout -> confirmation).
 * Composes the other helpers so scenarios can use one high-level step.
 */
export class OrderHelper {

    private readonly inventory: InventoryHelper;
    private readonly cart: CartHelper;
    private readonly checkout: CheckoutHelper;

    constructor(pages: PageObjectManager) {
        this.inventory = new InventoryHelper(pages);
        this.cart = new CartHelper(pages);
        this.checkout = new CheckoutHelper(pages);
    }

    /** Adds the products, checks out with the given (or default) details and finishes the order. */
    async placeOrder(productNames: string[], customer: CheckoutData = TestDataUtil.getDefaultCheckout()): Promise<void> {

        await this.inventory.addProductsToCart(productNames);
        await this.cart.openCart();
        await this.cart.proceedToCheckout();
        await this.checkout.fillInformationWith(customer);
        await this.checkout.continueToOverview();
        await this.checkout.finishOrder();
    }

    /** Expected item total, tax and total in cents-accurate arithmetic for the given products. */
    static calculateExpectedSummary(productNames: string[]): { itemTotal: number; tax: number; total: number } {

        const itemTotalCents = productNames
            .map(name => Math.round(TestDataUtil.getProduct(name).price * 100))
            .reduce((sum, cents) => sum + cents, 0);

        const taxCents = Math.round(itemTotalCents * TAX_RATE);

        return {
            itemTotal: itemTotalCents / 100,
            tax: taxCents / 100,
            total: (itemTotalCents + taxCents) / 100
        };
    }
}
