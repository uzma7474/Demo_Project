import { PageObjectManager } from '../core/PageObjectManager';
import { OrderSummary } from '../pages/checkout/CheckoutOverviewPage';
import { CheckoutData } from '../utils/TestDataUtil';

/** Workflows across the three checkout pages (information, overview, complete). */
export class CheckoutHelper {

    constructor(private readonly pages: PageObjectManager) { }

    // =========================================================
    // Step one: customer information
    // =========================================================

    async fillInformation(firstName: string, lastName: string, postalCode: string): Promise<void> {
        await this.pages.checkoutInfo.fillInformation(firstName, lastName, postalCode);
    }

    async fillInformationWith(data: CheckoutData): Promise<void> {
        await this.fillInformation(data.firstName, data.lastName, data.postalCode);
    }

    async continueToOverview(): Promise<void> {
        await this.pages.checkoutInfo.clickContinue();
    }

    async cancelFromInformation(): Promise<void> {
        await this.pages.checkoutInfo.clickCancel();
    }

    async getInformationError(): Promise<string> {
        return this.pages.checkoutInfo.getErrorMessage();
    }

    // =========================================================
    // Step two: overview
    // =========================================================

    async getOverviewItemNames(): Promise<string[]> {
        return this.pages.checkoutOverview.getItemNames();
    }

    async getOrderSummary(): Promise<OrderSummary> {
        return this.pages.checkoutOverview.getOrderSummary();
    }

    async finishOrder(): Promise<void> {
        await this.pages.checkoutOverview.clickFinish();
    }

    async cancelFromOverview(): Promise<void> {
        await this.pages.checkoutOverview.clickCancel();
    }

    // =========================================================
    // Complete
    // =========================================================

    async getConfirmationHeader(): Promise<string> {
        return this.pages.checkoutComplete.getConfirmationHeader();
    }

    async backToProducts(): Promise<void> {
        await this.pages.checkoutComplete.backToProducts();
    }
}
