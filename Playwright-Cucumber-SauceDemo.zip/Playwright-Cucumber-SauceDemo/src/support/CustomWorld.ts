import { IWorldOptions, World } from '@cucumber/cucumber';
import { Browser, BrowserContext, Page } from '@playwright/test';

import { BrowserManager } from '../core/BrowserManager';
import { PageObjectManager } from '../core/PageObjectManager';
import { PageObjectFixture } from '../fixtures/pageObjectFixture';
import { TestDataFixture } from '../fixtures/testDataFixture';

import { LoginHelper } from '../helpers/LoginHelper';
import { InventoryHelper } from '../helpers/InventoryHelper';
import { CartHelper } from '../helpers/CartHelper';
import { CheckoutHelper } from '../helpers/CheckoutHelper';
import { OrderHelper } from '../helpers/OrderHelper';

/**
 * One World instance is created per scenario by Cucumber.
 * It owns the browser resources, page objects, helpers and test data of that scenario.
 */
export class CustomWorld extends World {

    // Browser lifecycle management
    readonly browserManager: BrowserManager;

    // Playwright objects (set by initialize())
    browser!: Browser;
    context!: BrowserContext;
    page!: Page;

    // Page objects
    private readonly pageObjectFixture: PageObjectFixture;
    pages!: PageObjectManager;

    // Business workflow helpers
    loginHelper!: LoginHelper;
    inventoryHelper!: InventoryHelper;
    cartHelper!: CartHelper;
    checkoutHelper!: CheckoutHelper;
    orderHelper!: OrderHelper;

    // Test data
    readonly testData: TestDataFixture;

    // Scenario information
    scenarioName = '';

    /** Products the scenario has put in the cart (used to compute expected order totals). */
    cartProducts: string[] = [];

    /** Free-form values shared between steps of the same scenario. */
    readonly scenarioData = new Map<string, string>();

    constructor(options: IWorldOptions) {
        super(options);

        this.browserManager = new BrowserManager();
        this.pageObjectFixture = new PageObjectFixture();
        this.testData = new TestDataFixture();
    }

    /** Starts the browser and wires page objects, helpers and test data for the scenario. */
    async initialize(): Promise<void> {

        // Browser -> BrowserContext -> Page
        this.page = await this.browserManager.start();
        this.browser = this.browserManager.getBrowser();
        this.context = this.browserManager.getContext();

        // One PageObjectManager per scenario, shared by every helper.
        this.pages = this.pageObjectFixture.initialize(this.page);

        this.loginHelper = new LoginHelper(this.pages);
        this.inventoryHelper = new InventoryHelper(this.pages);
        this.cartHelper = new CartHelper(this.pages);
        this.checkoutHelper = new CheckoutHelper(this.pages);
        this.orderHelper = new OrderHelper(this.pages);

        this.testData.load();
    }

    /** Releases the browser resources after the scenario. */
    async dispose(): Promise<void> {
        await this.browserManager.stop();
    }
}
