import { defineParameterType } from '@cucumber/cucumber';

/** {product} matches any of the six SauceDemo catalogue items (unquoted in feature files). */
defineParameterType({
    name: 'product',
    regexp: /Sauce Labs Backpack|Sauce Labs Bike Light|Sauce Labs Bolt T-Shirt|Sauce Labs Fleece Jacket|Sauce Labs Onesie|Test\.allTheThings\(\) T-Shirt \(Red\)/,
    transformer: (value: string) => value
});
