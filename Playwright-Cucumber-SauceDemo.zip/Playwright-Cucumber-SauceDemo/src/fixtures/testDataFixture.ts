import { CheckoutData, CredentialsData, ProductData, TestDataUtil, UserData } from '../utils/TestDataUtil';

/** Loads the JSON test data once per scenario and exposes it to steps and helpers. */
export class TestDataFixture {

    private users: Record<string, UserData> = {};
    private products: ProductData[] = [];
    private checkout?: CheckoutData;
    private credentials?: CredentialsData;

    load(): void {
        this.users = TestDataUtil.getUsers();
        this.products = TestDataUtil.getProducts();
        this.checkout = TestDataUtil.getDefaultCheckout();
        this.credentials = TestDataUtil.getCredentials();
    }

    getUsers(): Record<string, UserData> {
        return this.users;
    }

    getProducts(): ProductData[] {
        return this.products;
    }

    getCheckout(): CheckoutData {
        if (!this.checkout) throw new Error('Test data has not been loaded.');
        return this.checkout;
    }

    getCredentials(): CredentialsData {
        if (!this.credentials) throw new Error('Test data has not been loaded.');
        return this.credentials;
    }
}
