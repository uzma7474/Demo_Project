import { BrowserContext, Page } from '@playwright/test';
import { Environment } from '../utils/Environment';

/** Owns the Page for one scenario and applies the default timeouts. */
export class PageFixture {

    private page?: Page;

    async createPage(context: BrowserContext): Promise<Page> {

        this.page = await context.newPage();

        this.page.setDefaultTimeout(Environment.getDefaultTimeout());
        this.page.setDefaultNavigationTimeout(Environment.getNavigationTimeout());

        return this.page;
    }

    getPage(): Page {

        if (!this.page) {
            throw new Error('Page has not been initialized.');
        }

        return this.page;
    }

    async close(): Promise<void> {

        if (this.page) {
            await this.page.close();
            this.page = undefined;
        }
    }
}
