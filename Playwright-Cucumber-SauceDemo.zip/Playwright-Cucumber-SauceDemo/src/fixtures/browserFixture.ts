import { Browser } from '@playwright/test';
import { DriverFactory } from '../core/DriverFactory';
import { Environment } from '../utils/Environment';

/** Owns the Browser instance for one scenario. */
export class BrowserFixture {

    private browser?: Browser;

    async launch(): Promise<Browser> {

        this.browser = await DriverFactory.createBrowser(Environment.getBrowser(), {
            headless: Environment.isHeadless(),
            slowMo: Environment.getSlowMo()
        });

        return this.browser;
    }

    getBrowser(): Browser {

        if (!this.browser) {
            throw new Error('Browser has not been initialized.');
        }

        return this.browser;
    }

    async close(): Promise<void> {

        if (this.browser) {
            await this.browser.close();
            this.browser = undefined;
        }
    }
}
