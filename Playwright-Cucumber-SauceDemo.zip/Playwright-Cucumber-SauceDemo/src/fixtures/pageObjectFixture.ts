import { Page } from '@playwright/test';
import { PageObjectManager } from '../core/PageObjectManager';

/** Owns the PageObjectManager bound to the scenario's Page. */
export class PageObjectFixture {

    private pageObjects?: PageObjectManager;

    initialize(page: Page): PageObjectManager {

        this.pageObjects = new PageObjectManager(page);

        return this.pageObjects;
    }

    getPageObjects(): PageObjectManager {

        if (!this.pageObjects) {
            throw new Error('PageObjectManager has not been initialized.');
        }

        return this.pageObjects;
    }
}
