import { Browser, BrowserContext } from '@playwright/test';
import { config } from '../core/EnvironmentManager';
import { Environment } from '../utils/Environment';

/** Owns the isolated BrowserContext (cookies, storage, tracing, video) for one scenario. */
export class ContextFixture {

    private context?: BrowserContext;

    async createContext(browser: Browser): Promise<BrowserContext> {

        this.context = await browser.newContext({
            viewport: Environment.getViewport(),
            ignoreHTTPSErrors: true,
            recordVideo: Environment.isVideoEnabled() ? { dir: config.paths.videos } : undefined
        });

        return this.context;
    }

    getContext(): BrowserContext {

        if (!this.context) {
            throw new Error('Browser context has not been initialized.');
        }

        return this.context;
    }

    async close(): Promise<void> {

        if (this.context) {
            await this.context.close();
            this.context = undefined;
        }
    }
}
