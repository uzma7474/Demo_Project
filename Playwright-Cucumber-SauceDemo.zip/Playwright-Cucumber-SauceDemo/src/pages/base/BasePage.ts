import { Locator, Page } from '@playwright/test';
import { Environment } from '../../utils/Environment';

/**
 * Wraps raw Playwright calls. Every page object extends this class,
 * so Playwright is only touched here and in locator definitions.
 */
export class BasePage {

    protected readonly page: Page;

    /** Page heading rendered by every authenticated screen. */
    protected readonly heading: Locator;

    constructor(page: Page) {
        this.page = page;
        this.heading = page.locator('[data-test="title"]');
    }

    // =========================================================
    // Navigation
    // =========================================================

    async navigateTo(url?: string): Promise<void> {
        await this.page.goto(url ?? Environment.getBaseUrl(), { waitUntil: 'domcontentloaded' });
    }

    /** Navigates to a path relative to BASE_URL, e.g. "/inventory.html". */
    async navigateToPath(relativePath: string): Promise<void> {
        await this.navigateTo(`${Environment.getBaseUrl()}${relativePath}`);
    }

    async reload(): Promise<void> {
        await this.page.reload({ waitUntil: 'domcontentloaded' });
    }

    async goBack(): Promise<void> {
        await this.page.goBack({ waitUntil: 'domcontentloaded' });
    }

    async goForward(): Promise<void> {
        await this.page.goForward({ waitUntil: 'domcontentloaded' });
    }

    // =========================================================
    // Locator helpers
    // =========================================================

    protected getByTestId(testId: string): Locator {
        return this.page.getByTestId(testId);
    }

    protected getByRole(...args: Parameters<Page['getByRole']>): Locator {
        return this.page.getByRole(...args);
    }

    protected getByText(text: string | RegExp): Locator {
        return this.page.getByText(text);
    }

    protected locator(selector: string): Locator {
        return this.page.locator(selector);
    }

    // =========================================================
    // Actions
    // =========================================================

    async click(locator: Locator): Promise<void> {
        await locator.click();
    }

    async fill(locator: Locator, value: string): Promise<void> {
        await locator.fill(value);
    }

    async clear(locator: Locator): Promise<void> {
        await locator.clear();
    }

    async press(locator: Locator, key: string): Promise<void> {
        await locator.press(key);
    }

    async selectOptionByLabel(locator: Locator, label: string): Promise<void> {
        await locator.selectOption({ label });
    }

    async hover(locator: Locator): Promise<void> {
        await locator.hover();
    }

    // =========================================================
    // Element state
    // =========================================================

    async isVisible(locator: Locator): Promise<boolean> {
        return locator.isVisible();
    }

    async isEnabled(locator: Locator): Promise<boolean> {
        return locator.isEnabled();
    }

    async isDisabled(locator: Locator): Promise<boolean> {
        return locator.isDisabled();
    }

    async isChecked(locator: Locator): Promise<boolean> {
        return locator.isChecked();
    }

    async count(locator: Locator): Promise<number> {
        return locator.count();
    }

    // =========================================================
    // Text / attributes
    // =========================================================

    async getText(locator: Locator): Promise<string> {
        return (await locator.innerText()).trim();
    }

    async getAllTexts(locator: Locator): Promise<string[]> {
        return (await locator.allInnerTexts()).map(text => text.trim());
    }

    async getAttribute(locator: Locator, attribute: string): Promise<string | null> {
        return locator.getAttribute(attribute);
    }

    /** Text of the [data-test="title"] heading, e.g. "Products". */
    async getHeadingText(): Promise<string> {
        await this.waitForVisible(this.heading);
        return this.getText(this.heading);
    }

    // =========================================================
    // Waits
    // =========================================================

    async waitForVisible(locator: Locator): Promise<void> {
        await locator.waitFor({ state: 'visible' });
    }

    async waitForHidden(locator: Locator): Promise<void> {
        await locator.waitFor({ state: 'hidden' });
    }

    async waitForUrl(url: string | RegExp): Promise<void> {
        await this.page.waitForURL(url);
    }

    async waitForLoadState(): Promise<void> {
        await this.page.waitForLoadState('domcontentloaded');
    }

    // =========================================================
    // URL / Page information
    // =========================================================

    getCurrentUrl(): string {
        return this.page.url();
    }

    async getTitle(): Promise<string> {
        return this.page.title();
    }

    // =========================================================
    // Screenshot
    // =========================================================

    async takeScreenshot(path: string): Promise<void> {
        await this.page.screenshot({ path, fullPage: true });
    }
}
