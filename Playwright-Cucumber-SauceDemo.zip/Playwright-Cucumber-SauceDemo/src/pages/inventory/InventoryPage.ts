import { Locator, Page } from '@playwright/test';
import { BasePage } from '../base/BasePage';
import { FooterComponent } from '../components/FooterComponent';
import { HeaderComponent } from '../components/HeaderComponent';
import { ProductCardComponent } from '../components/ProductCardComponent';
import { RegexUtil } from '../../utils/RegexUtil';

export class InventoryPage extends BasePage {

    readonly header: HeaderComponent;
    readonly footer: FooterComponent;

    private readonly container: Locator;
    private readonly productItems: Locator;
    private readonly productNames: Locator;
    private readonly productPrices: Locator;
    private readonly sortDropdown: Locator;

    constructor(page: Page) {
        super(page);

        this.header = new HeaderComponent(page);
        this.footer = new FooterComponent(page);

        this.container = page.locator('[data-test="inventory-container"]');
        this.productItems = page.locator('[data-test="inventory-item"]');
        this.productNames = page.locator('[data-test="inventory-item-name"]');
        this.productPrices = page.locator('[data-test="inventory-item-price"]');
        this.sortDropdown = page.locator('[data-test="product-sort-container"]');
    }

    // =========================================================
    // Page state
    // =========================================================

    async isDisplayed(): Promise<boolean> {
        return this.isVisible(this.container);
    }

    async waitForPageLoad(): Promise<void> {
        await this.waitForVisible(this.container);
    }

    // =========================================================
    // Products
    // =========================================================

    getProductCard(productName: string): ProductCardComponent {

        const card = this.productItems.filter({
            has: this.productNames.filter({ hasText: RegexUtil.exact(productName) })
        });

        return new ProductCardComponent(card);
    }

    async getProductCount(): Promise<number> {
        return this.count(this.productItems);
    }

    async getProductNames(): Promise<string[]> {
        await this.waitForPageLoad();
        return this.getAllTexts(this.productNames);
    }

    async getProductPrices(): Promise<number[]> {
        await this.waitForPageLoad();
        return (await this.getAllTexts(this.productPrices)).map(RegexUtil.parsePrice);
    }

    // =========================================================
    // Actions
    // =========================================================

    async addProductToCart(productName: string): Promise<void> {
        await this.getProductCard(productName).clickActionButton();
    }

    async removeProductFromCart(productName: string): Promise<void> {
        await this.getProductCard(productName).clickActionButton();
    }

    async openProductDetails(productName: string): Promise<void> {
        await this.getProductCard(productName).openDetails();
    }

    /** Selects a sort option by its visible label, e.g. "Price (low to high)". */
    async sortBy(optionLabel: string): Promise<void> {
        await this.selectOptionByLabel(this.sortDropdown, optionLabel);
    }

    async openCart(): Promise<void> {
        await this.header.shoppingCart.open();
    }
}
