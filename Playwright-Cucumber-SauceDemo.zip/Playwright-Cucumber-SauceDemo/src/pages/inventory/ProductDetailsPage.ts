import { Locator, Page } from '@playwright/test';
import { BasePage } from '../base/BasePage';
import { HeaderComponent } from '../components/HeaderComponent';
import { RegexUtil } from '../../utils/RegexUtil';

export class ProductDetailsPage extends BasePage {

    readonly header: HeaderComponent;

    private readonly name: Locator;
    private readonly description: Locator;
    private readonly price: Locator;
    private readonly image: Locator;
    private readonly addToCartButton: Locator;
    private readonly removeButton: Locator;
    private readonly backButton: Locator;

    constructor(page: Page) {
        super(page);

        this.header = new HeaderComponent(page);

        this.name = page.locator('[data-test="inventory-item-name"]');
        this.description = page.locator('[data-test="inventory-item-desc"]');
        this.price = page.locator('[data-test="inventory-item-price"]');
        this.image = page.locator('img.inventory_details_img');
        this.addToCartButton = page.locator('[data-test="add-to-cart"]');
        this.removeButton = page.locator('[data-test="remove"]');
        this.backButton = page.locator('[data-test="back-to-products"]');
    }

    async isDisplayed(): Promise<boolean> {
        return this.isVisible(this.name);
    }

    async getName(): Promise<string> {
        await this.waitForVisible(this.name);
        return this.getText(this.name);
    }

    async getDescription(): Promise<string> {
        return this.getText(this.description);
    }

    async getPrice(): Promise<number> {
        return RegexUtil.parsePrice(await this.getText(this.price));
    }

    async isImageDisplayed(): Promise<boolean> {
        return this.isVisible(this.image.first());
    }

    async addToCart(): Promise<void> {
        await this.click(this.addToCartButton);
    }

    async removeFromCart(): Promise<void> {
        await this.click(this.removeButton);
    }

    async isRemoveButtonDisplayed(): Promise<boolean> {
        return this.isVisible(this.removeButton);
    }

    async backToProducts(): Promise<void> {
        await this.click(this.backButton);
    }
}
