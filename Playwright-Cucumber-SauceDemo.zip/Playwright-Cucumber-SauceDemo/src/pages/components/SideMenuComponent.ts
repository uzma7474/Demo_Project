import { Locator, Page } from '@playwright/test';

/** Burger (slide-out) menu available on every authenticated page. */
export class SideMenuComponent {

    private readonly openButton: Locator;
    private readonly closeButton: Locator;
    private readonly allItemsLink: Locator;
    private readonly aboutLink: Locator;
    private readonly logoutLink: Locator;
    private readonly resetLink: Locator;
    private readonly links: Locator;

    constructor(page: Page) {
        this.openButton = page.locator('#react-burger-menu-btn');
        this.closeButton = page.locator('#react-burger-cross-btn');
        this.allItemsLink = page.locator('[data-test="inventory-sidebar-link"]');
        this.aboutLink = page.locator('[data-test="about-sidebar-link"]');
        this.logoutLink = page.locator('[data-test="logout-sidebar-link"]');
        this.resetLink = page.locator('[data-test="reset-sidebar-link"]');
        this.links = page.locator('.bm-item-list a');
    }

    async open(): Promise<void> {
        await this.openButton.click();
        await this.logoutLink.waitFor({ state: 'visible' });
    }

    async close(): Promise<void> {
        await this.closeButton.click();
        await this.logoutLink.waitFor({ state: 'hidden' });
    }

    async isOpen(): Promise<boolean> {
        return this.logoutLink.isVisible();
    }

    /** Visible link labels, e.g. ["All Items", "About", "Logout", "Reset App State"]. */
    async getMenuOptions(): Promise<string[]> {
        await this.logoutLink.waitFor({ state: 'visible' });
        return (await this.links.allInnerTexts()).map(text => text.trim());
    }

    async clickAllItems(): Promise<void> {
        await this.allItemsLink.click();
    }

    async clickAbout(): Promise<void> {
        await this.aboutLink.click();
    }

    async logout(): Promise<void> {
        await this.logoutLink.click();
    }

    async resetAppState(): Promise<void> {
        await this.resetLink.click();
    }
}
