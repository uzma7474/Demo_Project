import { Locator } from '@playwright/test';
import { RegexUtil } from '../../utils/RegexUtil';

/** One product tile in the inventory list (or one line in the cart / overview). */
export class ProductCardComponent {

    private readonly nameLink: Locator;
    private readonly description: Locator;
    private readonly price: Locator;
    private readonly image: Locator;
    private readonly actionButton: Locator;

    constructor(private readonly root: Locator) {
        this.nameLink = root.locator('[data-test="inventory-item-name"]');
        this.description = root.locator('[data-test="inventory-item-desc"]');
        this.price = root.locator('[data-test="inventory-item-price"]');
        this.image = root.locator('img.inventory_item_img');
        this.actionButton = root.locator('button');
    }

    async isDisplayed(): Promise<boolean> {
        return this.root.isVisible();
    }

    async getName(): Promise<string> {
        return (await this.nameLink.innerText()).trim();
    }

    async getDescription(): Promise<string> {
        return (await this.description.innerText()).trim();
    }

    async getPrice(): Promise<number> {
        return RegexUtil.parsePrice(await this.price.innerText());
    }

    async isImageDisplayed(): Promise<boolean> {
        return this.image.isVisible();
    }

    /** "Add to cart" or "Remove", depending on the cart state of this product. */
    async getActionButtonText(): Promise<string> {
        return (await this.actionButton.innerText()).trim();
    }

    async clickActionButton(): Promise<void> {
        await this.actionButton.click();
    }

    async openDetails(): Promise<void> {
        await this.nameLink.click();
    }
}
