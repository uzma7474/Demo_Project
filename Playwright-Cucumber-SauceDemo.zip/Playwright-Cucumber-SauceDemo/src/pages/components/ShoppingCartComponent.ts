import { Locator, Page } from '@playwright/test';

/** Cart icon + badge shown in the header of every authenticated page. */
export class ShoppingCartComponent {

    private readonly cartLink: Locator;
    private readonly badge: Locator;

    constructor(page: Page) {
        this.cartLink = page.locator('[data-test="shopping-cart-link"]');
        this.badge = page.locator('[data-test="shopping-cart-badge"]');
    }

    async open(): Promise<void> {
        await this.cartLink.click();
    }

    async isBadgeVisible(): Promise<boolean> {
        return this.badge.isVisible();
    }

    /** Number shown on the badge; 0 when no badge is rendered. */
    async getItemCount(): Promise<number> {

        if (!(await this.badge.isVisible())) return 0;

        return Number((await this.badge.innerText()).trim());
    }
}
