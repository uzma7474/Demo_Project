import { Locator, Page } from '@playwright/test';

export class FooterComponent {

    private readonly footer: Locator;
    private readonly twitter: Locator;
    private readonly facebook: Locator;
    private readonly linkedin: Locator;
    private readonly copyright: Locator;

    constructor(page: Page) {
        this.footer = page.locator('[data-test="footer"]');
        this.twitter = page.locator('[data-test="social-twitter"]');
        this.facebook = page.locator('[data-test="social-facebook"]');
        this.linkedin = page.locator('[data-test="social-linkedin"]');
        this.copyright = page.locator('[data-test="footer-copy"]');
    }

    async isDisplayed(): Promise<boolean> {
        return this.footer.isVisible();
    }

    async areSocialLinksDisplayed(): Promise<boolean> {
        return (await this.twitter.isVisible())
            && (await this.facebook.isVisible())
            && (await this.linkedin.isVisible());
    }

    async getCopyrightText(): Promise<string> {
        return (await this.copyright.innerText()).trim();
    }
}
