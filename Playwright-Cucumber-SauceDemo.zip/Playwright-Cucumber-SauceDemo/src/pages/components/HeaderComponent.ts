import { Locator, Page } from '@playwright/test';
import { ShoppingCartComponent } from './ShoppingCartComponent';
import { SideMenuComponent } from './SideMenuComponent';

/** Primary header: burger menu, logo and cart. */
export class HeaderComponent {

    readonly sideMenu: SideMenuComponent;
    readonly shoppingCart: ShoppingCartComponent;

    private readonly header: Locator;
    private readonly logo: Locator;

    constructor(page: Page) {
        this.header = page.locator('[data-test="primary-header"]');
        this.logo = page.locator('.app_logo');
        this.sideMenu = new SideMenuComponent(page);
        this.shoppingCart = new ShoppingCartComponent(page);
    }

    async isDisplayed(): Promise<boolean> {
        return (await this.header.isVisible()) && (await this.logo.isVisible());
    }

    async getLogoText(): Promise<string> {
        return (await this.logo.innerText()).trim();
    }
}
