import { Locator, Page } from '@playwright/test';
import { BasePage } from '../base/BasePage';
import { RegexUtil } from '../../utils/RegexUtil';

export interface OrderSummary {
    itemTotal: number;
    tax: number;
    total: number;
}

export class CheckoutOverviewPage extends BasePage {

    private readonly itemNames: Locator;
    private readonly itemTotalLabel: Locator;
    private readonly taxLabel: Locator;
    private readonly totalLabel: Locator;
    private readonly finishButton: Locator;
    private readonly cancelButton: Locator;

    constructor(page: Page) {
        super(page);

        this.itemNames = page.locator('[data-test="inventory-item-name"]');
        this.itemTotalLabel = page.locator('[data-test="subtotal-label"]');
        this.taxLabel = page.locator('[data-test="tax-label"]');
        this.totalLabel = page.locator('[data-test="total-label"]');
        this.finishButton = page.locator('[data-test="finish"]');
        this.cancelButton = page.locator('[data-test="cancel"]');
    }

    async isDisplayed(): Promise<boolean> {
        return this.isVisible(this.finishButton);
    }

    async waitForPageLoad(): Promise<void> {
        await this.waitForVisible(this.finishButton);
    }

    async getItemNames(): Promise<string[]> {
        await this.waitForPageLoad();
        return this.getAllTexts(this.itemNames);
    }

    async getOrderSummary(): Promise<OrderSummary> {
        await this.waitForPageLoad();

        return {
            itemTotal: RegexUtil.parsePrice(await this.getText(this.itemTotalLabel)),
            tax: RegexUtil.parsePrice(await this.getText(this.taxLabel)),
            total: RegexUtil.parsePrice(await this.getText(this.totalLabel))
        };
    }

    async clickFinish(): Promise<void> {
        await this.click(this.finishButton);
    }

    async clickCancel(): Promise<void> {
        await this.click(this.cancelButton);
    }
}
