import { Locator, Page } from '@playwright/test';
import { BasePage } from '../base/BasePage';

export class CheckoutCompletePage extends BasePage {

    private readonly completeHeader: Locator;
    private readonly completeText: Locator;
    private readonly confirmationImage: Locator;
    private readonly backHomeButton: Locator;

    constructor(page: Page) {
        super(page);

        this.completeHeader = page.locator('[data-test="complete-header"]');
        this.completeText = page.locator('[data-test="complete-text"]');
        this.confirmationImage = page.locator('[data-test="pony-express"]');
        this.backHomeButton = page.locator('[data-test="back-to-products"]');
    }

    async isDisplayed(): Promise<boolean> {
        return this.isVisible(this.completeHeader);
    }

    async waitForPageLoad(): Promise<void> {
        await this.waitForVisible(this.completeHeader);
    }

    async getConfirmationHeader(): Promise<string> {
        await this.waitForVisible(this.completeHeader);
        return this.getText(this.completeHeader);
    }

    async getConfirmationText(): Promise<string> {
        return this.getText(this.completeText);
    }

    async isConfirmationImageDisplayed(): Promise<boolean> {
        return this.isVisible(this.confirmationImage);
    }

    async backToProducts(): Promise<void> {
        await this.click(this.backHomeButton);
    }
}
