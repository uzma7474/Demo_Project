import { Locator, Page } from '@playwright/test';
import { BasePage } from '../base/BasePage';

export class CheckoutInformationPage extends BasePage {

    private readonly firstNameInput: Locator;
    private readonly lastNameInput: Locator;
    private readonly postalCodeInput: Locator;
    private readonly continueButton: Locator;
    private readonly cancelButton: Locator;
    private readonly errorMessage: Locator;

    constructor(page: Page) {
        super(page);

        this.firstNameInput = page.locator('[data-test="firstName"]');
        this.lastNameInput = page.locator('[data-test="lastName"]');
        this.postalCodeInput = page.locator('[data-test="postalCode"]');
        this.continueButton = page.locator('[data-test="continue"]');
        this.cancelButton = page.locator('[data-test="cancel"]');
        this.errorMessage = page.locator('[data-test="error"]');
    }

    async isDisplayed(): Promise<boolean> {
        return this.isVisible(this.firstNameInput);
    }

    async waitForPageLoad(): Promise<void> {
        await this.waitForVisible(this.firstNameInput);
    }

    async fillInformation(firstName: string, lastName: string, postalCode: string): Promise<void> {
        await this.fill(this.firstNameInput, firstName);
        await this.fill(this.lastNameInput, lastName);
        await this.fill(this.postalCodeInput, postalCode);
    }

    async clickContinue(): Promise<void> {
        await this.click(this.continueButton);
    }

    async clickCancel(): Promise<void> {
        await this.click(this.cancelButton);
    }

    async getErrorMessage(): Promise<string> {
        await this.waitForVisible(this.errorMessage);
        return this.getText(this.errorMessage);
    }

    async isErrorMessageVisible(): Promise<boolean> {
        return this.isVisible(this.errorMessage);
    }
}
