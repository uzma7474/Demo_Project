import { Locator, Page } from '@playwright/test';
import { BasePage } from '../base/BasePage';

export class LoginPage extends BasePage {

    // =========================================================
    // Locators
    // =========================================================

    private readonly usernameInput: Locator;
    private readonly passwordInput: Locator;
    private readonly loginButton: Locator;
    private readonly errorMessage: Locator;
    private readonly errorCloseButton: Locator;
    private readonly loginLogo: Locator;

    constructor(page: Page) {
        super(page);

        this.usernameInput = page.locator('[data-test="username"]');
        this.passwordInput = page.locator('[data-test="password"]');
        this.loginButton = page.locator('[data-test="login-button"]');
        this.errorMessage = page.locator('[data-test="error"]');
        this.errorCloseButton = page.locator('[data-test="error-button"]');
        this.loginLogo = page.locator('.login_logo');
    }

    // =========================================================
    // Navigation
    // =========================================================

    async open(): Promise<void> {
        await this.navigateTo();
        await this.waitForVisible(this.loginButton);
    }

    // =========================================================
    // Login actions
    // =========================================================

    async enterUsername(username: string): Promise<void> {
        await this.fill(this.usernameInput, username);
    }

    async enterPassword(password: string): Promise<void> {
        await this.fill(this.passwordInput, password);
    }

    async clickLogin(): Promise<void> {
        await this.click(this.loginButton);
    }

    async login(username: string, password: string): Promise<void> {
        await this.enterUsername(username);
        await this.enterPassword(password);
        await this.clickLogin();
    }

    // =========================================================
    // Error handling
    // =========================================================

    async getErrorMessage(): Promise<string> {
        await this.waitForVisible(this.errorMessage);
        return this.getText(this.errorMessage);
    }

    async isErrorMessageVisible(): Promise<boolean> {
        return this.isVisible(this.errorMessage);
    }

    async closeErrorMessage(): Promise<void> {
        await this.click(this.errorCloseButton);
        await this.waitForHidden(this.errorMessage);
    }

    // =========================================================
    // Element state
    // =========================================================

    async getPasswordInputType(): Promise<string | null> {
        return this.getAttribute(this.passwordInput, 'type');
    }

    async isUsernameFieldDisplayed(): Promise<boolean> {
        return this.isVisible(this.usernameInput);
    }

    async isPasswordFieldDisplayed(): Promise<boolean> {
        return this.isVisible(this.passwordInput);
    }

    async isLoginButtonDisplayed(): Promise<boolean> {
        return this.isVisible(this.loginButton);
    }

    async isLoginButtonEnabled(): Promise<boolean> {
        return this.isEnabled(this.loginButton);
    }

    async isLoginPageDisplayed(): Promise<boolean> {
        return (await this.isVisible(this.loginLogo))
            && (await this.isUsernameFieldDisplayed())
            && (await this.isPasswordFieldDisplayed())
            && (await this.isLoginButtonDisplayed());
    }

    // =========================================================
    // Waits
    // =========================================================

    async waitForInventoryPage(): Promise<void> {
        await this.waitForUrl('**/inventory.html');
    }
}
