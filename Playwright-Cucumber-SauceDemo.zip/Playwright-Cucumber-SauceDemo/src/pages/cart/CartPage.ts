import { Locator, Page } from '@playwright/test';
import { BasePage } from '../base/BasePage';
import { HeaderComponent } from '../components/HeaderComponent';
import { ProductCardComponent } from '../components/ProductCardComponent';
import { RegexUtil } from '../../utils/RegexUtil';

export class CartPage extends BasePage {

    readonly header: HeaderComponent;

    private readonly cartList: Locator;
    private readonly cartItems: Locator;
    private readonly itemNames: Locator;
    private readonly continueShoppingButton: Locator;
    private readonly checkoutButton: Locator;

    constructor(page: Page) {
        super(page);

        this.header = new HeaderComponent(page);

        this.cartList = page.locator('[data-test="cart-list"]');
        this.cartItems = page.locator('[data-test="inventory-item"]');
        this.itemNames = page.locator('[data-test="inventory-item-name"]');
        this.continueShoppingButton = page.locator('[data-test="continue-shopping"]');
        this.checkoutButton = page.locator('[data-test="checkout"]');
    }

    async isDisplayed(): Promise<boolean> {
        return this.isVisible(this.cartList);
    }

    async waitForPageLoad(): Promise<void> {
        await this.waitForVisible(this.cartList);
    }

    getCartItem(productName: string): ProductCardComponent {

        const item = this.cartItems.filter({
            has: this.itemNames.filter({ hasText: RegexUtil.exact(productName) })
        });

        return new ProductCardComponent(item);
    }

    async getItemCount(): Promise<number> {
        return this.count(this.cartItems);
    }

    async getItemNames(): Promise<string[]> {
        await this.waitForPageLoad();
        return this.getAllTexts(this.itemNames);
    }

    async getItemQuantity(productName: string): Promise<number> {
        const quantity = this.cartItems
            .filter({ has: this.itemNames.filter({ hasText: RegexUtil.exact(productName) }) })
            .locator('[data-test="item-quantity"]');

        return Number(await this.getText(quantity));
    }

    async removeItem(productName: string): Promise<void> {
        await this.getCartItem(productName).clickActionButton();
    }

    async continueShopping(): Promise<void> {
        await this.click(this.continueShoppingButton);
    }

    async proceedToCheckout(): Promise<void> {
        await this.click(this.checkoutButton);
    }
}
