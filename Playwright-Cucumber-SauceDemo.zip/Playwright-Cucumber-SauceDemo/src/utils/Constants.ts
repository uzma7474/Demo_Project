/** Relative application routes. */
export const Routes = {
    login: '/',
    inventory: '/inventory.html',
    productDetails: '/inventory-item.html',
    cart: '/cart.html',
    checkoutInformation: '/checkout-step-one.html',
    checkoutOverview: '/checkout-step-two.html',
    checkoutComplete: '/checkout-complete.html'
} as const;

/** Page headings rendered in [data-test="title"]. */
export const PageHeadings = {
    inventory: 'Products',
    cart: 'Your Cart',
    checkoutInformation: 'Checkout: Your Information',
    checkoutOverview: 'Checkout: Overview',
    checkoutComplete: 'Checkout: Complete!'
} as const;

/** Application error messages. */
export const ErrorMessages = {
    lockedOutUser: 'Epic sadface: Sorry, this user has been locked out.',
    invalidCredentials: 'Epic sadface: Username and password do not match any user in this service',
    usernameRequired: 'Epic sadface: Username is required',
    passwordRequired: 'Epic sadface: Password is required',
    firstNameRequired: 'Error: First Name is required',
    lastNameRequired: 'Error: Last Name is required',
    postalCodeRequired: 'Error: Postal Code is required'
} as const;

export const SideMenuOptions = ['All Items', 'About', 'Logout', 'Reset App State'] as const;

export const OrderConfirmation = {
    header: 'Thank you for your order!'
} as const;

/** Sales tax applied by SauceDemo on the item total. */
export const TAX_RATE = 0.08;

/** Dropdown values of the product sort container. */
export type SortKey = 'az' | 'za' | 'lohi' | 'hilo';
