/**
 * Generic wait helpers for non-UI conditions.
 * For UI conditions prefer Playwright auto-waiting / web-first assertions.
 */
export class WaitUtil {

    static sleep(ms: number): Promise<void> {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /** Polls `condition` until it returns true or the timeout elapses. */
    static async waitUntil(
        condition: () => Promise<boolean> | boolean,
        timeoutMs = 10000,
        intervalMs = 250,
        description = 'condition'
    ): Promise<void> {

        const deadline = Date.now() + timeoutMs;

        while (Date.now() < deadline) {
            if (await condition()) return;
            await WaitUtil.sleep(intervalMs);
        }

        throw new Error(`Timed out after ${timeoutMs}ms waiting for ${description}`);
    }
}
