import { JsonReader } from './JsonReader';

export interface UserData {
    username: string;
    password: string;
    description: string;
}

export interface ProductData {
    name: string;
    price: number;
}

export interface CheckoutData {
    firstName: string;
    lastName: string;
    postalCode: string;
}

export interface CredentialsData {
    defaultPassword: string;
    invalid: { username: string; password: string };
}

/** Typed, cached access to the JSON files under src/test-data. */
export class TestDataUtil {

    private static users?: Record<string, UserData>;
    private static products?: ProductData[];
    private static checkout?: { default: CheckoutData };
    private static credentials?: CredentialsData;

    static getUsers(): Record<string, UserData> {
        return (TestDataUtil.users ??= JsonReader.read<Record<string, UserData>>('users.json'));
    }

    static getUser(username: string): UserData {
        const user = TestDataUtil.getUsers()[username];
        if (!user) throw new Error(`User "${username}" not found in users.json`);
        return user;
    }

    static getCredentials(): CredentialsData {
        return (TestDataUtil.credentials ??= JsonReader.read<CredentialsData>('credentials.json'));
    }

    /** Password for a known user, or the shared default for unknown ones. */
    static getPasswordFor(username: string): string {
        return TestDataUtil.getUsers()[username]?.password ?? TestDataUtil.getCredentials().defaultPassword;
    }

    static getProducts(): ProductData[] {
        return (TestDataUtil.products ??= JsonReader.read<ProductData[]>('products.json'));
    }

    static getProduct(name: string): ProductData {
        const product = TestDataUtil.getProducts().find(p => p.name === name);
        if (!product) throw new Error(`Product "${name}" not found in products.json`);
        return product;
    }

    static getDefaultCheckout(): CheckoutData {
        return (TestDataUtil.checkout ??= JsonReader.read<{ default: CheckoutData }>('checkout.json')).default;
    }
}
