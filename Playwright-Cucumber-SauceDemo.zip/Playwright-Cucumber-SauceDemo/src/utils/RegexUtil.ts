export class RegexUtil {

    /** Escapes regex metacharacters so a literal string can be used inside a RegExp. */
    static escape(value: string): string {
        return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    /** Case-sensitive, whole-string match for a literal value. */
    static exact(value: string): RegExp {
        return new RegExp(`^${RegexUtil.escape(value)}$`);
    }

    /** Parses a price such as "$29.99" or "Item total: $29.99" into 29.99. */
    static parsePrice(text: string): number {
        const match = text.match(/\$\s*([\d,]+(?:\.\d+)?)/);
        if (!match) throw new Error(`No price found in "${text}"`);
        return Number(match[1].replace(/,/g, ''));
    }
}
