import { config } from '../core/EnvironmentManager';

type Level = 'debug' | 'info' | 'warn' | 'error';

const order: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };

/** Minimal leveled logger. Level is controlled by LOG_LEVEL. */
export class Logger {

    private static enabled(level: Level): boolean {
        const configured = (config.logLevel as Level) in order ? (config.logLevel as Level) : 'info';
        return order[level] >= order[configured];
    }

    private static write(level: Level, message: string): void {
        if (!Logger.enabled(level)) return;
        const line = `${new Date().toISOString()} [${level.toUpperCase()}] ${message}`;
        level === 'error' ? console.error(line) : console.log(line);
    }

    static debug(message: string): void { Logger.write('debug', message); }

    static info(message: string): void { Logger.write('info', message); }

    static warn(message: string): void { Logger.write('warn', message); }

    static error(message: string): void { Logger.write('error', message); }
}
