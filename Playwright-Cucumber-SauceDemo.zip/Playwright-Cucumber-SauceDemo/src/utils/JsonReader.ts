import fs from 'fs';
import path from 'path';
import { config } from '../core/EnvironmentManager';

export class JsonReader {

    /** Reads and parses a JSON file located under src/test-data (e.g. "users.json"). */
    static read<T>(relativePath: string): T {

        const fullPath = path.join(config.paths.testData, relativePath);

        if (!fs.existsSync(fullPath)) {
            throw new Error(`Test data file not found: ${fullPath}`);
        }

        return JSON.parse(fs.readFileSync(fullPath, 'utf-8')) as T;
    }
}
