import fs from 'fs';
import path from 'path';
import { Page } from '@playwright/test';
import { config } from '../core/EnvironmentManager';

export class ScreenshotUtil {

    /** Makes a scenario name safe to use as a file name. */
    static toFileName(name: string): string {
        return name.replace(/[^a-z0-9]+/gi, '_').replace(/^_+|_+$/g, '').slice(0, 120) || 'screenshot';
    }

    /** Saves a full-page screenshot to /screenshots and returns the PNG buffer. */
    static async capture(page: Page, scenarioName: string): Promise<Buffer> {

        fs.mkdirSync(config.paths.screenshots, { recursive: true });

        const stamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filePath = path.join(config.paths.screenshots, `${ScreenshotUtil.toFileName(scenarioName)}_${stamp}.png`);

        return page.screenshot({ path: filePath, fullPage: true });
    }
}
