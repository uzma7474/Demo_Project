import { BrowserName, TraceMode, config } from '../core/EnvironmentManager';

/**
 * Thin static facade over the loaded configuration.
 * Page objects, fixtures and helpers depend on this, never on process.env directly.
 */
export class Environment {

    static getEnvName(): string {
        return config.env;
    }

    static getBaseUrl(): string {
        return config.baseUrl;
    }

    static getBrowser(): BrowserName {
        return config.browser;
    }

    static isHeadless(): boolean {
        return config.headless;
    }

    static getSlowMo(): number {
        return config.slowMo;
    }

    static getDefaultTimeout(): number {
        return config.defaultTimeout;
    }

    static getNavigationTimeout(): number {
        return config.navigationTimeout;
    }

    static getExpectTimeout(): number {
        return config.expectTimeout;
    }

    static getViewport(): { width: number; height: number } {
        return { ...config.viewport };
    }

    static isVideoEnabled(): boolean {
        return config.video;
    }

    static getTraceMode(): TraceMode {
        return config.trace;
    }

    static isScreenshotOnFailure(): boolean {
        return config.screenshotOnFailure;
    }

    /** Reads any raw environment variable (e.g. STANDARD_USERNAME). */
    static get(key: string, fallback?: string): string | undefined {
        return process.env[key] ?? fallback;
    }
}
