Feature: Checkout - order overview
  As a customer
  I want to review my order and its total
  So that I know exactly what I am paying

  Background:
    Given the user is logged in as "standard_user"
    And the user adds Sauce Labs Backpack to the cart
    And the user adds Sauce Labs Fleece Jacket to the cart
    And the user opens the cart
    And the user clicks checkout
    And the user fills checkout information with the default customer details
    And the user clicks continue

  @smoke @checkout @CHK005 @checkoutOverview01
  Scenario: Overview lists the ordered products
    Then the checkout overview page should be displayed
    And the overview should list Sauce Labs Backpack
    And the overview should list Sauce Labs Fleece Jacket

  @regression @checkout @CHK006 @checkoutOverview02
  Scenario: Item total, tax and total are calculated correctly
    Then the order summary should be calculated correctly

  @regression @checkout @CHK007 @checkoutOverview03
  Scenario: Cancel on the overview returns to the products page
    When the user cancels the checkout from the overview page
    Then the inventory page should be displayed
