Feature: Checkout - customer information
  As a customer with items in my cart
  I want to enter my details
  So that my order can be processed

  Background:
    Given the user is logged in as "standard_user"
    And the user adds Sauce Labs Backpack to the cart
    And the user opens the cart
    And the user clicks checkout

  @smoke @checkout @CHK001 @checkoutInformation01
  Scenario: Checkout information page is displayed
    Then the checkout information page should be displayed

  @regression @checkout @negative @CHK002 @checkoutInformation02
  Scenario Outline: Missing mandatory information is rejected
    When the user fills checkout information with first name "<firstName>", last name "<lastName>" and postal code "<postalCode>"
    And the user clicks continue
    Then the checkout error message should be "<error>"

    Examples:
      | firstName | lastName | postalCode | error                           |
      |           | Doe      | 411001     | Error: First Name is required   |
      | John      |          | 411001     | Error: Last Name is required    |
      | John      | Doe      |            | Error: Postal Code is required  |
      |           |          |            | Error: First Name is required   |

  @smoke @checkout @CHK003 @checkoutInformation03
  Scenario: Valid information continues to the overview
    When the user fills checkout information with the default customer details
    And the user clicks continue
    Then the checkout overview page should be displayed

  @regression @checkout @CHK004 @checkoutInformation04
  Scenario: Cancel returns to the cart
    When the user cancels the checkout from the information page
    Then the cart page should be displayed
    And the cart should contain Sauce Labs Backpack
