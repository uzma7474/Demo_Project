Feature: Checkout - order confirmation
  As a customer
  I want confirmation that my order was placed
  So that I know it went through

  Background:
    Given the user is logged in as "standard_user"
    And the user places an order for Sauce Labs Bike Light using the default customer details

  @smoke @checkout @CHK008 @checkoutComplete01
  Scenario: Confirmation page is displayed after finishing the order
    Then the order confirmation page should be displayed
    And the confirmation message should be "Thank you for your order!"

  @regression @checkout @CHK009 @checkoutComplete02
  Scenario: Back Home returns to an empty cart on the products page
    When the user returns to products from the confirmation page
    Then the inventory page should be displayed
    And the cart badge should not be displayed
