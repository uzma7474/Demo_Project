Feature: Shopping cart
  As a logged-in customer
  I want to review and change my cart
  So that I only buy what I want

  Background:
    Given the user is logged in as "standard_user"

  @smoke @cart @CRT001 @cart01
  Scenario: Cart shows the products that were added
    Given the user adds Sauce Labs Backpack to the cart
    And the user adds Sauce Labs Bike Light to the cart
    When the user opens the cart
    Then the cart page should be displayed
    And the cart should contain 2 items
    And the cart should contain Sauce Labs Backpack
    And the cart should contain Sauce Labs Bike Light

  @regression @cart @CRT002 @cart02
  Scenario: Empty cart has no items
    When the user opens the cart
    Then the cart page should be displayed
    And the cart should be empty

  @regression @cart @CRT003 @cart03
  Scenario: Each cart item has quantity one
    Given the user adds Sauce Labs Onesie to the cart
    When the user opens the cart
    Then the cart item Sauce Labs Onesie should have quantity 1

  @regression @cart @CRT004 @cart04
  Scenario: Remove an item from the cart page
    Given the user adds Sauce Labs Backpack to the cart
    And the user adds Sauce Labs Bolt T-Shirt to the cart
    When the user opens the cart
    And the user removes Sauce Labs Backpack from the cart page
    Then the cart should not contain Sauce Labs Backpack
    And the cart should contain 1 item
    And the cart badge should show 1

  @regression @cart @CRT005 @cart05
  Scenario: Continue shopping returns to the products page
    Given the user adds Sauce Labs Backpack to the cart
    When the user opens the cart
    And the user clicks continue shopping
    Then the inventory page should be displayed
    And the cart badge should show 1

  @smoke @cart @CRT006 @cart06
  Scenario: Checkout from the cart opens the information page
    Given the user adds Sauce Labs Backpack to the cart
    When the user opens the cart
    And the user clicks checkout
    Then the checkout information page should be displayed
