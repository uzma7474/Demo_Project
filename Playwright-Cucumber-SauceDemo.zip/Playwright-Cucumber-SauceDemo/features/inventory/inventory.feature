Feature: Inventory - product listing, sorting, cart badge and menu
  As a logged-in customer
  I want to browse and sort products
  So that I can choose what to buy

  Background:
    Given the user is logged in as "standard_user"

  @smoke @inventory @INVT001 @inventory01
  Scenario: Products page is displayed after login
    Then the inventory page should be displayed
    And the page heading should be "Products"
    And 6 products should be displayed

  @regression @inventory @INVT002 @inventory02
  Scenario: Every product shows name, description, price and image
    Then every product should show its name, description, price and image

  @regression @inventory @INVT003 @inventory03
  Scenario: Header and footer are displayed
    Then the header and footer should be displayed

  # ------------------------------------------------------------------------------------------
  # Sorting
  # ------------------------------------------------------------------------------------------

  @regression @inventory @sorting @INVT004 @inventory04
  Scenario Outline: Sort products
    When the user selects sort option "<option>"
    Then the products should be sorted by "<key>"

    Examples:
      | option              | key  |
      | Name (A to Z)       | az   |
      | Name (Z to A)       | za   |
      | Price (low to high) | lohi |
      | Price (high to low) | hilo |

  # ------------------------------------------------------------------------------------------
  # Cart badge
  # ------------------------------------------------------------------------------------------

  @smoke @inventory @cart @INVT005 @inventory05
  Scenario: Adding a product updates the cart badge and button
    When the user adds Sauce Labs Backpack to the cart
    Then the cart badge should show 1
    And the Sauce Labs Backpack button should read "Remove"

  @regression @inventory @cart @INVT006 @inventory06
  Scenario: Adding multiple products updates the cart badge
    When the user adds Sauce Labs Backpack to the cart
    And the user adds Sauce Labs Bike Light to the cart
    And the user adds Sauce Labs Onesie to the cart
    Then the cart badge should show 3

  @regression @inventory @cart @INVT007 @inventory07
  Scenario: Removing a product from the products page clears the badge
    Given the user adds Sauce Labs Backpack to the cart
    When the user removes Sauce Labs Backpack from the products page
    Then the cart badge should not be displayed
    And the Sauce Labs Backpack button should read "Add to cart"

  # ------------------------------------------------------------------------------------------
  # Side menu
  # ------------------------------------------------------------------------------------------

  @regression @inventory @menu @INVT008 @inventory08
  Scenario: Side menu lists all options
    When the user opens the side menu
    Then the side menu should display all menu options

  @regression @inventory @menu @INVT009 @inventory09
  Scenario: Reset app state empties the cart
    Given the user adds Sauce Labs Backpack to the cart
    When the user resets the app state
    Then the cart badge should not be displayed
