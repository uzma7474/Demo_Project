Feature: Product details
  As a logged-in customer
  I want to open a product
  So that I can see its details before buying

  Background:
    Given the user is logged in as "standard_user"

  @smoke @productDetails @PD001 @productDetails01
  Scenario Outline: Product details match the catalogue
    When the user opens the details of <product>
    Then the user should be redirected to "/inventory-item.html"
    And the product details should match the catalogue for <product>

    Examples:
      | product                           |
      | Sauce Labs Backpack               |
      | Sauce Labs Bike Light             |
      | Sauce Labs Bolt T-Shirt           |
      | Sauce Labs Fleece Jacket          |
      | Sauce Labs Onesie                 |
      | Test.allTheThings() T-Shirt (Red) |

  @regression @productDetails @PD002 @productDetails02
  Scenario: Add a product to the cart from the details page
    When the user opens the details of Sauce Labs Backpack
    And the user adds the product to the cart from the details page
    Then the cart badge should show 1
    And the product details page should show the Remove button

  @regression @productDetails @PD003 @productDetails03
  Scenario: Back to products returns to the product list
    When the user opens the details of Sauce Labs Bike Light
    And the user goes back to the products page
    Then the inventory page should be displayed
    And 6 products should be displayed
