Feature: Login - invalid credentials and input validation
  As a SauceDemo customer
  I want clear errors when my login fails
  So that I know how to correct it

  # ============================================================================================
  # LOCKED USER
  # ============================================================================================

  @negative @security @smoke @INV001 @invalidLogin01
  Scenario: Login with locked out user
    Given the user is on the SauceDemo login page
    When user enters username "locked_out_user"
    And user enters password "secret_sauce"
    And user clicks login button
    Then the login error message should be "Epic sadface: Sorry, this user has been locked out."

  # ============================================================================================
  # INVALID CREDENTIALS
  # ============================================================================================

  @negative @smoke @INV002 @invalidLogin02
  Scenario Outline: Login with invalid credential combinations
    Given the user is on the SauceDemo login page
    When user enters username "<username>"
    And user enters password "<password>"
    And user clicks login button
    Then the login error message should be "Epic sadface: Username and password do not match any user in this service"

    Examples:
      | username      | password       |
      | standard_user | wrong_password |
      | invalid_user  | secret_sauce   |
      | invalid_user  | wrong_password |

  # ============================================================================================
  # EMPTY FIELDS
  # ============================================================================================

  @negative @validation @regression @INV003 @invalidLogin03
  Scenario: Login with empty username
    Given the user is on the SauceDemo login page
    When user leaves the username field empty
    And user enters password "secret_sauce"
    And user clicks login button
    Then the login error message should be "Epic sadface: Username is required"

  @negative @validation @regression @INV004 @invalidLogin04
  Scenario: Login with empty password
    Given the user is on the SauceDemo login page
    When user enters username "standard_user"
    And user leaves the password field empty
    And user clicks login button
    Then the login error message should be "Epic sadface: Password is required"

  @negative @validation @regression @INV005 @invalidLogin05
  Scenario: Login with empty username and password
    Given the user is on the SauceDemo login page
    When user leaves the username field empty
    And user leaves the password field empty
    And user clicks login button
    Then the login error message should be "Epic sadface: Username is required"

  # ============================================================================================
  # WHITESPACE, CASE SENSITIVITY, SPECIAL CHARACTERS, BOUNDARIES
  # (Gherkin trims table cells, so \s = space, \t = tab and \n = newline are decoded by the step definition)
  # ============================================================================================

  @negative @validation @regression @INV006 @invalidLogin06
  Scenario Outline: Login with malformed or non-matching input
    Given the user is on the SauceDemo login page
    When user enters username "<username>"
    And user enters password "<password>"
    And user clicks login button
    Then the login error message should be "Epic sadface: Username and password do not match any user in this service"

    Examples: Whitespace
      | username              | password         |
      | \s\sstandard_user\s\s | secret_sauce     |
      | standard_user         | \ssecret_sauce\s |
      | standard_user\t       | secret_sauce     |
      | standard_user         | secret_sauce\t   |

    Examples: Case sensitivity
      | username      | password     |
      | STANDARD_USER | secret_sauce |
      | standard_user | SECRET_SAUCE |

    Examples: Special characters
      | username   | password     |
      | !@#$%^&*() | secret_sauce |
      | standard_user | !@#$%^&*() |

    Examples: Boundary values
      | username                                                                                             | password                                                                                             |
      | aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa | secret_sauce                                                                                         |
      | standard_user                                                                                        | aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa |

  # ============================================================================================
  # INJECTION ATTEMPTS
  # ============================================================================================

  @negative @security @regression @INV007 @invalidLogin07
  Scenario Outline: Login rejects injection strings
    Given the user is on the SauceDemo login page
    When user enters username "<username>"
    And user enters password "<password>"
    And user clicks login button
    Then the login error message should be "Epic sadface: Username and password do not match any user in this service"

    Examples:
      | username                      | password     |
      | ' OR '1'='1                   | ' OR '1'='1  |
      | <script>alert('XSS')</script> | secret_sauce |

  # ============================================================================================
  # ERROR MESSAGE BEHAVIOUR
  # ============================================================================================

  @ui @negative @regression @INV008 @invalidLogin08
  Scenario: Verify login error message is displayed
    Given the user is on the SauceDemo login page
    When user enters username "invalid_user"
    And user enters password "wrong_password"
    And user clicks login button
    Then the login error message should be displayed

  @ui @negative @regression @INV009 @invalidLogin09
  Scenario: Close login error message
    Given the user is on the SauceDemo login page
    When user enters username "invalid_user"
    And user enters password "wrong_password"
    And user clicks login button
    Then the login error message should be displayed
    When the user closes the login error message
    Then the login error message should not be displayed
