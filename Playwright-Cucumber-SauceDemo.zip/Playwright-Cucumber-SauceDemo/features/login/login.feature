Feature: Login - successful login, UI and access control
  As a SauceDemo customer
  I want to log in with my credentials
  So that I can access the product catalogue

  # ============================================================================================
  # POSITIVE
  # ============================================================================================

  @positive @smoke @LGN001 @login01
  Scenario: Login with valid credentials
    Given user opens SauceDemo application
    When user enters username "standard_user"
    And user enters password "secret_sauce"
    And user clicks login button
    Then user should be redirected to inventory page

  @positive @regression @LGN002 @login02
  Scenario Outline: Login successfully with each accepted user type
    Given user opens SauceDemo application
    When user enters username "<username>"
    And user enters password "<password>"
    And user clicks login button
    Then user should be redirected to inventory page

    Examples:
      | username                | password     |
      | standard_user           | secret_sauce |
      | problem_user            | secret_sauce |
      | performance_glitch_user | secret_sauce |
      | error_user              | secret_sauce |
      | visual_user             | secret_sauce |

  # ============================================================================================
  # UI VALIDATION
  # ============================================================================================

  @ui @smoke @LGN003 @login03
  Scenario: Verify username field is displayed
    Given the user is on the SauceDemo login page
    Then the username field should be displayed

  @ui @smoke @LGN004 @login04
  Scenario: Verify password field is displayed
    Given the user is on the SauceDemo login page
    Then the password field should be displayed

  @ui @smoke @LGN005 @login05
  Scenario: Verify Login button is displayed
    Given the user is on the SauceDemo login page
    Then the Login button should be displayed

  @ui @regression @LGN006 @login06
  Scenario: Verify Login button is enabled
    Given the user is on the SauceDemo login page
    Then the Login button should be enabled

  @ui @security @regression @LGN007 @login07
  Scenario: Verify password is masked
    Given the user is on the SauceDemo login page
    When user enters password "secret_sauce"
    Then the password should be masked

  # ============================================================================================
  # NAVIGATION AND ACCESS CONTROL
  # ============================================================================================

  @positive @navigation @regression @LGN008 @login08
  Scenario: Verify successful login redirects to inventory
    Given the user is on the SauceDemo login page
    When user enters username "standard_user"
    And user enters password "secret_sauce"
    And user clicks login button
    Then the user should be redirected to "/inventory.html"
    And the inventory page should be displayed

  @negative @security @regression @LGN009 @login09
  Scenario: Prevent unauthorized access to inventory page
    Given the user has not logged into SauceDemo
    When the user navigates directly to "/inventory.html"
    Then the user should not have access to the inventory page
    And the user should be redirected to the login page
    And the login error message should be "Epic sadface: You can only access '/inventory.html' when you are logged in."

  @positive @regression @LGN010 @login10
  Scenario: Logout returns the user to the login page
    Given the user is logged in as "standard_user"
    When the user logs out
    Then the user should be redirected to the login page
