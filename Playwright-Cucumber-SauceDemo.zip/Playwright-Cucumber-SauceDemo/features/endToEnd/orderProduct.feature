Feature: End-to-end ordering
  As a customer
  I want to log in, choose products and complete the purchase
  So that I receive my order

  @e2e @smoke @E2E001 @orderProduct01
  Scenario: Order a single product
    Given the user is logged in as "standard_user"
    When the user places an order for Sauce Labs Backpack using the default customer details
    Then the order should be confirmed
    When the user returns to products from the confirmation page
    Then the inventory page should be displayed
    And the cart badge should not be displayed

  @e2e @regression @E2E002 @orderProduct02
  Scenario: Order multiple products step by step and verify the totals
    Given the user is logged in as "standard_user"
    When the user adds Sauce Labs Backpack to the cart
    And the user adds Sauce Labs Bike Light to the cart
    Then the cart badge should show 2
    When the user opens the cart
    And the user clicks checkout
    And the user fills checkout information with the default customer details
    And the user clicks continue
    Then the overview should list Sauce Labs Backpack
    And the overview should list Sauce Labs Bike Light
    And the order summary should be calculated correctly
    When the user finishes the order
    Then the confirmation message should be "Thank you for your order!"

  @e2e @regression @E2E003 @orderProduct03
  Scenario: Remove a product in the cart before ordering
    Given the user is logged in as "standard_user"
    And the user adds Sauce Labs Onesie to the cart
    And the user adds Sauce Labs Bolt T-Shirt to the cart
    When the user opens the cart
    And the user removes Sauce Labs Onesie from the cart page
    And the user clicks checkout
    And the user fills checkout information with the default customer details
    And the user clicks continue
    Then the overview should list Sauce Labs Bolt T-Shirt
    And the order summary should be calculated correctly
    When the user finishes the order
    Then the order should be confirmed

  @e2e @regression @E2E004 @orderProduct04
  Scenario Outline: Every catalogue product can be ordered
    Given the user is logged in as "standard_user"
    When the user places an order for <product> using the default customer details
    Then the order should be confirmed

    Examples:
      | product                           |
      | Sauce Labs Backpack               |
      | Sauce Labs Bike Light             |
      | Sauce Labs Bolt T-Shirt           |
      | Sauce Labs Fleece Jacket          |
      | Sauce Labs Onesie                 |
      | Test.allTheThings() T-Shirt (Red) |
