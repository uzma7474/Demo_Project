# Playwright + TypeScript + Cucumber — SauceDemo

BDD UI automation framework for <https://www.saucedemo.com>, built on Playwright, Cucumber.js and TypeScript with the Page Object Model, helpers, assertions and per-scenario browser isolation.

## Quick start

```bash
npm install
npx playwright install --with-deps   # downloads browsers (first time only)
npm run typecheck                    # optional: compile check
npm test                             # run everything, headless chromium
```

| Command | What it does |
|---|---|
| `npm test` | All features |
| `npm run test:smoke` | `@smoke` scenarios |
| `npm run test:regression` | Everything not tagged `@wip` |
| `npm run test:login` / `inventory` / `cart` / `checkout` / `e2e` | One feature folder |
| `npm run test:headed` | Visible browser |
| `npm run test:debug` | Visible browser, 300 ms slow motion |
| `npm run test:firefox` / `test:webkit` | Other browsers |
| `npm run test:parallel` | 4 parallel workers |
| `npx cucumber-js --tags "@login and not @security"` | Any tag expression |
| `npm run show:trace -- traces/<scenario>.zip` | Open a failure trace |

## Control flow

```
cucumber.js → Cucumber runner → Before hook
  → BrowserFixture → Browser → BrowserContext → Page → CustomWorld
  → feature file → step definitions → Helper → Page object → BasePage → Playwright → SauceDemo
  → Assertions
  → After hook: screenshot if failed · trace if failed · close browser
```

| Layer | Folder | Responsibility |
|---|---|---|
| Runner config | `cucumber.js` | Load order, formats, profiles, retries, parallelism |
| Hooks | `src/hooks` | `beforeHook` starts browser + tracing, `afterHook` captures artifacts and closes, `hooks.ts` sets timeouts and creates folders |
| Fixtures | `src/fixtures` | One class each for Browser, Context, Page, PageObjects, TestData |
| Core | `src/core` | `BrowserManager` (fixture orchestration), `DriverFactory` (browser launch), `PageObjectManager` (lazy page objects), `EnvironmentManager` (env loading) |
| World | `src/support` | `CustomWorld` holds page, helpers, page objects and test data per scenario; `parameterTypes.ts` defines `{product}` |
| Steps | `src/step-definitions` | Thin glue only: call helpers and assertions |
| Helpers | `src/helpers` | Business workflows (`LoginHelper`, `InventoryHelper`, `CartHelper`, `CheckoutHelper`, `OrderHelper`) |
| Pages | `src/pages` | Locators + page actions; `components/` holds reusable header, footer, side menu, cart, product card |
| Assertions | `src/assertions` | All `expect` calls; they retry until `EXPECT_TIMEOUT` |
| Utils | `src/utils` | `Environment`, `Constants`, `Logger`, `ScreenshotUtil`, `JsonReader`, `TestDataUtil`, `WaitUtil`, `RegexUtil` |
| Test data | `src/test-data` | `users.json`, `credentials.json`, `products.json`, `checkout.json` |

Rules that keep it scalable: steps never touch Playwright, page objects never assert, assertions never click, and every scenario gets its own browser, context and page.

## Configuration

Edit `.env`, or override with real environment variables. `ENV=stage` loads `.env.stage` first.

| Variable | Default | Notes |
|---|---|---|
| `BASE_URL` | `https://www.saucedemo.com` | |
| `BROWSER` | `chromium` | `firefox`, `webkit` |
| `HEADLESS` | `true` | |
| `SLOW_MO` | `0` | ms |
| `DEFAULT_TIMEOUT` / `NAVIGATION_TIMEOUT` / `EXPECT_TIMEOUT` | 15000 / 30000 / 10000 | ms |
| `TRACE` | `on-failure` | `on`, `off`, `on-failure` |
| `VIDEO` | `false` | Kept only for failed scenarios |
| `SCREENSHOT_ON_FAILURE` | `true` | Also attached to the HTML report |
| `RETRY` / `PARALLEL` | `0` / `0` | Cucumber retries and workers |

## Artifacts

| Output | Location |
|---|---|
| HTML report | `reports/html/index.html` |
| JSON report | `reports/json/cucumber.json` |
| Cucumber messages | `reports/cucumber-report/messages.ndjson` |
| Failure screenshots | `screenshots/` |
| Failure traces | `traces/*.zip` |
| Videos | `videos/` |

## Writing new tests

1. Add locators and actions to a page object (or a new class in `src/pages/`, exposed from `PageObjectManager`).
2. Add a workflow method to the matching helper and an assertion to the matching assertions class.
3. Add a feature file and thin steps in `src/step-definitions/<area>/`.
4. Tag it (`@smoke`, `@regression`, `@wip` to skip).

Feature-file escapes for login input: Gherkin trims table cells and cannot hold control characters, so use `\s` for a space, `\t` for a tab and `\n` for a newline in username and password values.

## SauceDemo users

`standard_user`, `locked_out_user`, `problem_user`, `performance_glitch_user`, `error_user`, `visual_user` — all with password `secret_sauce` (public demo credentials).
