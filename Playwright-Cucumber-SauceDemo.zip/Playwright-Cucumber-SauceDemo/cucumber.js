/**
 * Cucumber runner configuration.
 *
 * Load order matters: support (World, parameter types) -> hooks -> step definitions.
 * Profiles:  npx cucumber-js --profile smoke
 */
const common = {
    paths: ['features/**/*.feature'],
    requireModule: ['ts-node/register'],
    require: [
        'src/support/**/*.ts',
        'src/hooks/**/*.ts',
        'src/step-definitions/**/*.ts'
    ],
    format: [
        'progress-bar',
        'html:reports/html/index.html',
        'json:reports/json/cucumber.json',
        'message:reports/cucumber-report/messages.ndjson'
    ],
    formatOptions: { snippetInterface: 'async-await' },
    retry: Number(process.env.RETRY || 0),
    parallel: Number(process.env.PARALLEL || 0)
};

module.exports = {
    default: common,
    smoke: { ...common, tags: '@smoke' },
    regression: { ...common, tags: 'not @wip' },
    e2e: { ...common, tags: '@e2e' }
};
