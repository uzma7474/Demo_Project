/**
 * Playwright tooling config.
 *
 * Tests are executed by the Cucumber runner (see cucumber.js), not by `playwright test`.
 * This file exists so Playwright tooling (VS Code extension, `playwright install`,
 * trace viewer defaults) shares the same browser / viewport / timeout settings.
 */
import { defineConfig, devices } from '@playwright/test';
import { config } from './src/core/EnvironmentManager';

export default defineConfig({
    testDir: './features',
    timeout: config.defaultTimeout * 4,
    expect: { timeout: config.expectTimeout },
    outputDir: 'traces',
    use: {
        baseURL: config.baseUrl,
        headless: config.headless,
        viewport: config.viewport,
        actionTimeout: config.defaultTimeout,
        navigationTimeout: config.navigationTimeout,
        trace: config.trace === 'on-failure' ? 'retain-on-failure' : config.trace
    },
    projects: [
        { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
        { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
        { name: 'webkit', use: { ...devices['Desktop Safari'] } }
    ]
});
